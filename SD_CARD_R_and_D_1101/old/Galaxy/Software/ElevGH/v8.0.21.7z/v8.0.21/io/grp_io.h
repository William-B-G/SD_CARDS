extern void set_grp_io (void);
