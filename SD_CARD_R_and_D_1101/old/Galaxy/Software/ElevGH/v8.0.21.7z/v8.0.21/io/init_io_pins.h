extern void InitGPIO(void);
extern void InitGPIO_p1(void);
