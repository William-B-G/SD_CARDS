#include "global.h"


/*******************************************************************************
* External objects
*******************************************************************************/

/* Prototype for PRC1 startup */
extern void __start_p1();
extern void control(void); 
extern void init_control(void);
extern void inttim(void);
extern void int_tsec(void);
extern void InitGPIO(void);
extern void InitGPIO_p1(void);
extern short int fvars[];
#define fvcputiming 280			// Cpu timing output control
 
 /*******************************************************************************
* Constants and macros
*******************************************************************************/

#define FLASH_REG FLASH.PFCRP0.R
//#define FLASH_DATA  0x0800EF00
//#define FLASH_DATA  0x04006B00
#define FLASH_DATA  0x00016B00
#define FLASH_REG2 FLASH.PFCRP1.R
//#define FLASH_DATA2 0x30002900
#define FLASH_DATA2 0x30006B00

/*******************************************************************************
* Local types
*******************************************************************************/

/*******************************************************************************
* Local function prototypes
*******************************************************************************/
static void InitHW(void);
static void InitSysclk(void);
static void FlashConfig(void);
static void Delay(void);
static void Delay_1s(void);


/*******************************************************************************
* Local variables
*******************************************************************************/ 

/*******************************************************************************
* Local functions
*******************************************************************************/
          
/*******************************************************************************
Function Name : InitHW
Engineer      : b08110
Date          : Feb-18-2010
Parameters    : NONE
Modifies      : NONE
Returns       : NONE
Notes         : initialization of the hw for the purposes of this example
Issues        : NONE
*******************************************************************************/
static void InitHW(void)
{
    disable_dog();
    InitSysclk();
    FlashConfig();
    InitGPIO();    
	InitGPIO_p1();	
}

/*******************************************************************************
Function Name : InitSysclk
Engineer      : b08110
Date          : Feb-18-2010
Parameters    : NONE
Modifies      : NONE
Returns       : NONE
Notes         : initialize Fsys 108.75 MHz PLL with 40 MHz crystal reference
                monitor PK9 (connector P30 pin 10 on MPC5668EVB) for Fsys/2
Issues        : NONE
*******************************************************************************/
static void InitSysclk(void)
{
    /* External clock enable. ECEN = 1 */
    /* External clock divide by 2. ECDF = 0b01 */
    SIU.ECCR.R = 0x00000009; 
    
    /* configure PK9 for CLKOUT */ 
    /* PA = 0b01 */
    /* OBE = 1 output */
    /* IBE = 0 */
    /* ODE = 0 */
    /* HYS = 0 */
    /* SRC = 0b11 max.slew rate */
    /* WPE = 0 */
    /* WPS = 0 */    
//    SIU.PCR[153].R = 0x060C;
 
 #if 1 
    /* EN40MOSC is enabled out of reset by default */  
    /* enable external oscillator */ 
//    CRP.CLKSRC.B.EN40MOSC = 0b1;      
    CRP.CLKSRC.B.EN40MOSC = 0x0001;      
 #endif
    
    /*
    1. determine the approptiate value EPREDIV, EMFD, ERFD. 
    for Fsys = 108.75 MHz with a 40 MHz crystal reference, we will get the final
    values: 

    EPREDIV = 7 (divide by 8) 
    EMFD = 71 (divide by 87) 
    ERFD = 3 (divide by 4) in this case, 
    Fvco will be 435 MHz. 
    */
         
    /* 2. write ERFD = 5 (divide by 6). disable FM (EDEPTH = 0) */ 
    FMPLL.ESYNCR2.R = 5; 

    /* 3. EPREDIV = 7 (div by 8), EMFD = 71 (div by 87) */ 
//    FMPLL.ESYNCR1.R = 0xF0090054; // EPREDIV = 9 (div by 10), EMFD = 84 (div by 100) -- for 100Mhz
    FMPLL.ESYNCR1.R = 0xF0070047; // EPREDIV = 7 (div by 8), EMFD = 71 (div by 87)
 
    /* 4. wait for LOCK */ 
    while (FMPLL.SYNSR.B.LOCK != 1) {} 
 
    /* 5. write final ERFD = 3 (divide by 4). disable FM (EDEPTH = 0) */ 
    FMPLL.ESYNCR2.R = 3; 
 
    /* 6. select PLL as the Fsys */ 
    SIU.SYSCLK.B.SYSCLKSEL = 2;         
}



/*******************************************************************************
Function Name : FlashConfig
Engineer      : b08110
Date          : Mar-04-2010
Parameters    : NONE
Modifies      : NONE
Returns       : NONE
Notes         : PFCRP0 and PFCRP1 adjusted for actual Fsys
Issues        : expected Fsys = 100 MHz, IOP operates 50 MHz
*******************************************************************************/
static void FlashConfig(void) 
{
    unsigned int mem_write_code [] = 
    {

    #if __option(vle)
        /*for processors which support VLE only or for 'VLE on' option*/
        0xD0344400, /* stw r3,(0)r4 machine code: writes r3 contents to addr in r4 then se_nop*/
        0x7C0006AC, /* mbar machine code: ensure prior store completed */
        0x44000004  /* blr machine code: branches to return address in link register */
    #else
        0x90640000, /* stw r3,(0)r4 machine code: writes r3 contents to addr in r4 */
        0x7C0006AC, /* mbar machine code: ensure prior store completed */
        0x4E800020  /* blr machine code: branches to return address in link register */
    #endif // __option(vle)

    };
	

typedef void (*mem_write_code_ptr_t)(unsigned int, unsigned int);
 
    (*((mem_write_code_ptr_t)mem_write_code)) 	/* cast mem_write_code as func ptr*/
                                 /* * de-references func ptr, i.e. converts to func*/
        (FLASH_DATA,            /* which passes integer (in r3) */
        (unsigned int)&FLASH_REG);
      
//#if defined(FLASH_REG2)
    (*((mem_write_code_ptr_t)mem_write_code)) 	/* cast mem_write_code as func ptr*/
                                 /* * de-references func ptr, i.e. converts to func*/
        (FLASH_DATA2,            /* which passes integer (in r3) */
        (unsigned int)&FLASH_REG2);
//#endif 
 
}


static void Unexpected_Interrupt (void)
{
   while (1) {}; 	 /* Wait forever or for watchdog timeout */
}


/*******************************************************************************
Function Name : InitPIT
Engineer      : b08110
Date          : Feb-18-2011
Parameters    : NONE
Modifies      : NONE
Returns       : NONE
Notes         : - 1 second periodic interrup using the PIT3 module
Issues        : - expecting 108.75 MHz fsys for the PIT timer
*******************************************************************************/
static void InitPIT(void)
{
	/* 30: MDIS = 0 to enable clock for PITs. */
    /* 31: FRZ = 1 for Timers stopped in debug mode */
    PIT.MCR.R = 0x00000001;    



	// 10 msec interrupt timer - PIT 1
//	PIT.LDVAL1.R = 1000000 - 1;		// setup timer 1 for 10 msec with 100 MHz fsys
	PIT.LDVAL1.R = 1087500 - 1;		// setup timer 1 for 10 msec with 108.75 MHz fsys
	PIT.TFLG1.B.TIF = 1;			// Clear interrupt flag so an interrupt does not occur right away
	PIT.TCTRL1.B.TIE = 1;		// Enable interrupts
	PIT.TCTRL1.B.TEN = 1;		// Start Timer
                
    // 1 second timer - PIT 3
//    PIT.LDVAL3.R = 100000000 - 1;
    PIT.LDVAL3.R = 108750000 - 1;
    	
    /* clear the TIF flag */
    PIT.TFLG3.R = 0x00000001;
    	
    /* 30: TIE = 1 for interrupt request enabled */
    /* 31: TEN = 1 for timer active */
    PIT.TCTRL3.R = 0x00000003;
}


/*******************************************************************************
* Main call top car control for Z6 CPU
*******************************************************************************/
int32_t main(void) 
{
    uint32_t i = 0;

    InitHW();
    
    
    // Set all interrupts to the Unexpected interrupt vector
    
    for(i=0;i<316;i++)
    {
	    INTC_InstallINTCInterruptHandler(Unexpected_Interrupt, (uint16)i, 10);
    }
    
    
    /* Install PIT3_isr into the interrupt vector table */
    INTC_InstallINTCInterruptHandler(int_tsec, 151, 1);

  	/* Install our handlers */  
  	INTC_InstallINTCInterruptHandler(inttim, 149, 1);  
    
    /* lower current INTC priority to start INTC interrupts */
    INTC.CPR_PRC0.R = 0;
    
    /* Initilize pit timers */
    InitPIT();
    
    // sytem timer
	STM._CR.B.CPS = 0;		// divide by 1
	// Set DMA priority operation for all DMA devices
	STM._CR.B.TEN = 0;		// disable for now
	STM.CNT.R = 0;
	
  	EDMA.CRR.R = 0x0000000C; 	// Use round robin priority arbitration for DMA groups and channels  

	
	init_control();
  

  	/* Start the other core by writing CRP.Z0VEC.R */ 
  	CRP.Z0VEC.R = (unsigned long)__start_p1;
            
  	/* Loop forever */
  	for (;;) {
    	i++;
    	control();
  	}
}

