extern bool hc_power_lost;
extern uint16 emdispf;

extern void hallcall_comm_loss(void);
