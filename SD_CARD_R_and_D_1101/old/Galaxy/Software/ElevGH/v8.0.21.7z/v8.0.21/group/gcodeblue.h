
extern int16 g_cb_fl[car_size];
extern int16 g_rcb_fl[car_size];
extern int16 grp_codebf[car_size];

extern uint32 g_cbmsk[2];			// Bit mask for valid code blue call floors
extern uint32 g_rcbmsk[2];			// Bit mask for valid rear code blue call floors


extern void code_blue(void);
