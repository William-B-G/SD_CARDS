// Delta drive include file
extern void Adjust_Delta_Drive_Parameters (void);
extern void Adjust_KEB_Drive_Parameters (void);
