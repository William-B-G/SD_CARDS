extern int16 ups_com_tx_cnt;					// transmit count
extern int16 ups_com_rx_cnt;					// receive count
extern int16 ups_bat_status;					// power loss ups battery status
extern unsigned char ups_com_online;			// power loss ups online
extern char bat_cap[6];							// Battery capacity

extern void UPS_comm(void);
