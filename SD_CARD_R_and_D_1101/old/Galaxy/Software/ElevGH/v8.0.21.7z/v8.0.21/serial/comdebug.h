extern int16 mute_echo_on_port;
extern void comm_debug(int16 comnmb);
