
extern unsigned char dl20_com_online;			// DL20 online
extern unsigned char dl20_online_count;			// DL20 online count
extern int16 dl20_com_tx_cnt;					// transmit count
extern int16 dl20_com_rx_cnt;					// receive count
extern int16 DL20_tx_timer;						// DL20 10 msec transmit timer

extern void DL20_comm(int16 comnmb);
