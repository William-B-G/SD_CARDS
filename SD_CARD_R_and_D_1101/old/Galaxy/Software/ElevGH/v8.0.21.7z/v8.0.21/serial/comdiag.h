
extern void comm_diag (int16 com_nmb);
extern void Init_Modem(int16 com_nmb);
extern void Modem_Quiet_Mode(int16 com_nmb);
