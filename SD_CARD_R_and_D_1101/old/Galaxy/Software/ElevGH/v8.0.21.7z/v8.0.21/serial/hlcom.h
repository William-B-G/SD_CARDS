extern unsigned char hl_trm_buf[];
extern uint16 hl_tx_len;
extern int16 hl_com_tx_cnt;					// transmit count
extern int16 hl_com_rx_cnt;					// receive count

//*********************************
// Function Declaration
//*********************************

extern void hl_com (void);
