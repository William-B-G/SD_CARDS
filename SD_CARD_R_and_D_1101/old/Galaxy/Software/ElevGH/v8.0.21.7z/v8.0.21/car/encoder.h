extern int16 enc_init_cnt;
extern int16 reset_enc_base_count;


extern void Init_Encoder (void);
extern void preset_encoder_count(int32 Count);
extern void Read_Encoder(void );
extern void init_encoder_count(int32 Count);
