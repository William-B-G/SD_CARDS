#define last_redundancy_test 9
extern int16 disable_auto_door;
extern void set_auto_servf (void);
extern void auto_svc_time_out_recover (void);
extern void doors(void );
extern void rdoors(void );
extern void clr_door_vars(void);
extern void ck_swing_door(void);
extern void doorsel(void);
extern void peelle_doors(void);
extern void auto_freight_doors();
extern void guilbert_doors(void);
extern int16 chkdoor(void);
extern void courion_doors();
extern void ems_doors();
extern int16 at_floor_check (void);
extern void auto_swg_doors(void);
extern void auto_peelle_doors();
