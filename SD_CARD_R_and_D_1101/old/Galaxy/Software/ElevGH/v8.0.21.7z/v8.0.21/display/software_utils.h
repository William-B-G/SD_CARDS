extern int16 software_utilities (int16 lcd_menu);
