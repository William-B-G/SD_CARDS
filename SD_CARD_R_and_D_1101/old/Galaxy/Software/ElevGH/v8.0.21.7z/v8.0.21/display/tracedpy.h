// trace menu

extern const char procf_table[][18];


extern int16 trace_trigger_menu (int16 lcd_menu);
