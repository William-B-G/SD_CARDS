//  Software Utilities Menus

#define d_SWUDPY 1
#include "global.h"
int16 software_utilities (int16 lcd_menu);

#pragma section const_type

const char LCD_Software_Menu[10][21] = {
  " Software Version   ",
  " Run Power-Up Mode  ",
  " Test Watchdog Reset",
  " Reset Debug Vars   ",
  " SD Card Read/Write ",
  " SD Card Status     ",
  " WiFi Card Setup    ",
  " Change Floor PI    ",	 
  " Trace Setup        ",
  " Send Flr Tbl to NTS",
};

#define Last_SW_Menu 9			   //0,1,2,3,4,5,6,7,8
static const char SW_Menu_list[10] = {0,1,2,3,4,5,6,7,8,9};


static  const char LCD_Version[4][21] = {
  "Car # 1 Car Type:   ",
  "   Controller # 1   ",
  " Software Version:  ",
  "      01.01.01      ",
};


static  const char LCD_Jump_info[8][21] = {
  "Place car on Inspect",
  " and then hit Enter ",
  "Cannot Run Power-Up ",
  " Car Not on Inspect ",
  "Power-Up Jump Failed",
  " Invalid MRAM Code  ",
  "Invalid Start Addres",
  "Invalid Address Code",
};

static  const char LCD_Watchdog_info[4][21] = {
  "Place car on Inspect",
  " and then hit Enter ",
  " Cannot Run WD Test ",
  " Car Not on Inspect ",
};

static  const char LCD_SD_Read_Write[19][21] = {
  " Wrt Field Variable ",	 // 0
  " Read FieldVariables",	 // 1
  " Write NTS Proc Vars",	 // 2
  " Read NTS Proc Vars ",	 // 3
  " Wrt Job Setup Data ",	 // 4
  " Read Job Setup Data",	 // 5
  " Write Hoistway Data",	 // 6
  " Read Hoistway Data ",	 // 7
  " Wrt Service Timers ",	 // 8
  " Read Service timers",	 // 9
  " Write Security Data",	 // 10
  " Read Security Data ",	 // 11
  " Write Fault Log    ",	 // 12
  " Wrt LongTerm FltLog",	 // 13
  " Wrt Job Statistics ",	 // 14
  " Rd SD->CPU:cons.dat",  	 // 15
  " Rd SD->CPU:io.dat  ",  	 // 16
  " Wr CPU->SD:cons.dat",  	 // 17
  " Wrt CPU->SD:io.dat ",	 // 18
};

#define Last_SD_Menu 18				//0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18
static const char SD_Menu_list[19] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18};


static  const char LCD_Debug_Reset[2][21] = {
  "  Debug Variables   ",
  "       Reset        ",
};


static  const char LCD_SD_Read_Write_info[15][21] = {
  "    Place Car on    ",	// 0
  " Inspection to Run  ",   // 1
  " SD Card Read/Write ",	// 2
  "     Operation      ",	// 3
  "  Invalid Command   ",	// 4 - 0
  "Data Written to File",	// 5 - 1
  "Data Read from File ",	// 6 - 2
  "   File Not Found   ",	// 7 - 3
  "Cannot Read Car Data",	// 8 - 4
  "  Invalid Car Data  ",	// 9 - 5
  " Invalid Data Field ",	// 10 - 6
  " SD Card Init Error ",	// 11 - 7
  "  Media Init Error  ",	// 12 - 8
  " File Delete Error  ",	// 13 - 9
  " Overwrite File? Y  ",	// 14 - 10
};

static  const char LCD_SD_Card_Status[3][21] = {
  "Hit Enter for Status",
  "Init=0,HC=0,VStat=0 ",
  "Place Car on Inspect",
};

static  const char LCD_SD_Error[17][21] = {
  "    SD Card Error   ",
  "SD Card Not Detected",
  " SD Card Wrt Protect",
  " Idle State Failed  ",
  " Idle CMD0 Time Out ",
  "Block Len CMD TimOut",
  "Read CMD17 Time Out ",
  " Read Command Fail  ",
  "Read Response Error ",
  "Write CMD24 Time Out",
  " Write Command Fail ",
  "Invalid Card Voltage",
  " SDHC ACMD41 Tim-Out",
  " SDHC Response Error",
  "App ReqCMD55 Tim-Out",
  "OCR ReqCMD58 Tim-Out",
  "CRC offCMD59 Tim-Out",
};



static  const char LCD_Mod_Fl_Label[7][21] = {
  " Floor  Table    PI ",
  "  Hit Mode to Exit  ",
  "   Keep Floor PI    ", 
  " Changes <Up/Dn>?No ",
  " Floor PI Table has ",
  "   been Updated.    ",
  "  Not been Updated. ",
};  
static  const char LCD_Fl_Label[7][21] = {
  "        Common      ",
  "      B,G,H,L,M,    ",
  "       P,R,S,T      ",
  "        Number      ",
  "      0,1...8,9     ",
  "        Alpha       ",
  "      A,B...Y,Z     ",
};  

char char_common_tbl[10] = {'B','G','H','L','M','P','R','S','T',' '};
char char_number_tbl[12] = {'0','1','2','3','4','5','6','7','8','9','-',' '};
char char_alpha_tbl[27] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ "};

	
#pragma section all_types

int32 addr_ptr;
int32 address_code = 0;
int32 start_address = 0;

int16 sd_error = 0;		// secure digital return error code

int16 flash_column[2] = {17,18};

int16 tbl_len[3] = {9,11,26};
char *char_ptr_tbl[3] = {char_common_tbl,char_number_tbl,char_alpha_tbl};

char tflmrk[fl_size][2];     // floor markings
int16 tflr_ptr[3] = {0,1,2};

int16 software_utilities (int16 lcd_menu)
{
	int16 i,j;
  	int16 program_status = 0;
	int16 start_ptr;
	int16 line_ptr;
	char *char_ptr;	
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	static int16 menu_ptr_ret;
	static int16 mode_sel;
	static int16 file_read_ok;
	static int16 floor_ptr;
	static int16 table_ptr;
	static int16 char_ix;
	static int16 char_digit_ix;
	static int16 table_upd;
	static char temp_char[2];
	static uint8 yes_no;


	if ((detect_sd() == 0) && (sd_init == 1))
	{
		sd_init = 0;
		sd_error = 0;
	}
	if ((det_sd_wr_prot() == 1) && (sd_init == 1))
	{
		sd_init = 0;
		sd_error = 0;
	}



	if (LCD_Init == 1)
	{
		LCD_Init = 0; 
		upd_dpy = 1;
		menu_level = 0;
		menu_ptr = 0;
  	}

	if (menu_level == 0)
	{			// Rotate through Call menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  menu_ptr = Last_SW_Menu;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
		    if(menu_ptr > Last_SW_Menu)
			  menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = (int16)(SW_Menu_list[menu_ptr] + 1);
  		    mode_sel = 0;
  			menu_ptr_ret = menu_ptr;
  		    menu_ptr = 0;
  		    LCD_Sub_Init = 1;
		  	return(lcd_menu);
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
	  		line_ptr = menu_ptr % 3;
	  		start_ptr = menu_ptr - line_ptr;
	  	    for(i=0; i<=19; i++)
	  	    {
	  			LCD_Display[0][i] = LCD_Main_Menu[13][i];
				LCD_Display[1][i] = LCD_Software_Menu[SW_Menu_list[start_ptr]][i];
				if ((start_ptr + 1) > Last_SW_Menu)
			  	{
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
			  	}
			  	else
			  	{
					LCD_Display[2][i] = LCD_Software_Menu[SW_Menu_list[start_ptr+1]][i];
					if ((start_ptr + 2) > Last_SW_Menu)
				  		LCD_Display[3][i] = ' ';
					else
						LCD_Display[3][i] = LCD_Software_Menu[SW_Menu_list[start_ptr+2]][i];
			  	}
	  	    }
			LCD_Display[line_ptr+1][0] = '>';		// show cursor
		}
	}
	if (menu_level == 1)
	{			// Display software Version
  		if(upd_dpy == 1)	
  		{
	    	upd_dpy = 0;
	    	for(i=0; i<=19; i++)
	    	{
				LCD_Display[0][i] = LCD_Version[0][i];
				LCD_Display[1][i] = LCD_Version[1][i];
				LCD_Display[2][i] = LCD_Version[2][i];
				LCD_Display[3][i] = LCD_Version[3][i];
	    	}
			
			LCD_Display[0][5] = car_bld_no[cons[carnmb]][0];
			LCD_Display[0][6] = car_bld_no[cons[carnmb]][1];

#if (Tract_HR == 1)
			LCD_Display[0][18] = 'T';
			LCD_Display[0][19] = 'R';
#else
			LCD_Display[0][18] = 'H';
			LCD_Display[0][19] = 'Y';
#endif

			LCD_Display[1][16] = (char)(cons[carnmb] + '0');

			if ((version/10) == 0)
				LCD_Display[3][6] = ' ';
			else
				LCD_Display[3][6] = (char)((version/10) + '0');
			LCD_Display[3][7] = (char)((version%10) + '0');
			LCD_Display[3][8] = '.';
			LCD_Display[3][9] = (char)((revision/10) + '0');
			LCD_Display[3][10] = (char)((revision%10) + '0');

			LCD_Display[3][11] = '.';
			LCD_Display[3][12] = (char)((interim_revision/10) + '0');
			LCD_Display[3][13] = (char)((interim_revision%10) + '0');

  #if (Simulator == 1)
			LCD_Display[3][17] = 'S';
			LCD_Display[3][18] = 'i';
			LCD_Display[3][19] = 'm';
#endif
			
		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
      		LCD_Mode_PB = 1;  //
			menu_level = 0;
			menu_ptr = menu_ptr_ret;
 			upd_dpy = 1;
 			return(lcd_menu);
 		}
	}
	if (menu_level == 2)
	{      	  // Jump to Power Up Routine
		if (PasswordFlag == false)
	   	{
	  		StoreLCDInfo();
			clrLCDdpy();
	  		LCD_Menu = 25;
	  		LCD_Init = 1;
 			return(lcd_menu);
   	   	}
  		if(upd_dpy == 1)	
  		{
  		    upd_dpy = 0;
  		    for(i=0; i<=19; i++)
  		    {
  		    	LCD_Display[0][i] = ' ';
				LCD_Display[1][i] = LCD_Jump_info[0][i];
				LCD_Display[2][i] = LCD_Jump_info[1][i];
  		    	LCD_Display[3][i] = ' ';
  		    }
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
#if (Simulator == 0)
	    	if(chk_ins() == 1)
			{ 			// Car must be on inspection
#endif
				clrall();

		 	    addr_ptr = 0x00000000;
		 	    address_code = (*(uint32*)addr_ptr);
				addr_ptr = 0x00000004;
				start_address = (*(uint32*)addr_ptr);
				program_status = 0;
					
				
				if (address_code == 0x015A015A)
				{
					if (start_address != 0)
					{
						if (get_MRAM_code() == 0x4D7C)
						{
				  		    for(i=0; i<=19; i++)
				  		    {
				  		    	LCD_Display[0][i] = ' ';
								LCD_Display[1][i] = ' ';
								LCD_Display[2][i] = ' ';
				  		    	LCD_Display[3][i] = ' ';
				  		    }
							timers[tsec] = 0;	
							delay(20000);						
							write_MRAM_code(0x5E8D);		// Write code to stay in powerup routine
							SIU.SRCR.B.SSR = 1;				// Software Reset
 							return(lcd_menu);
						}
						else
							program_status = 1;
					}
					else 
						program_status = 2;
				}
				else 
					program_status = 3;
				
	  		    for(i=0; i<=19; i++)
	  		    {
			  		LCD_Display[1][i] = LCD_Jump_info[4][i];
			  		LCD_Display[2][i] = LCD_Jump_info[program_status+4][i];
	  		    }
#if (Simulator == 0)
	 		}
			else
			{
	  		    for(i=0; i<=19; i++)
	  		    {
			  		LCD_Display[1][i] = LCD_Jump_info[2][i];
			  		LCD_Display[2][i] = LCD_Jump_info[3][i];
	  		    }
			}
#endif
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
			menu_ptr = menu_ptr_ret;
 			upd_dpy = 1;
 			return(lcd_menu);
  		}
	}
	if (menu_level == 3)
	{      	  // Watchdog test
		if (PasswordFlag == false)
	   	{
	  		StoreLCDInfo();
			clrLCDdpy();
	  		LCD_Menu = 25;
	  		LCD_Init = 1;
 			return(lcd_menu);
   	   	}
  		if(upd_dpy == 1)	
  		{
  		    upd_dpy = 0;
  		    for(i=0; i<=19; i++)
  		    {
  		    	LCD_Display[0][i] = ' ';
				LCD_Display[1][i] = LCD_Watchdog_info[0][i];
				LCD_Display[2][i] = LCD_Watchdog_info[1][i];
  		    	LCD_Display[3][i] = ' ';
  		    }
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
			if (LCD_Enter_PB == 0)
			{
				
	  		    for(i=0; i<=19; i++)
	  		    {
			  		LCD_Display[0][i] = ' ';
			  		LCD_Display[1][i] = ' ';
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
	  		    }
			}
  		    LCD_Enter_PB = 1;
	    	if(chk_ins() == 1)
			{ 			// Car must be on inspection
				while(1)
					;
	 		}
			else
			{
	  		    for(i=0; i<=19; i++)
	  		    {
			  		LCD_Display[1][i] = LCD_Watchdog_info[2][i];
			  		LCD_Display[2][i] = LCD_Watchdog_info[3][i];
	  		    }
			}
		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
 			upd_dpy = 1;
			menu_ptr = menu_ptr_ret;
 			return(lcd_menu);
 		}
	}
	if (menu_level == 4)
	{			// Reset Debug Variables
  		if(upd_dpy == 1)	
  		{
	    	upd_dpy = 0;
	    	for(i=0; i<=19; i++)
	    	{
  		    	LCD_Display[0][i] = ' ';
				LCD_Display[1][i] = LCD_Debug_Reset[0][i];
				LCD_Display[2][i] = LCD_Debug_Reset[1][i];
  		    	LCD_Display[3][i] = ' ';
	    	}
			debug1 = 0;
			debug2 = 0;
			debug3 = 0;
			debug4 = 0;
			debug5 = 0;
			debug6 = 0;
			debug7 = 0;
			debug8 = 0;
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
      		LCD_Mode_PB = 1;  
			menu_level = 0;
 			upd_dpy = 1;
 			menu_ptr = menu_ptr_ret;
			return(lcd_menu);
  		}
	}
	
	if (menu_level == 5)
	{      	  // Store Field Variables
		if (PasswordFlag == false)
	   	{
	  		StoreLCDInfo();
			clrLCDdpy();
	  		LCD_Menu = 25;
	  		LCD_Pointer = 25;
 			return(lcd_menu);
   	   	}

  		if (((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0)) || (mode_sel == 4))
  		{
	  	  	LCD_Mode_PB = 1;  
  			if (mode_sel != 0)
  			{
  				mode_sel = 0;
  				upd_dpy = 1;
  			}
  			else
  			{
				menu_level = 0;
	 			upd_dpy = 1;
				menu_ptr = menu_ptr_ret;
	 			return(lcd_menu);
  			}
  		}
  		
#if(Simulator == 0)
    	if(chk_ins() == 0)  // Car not on inspection
    	{
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_SD_Read_Write_info[0][i];
				LCD_Display[1][i] = LCD_SD_Read_Write_info[1][i];
				LCD_Display[2][i] = LCD_SD_Read_Write_info[2][i];
				LCD_Display[3][i] = LCD_SD_Read_Write_info[3][i];
			}
 			return(lcd_menu);
    	}
    	else
#endif
    	{
			if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
			{
			    LCD_UP_PB = 1;  // incriment
			    if (mode_sel < 2)
			    {
				    upd_dpy = 1;
				    menu_ptr--;
				    if(menu_ptr < 0)
					  menu_ptr = Last_SD_Menu;
				    
		  		    mode_sel = 0;
			    }
			    else if (mode_sel == 2)
			    	mode_sel = 3;
			    else
			    	mode_sel = 2;
			}

			if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
			{
			    LCD_DN_PB = 1;  // decriment
			    if (mode_sel < 2)
			    {
				    upd_dpy = 1;
				    menu_ptr++;
				    if(menu_ptr > Last_SD_Menu)
					  menu_ptr = 0;
				    
		  		    mode_sel = 0;
			    }
			    else if (mode_sel == 2)
			    	mode_sel = 3;
			    else
			    	mode_sel = 2;
			}
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	  		    LCD_Enter_PB = 1;
				upd_dpy = 0;
				if (mode_sel <= 2)
				{
					j = fvarstoSD(menu_ptr,(mode_sel == 2));
					if (j == 10)
						mode_sel = 2;
					else	
						mode_sel = 1;	
					for(i=0; i<=19; i++)
				  	{
  		    			LCD_Display[0][i] = getcaps(LCD_Software_Menu[4][i]);
					  	LCD_Display[1][i] = LCD_SD_Read_Write[menu_ptr][i];
					    LCD_Display[2][i] = LCD_SD_Read_Write_info[j+4][i];
			  			LCD_Display[3][i] = ' ';
					}
				}
				else
				{
					upd_dpy = 1;
					mode_sel = 4;
				}
	 		}
  		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
	  		line_ptr = menu_ptr % 3;
	  		start_ptr = menu_ptr - line_ptr;
	  	    for(i=0; i<=19; i++)
	  	    {
  		    	LCD_Display[0][i] = getcaps(LCD_Software_Menu[4][i]);
				LCD_Display[1][i] = LCD_SD_Read_Write[start_ptr][i];
				if ((start_ptr + 1) > Last_SD_Menu)
			  	{
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
			  	}
			  	else
			  	{
					LCD_Display[2][i] = LCD_SD_Read_Write[start_ptr+1][i];
					if ((start_ptr + 2) > Last_SD_Menu)
				  		LCD_Display[3][i] = ' ';
					else
						LCD_Display[3][i] = LCD_SD_Read_Write[start_ptr+2][i];
			  	}
	  	    }
			LCD_Display[line_ptr+1][0] = '>';		// show cursor
		}
		else if (mode_sel == 2)
			LCD_Display[2][17] = 'Y';
		else if (mode_sel == 3)
			LCD_Display[2][17] = 'N';

	}
  	
	if (menu_level == 6)
	{      	  // SD Card Status
		if (PasswordFlag == false)
	   	{
	  		StoreLCDInfo();
			clrLCDdpy();
	  		LCD_Menu = 25;
	  		LCD_Pointer = 25;
 			return(lcd_menu);
   	   	}

  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
	  		LCD_Mode_PB = 1;  
  			sd_error = 0;
  			if (mode_sel == 1)
  			{
  				mode_sel = 0;
  				upd_dpy = 1;
  			}
  			else
  			{
				menu_level = 0;
	 			upd_dpy = 1;
				menu_ptr = menu_ptr_ret;
	 			return(lcd_menu);
  			}
  		}
  			
#if(Simulator == 0)
    	if(chk_ins() == 0)  // Car not on inspection
    	{
  		    for(i=0; i<=19; i++)
  		    {
 			    LCD_Display[0][i] = ' ';
			  	LCD_Display[1][i] = getcaps(LCD_Software_Menu[5][i]);
			  	LCD_Display[2][i] = LCD_SD_Card_Status[2][i];
   		   		LCD_Display[3][i] = ' ';
			}
			upd_dpy = 1;	
    	}
    	else

#endif
    	{
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	  		    LCD_Enter_PB = 1;
  				mode_sel = 1;
				sd_error = Load_Store_Program(0);
				if (sd_error == 0)
					sd_init = 1;
				else
					sd_init = 0;
				if (sd_error == 0)
				{
		  		    for(i=0; i<=19; i++)
		  		    {
 			    		LCD_Display[0][i] = ' ';
				  		LCD_Display[1][i] = getcaps(LCD_Software_Menu[5][i]);
				  		LCD_Display[2][i] = LCD_SD_Card_Status[1][i];
   		 		 	  	LCD_Display[3][i] = ' ';
		  		    }
			  	    if (sd_init == 1)
			  	    	LCD_Display[2][5] = '1';
			  	    if (sdhc == 1)
			  	    	LCD_Display[2][10] = '1';
			  	    if (sdvs == 1)
			  	    	LCD_Display[2][18] = '1';
				}
				else
	  			{
				    for(i=0; i<=19; i++)
				    {
				  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[5][i]);
						LCD_Display[1][i] = LCD_SD_Error[0][i];
					  	LCD_Display[2][i] = LCD_SD_Error[sd_error][i];
   		 		   		LCD_Display[3][i] = ' ';
				    }
	  			}
	  		}
	  		if (upd_dpy == 1)
	  		{
	  			upd_dpy = 0;
	  		    for(i=0; i<=19; i++)
	  		    {
 			    	LCD_Display[0][i] = ' ';
					LCD_Display[1][i] = getcaps(LCD_Software_Menu[5][i]);
					LCD_Display[2][i] = LCD_SD_Card_Status[0][i];
   		 		   	LCD_Display[3][i] = ' ';
	  		    }
	  		}
	    }
	    
	}
	
	if (menu_level == 7)
	{			// Set View WiFi Settings
		menu_level = wifi_submenus(menu_level);
		if (menu_level == 0)
		{
			menu_level = 0;
			menu_ptr = menu_ptr_ret;
 			upd_dpy = 1;
		}
	}
	
	
	if (menu_level == 8)
	{			//  Change Floor PI
	
				// mode_sel = 0		View all floor PI's
				// mode_sel = 1		Select Floor Edit Table
				// mode_sel = 2		Move to next floor to edit
				// mode_sel = 3		Modify Ones Digit on PI
				// mode_sel = 4		Modify Tens Digit on PI
				// mode_sel = 5		Update PI Table
				
		if (PasswordFlag == false)
	   	{
	  		StoreLCDInfo();
			clrLCDdpy();
	  		LCD_Menu = 25;
	  		LCD_Pointer = 25;
 			return(lcd_menu);
   	   	}

	 	if(LCD_Sub_Init == 1)
			table_upd = 0;
  	
  	
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
      		LCD_Mode_PB = 1;  
 			upd_dpy = 1;
  			if (mode_sel == 0)
  			{
  				if (table_upd == 1)
  					mode_sel = 5;
  				else
  				{
					menu_level = 0;
					menu_ptr = menu_ptr_ret;
		 			return(lcd_menu);
  				}
  			}
  			else if (mode_sel == 1)
  				mode_sel = 0;
  			else if (mode_sel == 2)
  				mode_sel = 1;
		  	else if (mode_sel == 3)
		  	{
				tflmrk[floor_ptr][char_digit_ix] = temp_char[char_digit_ix];
		      	if (temp_char[char_digit_ix] == ' ')
		   			LCD_Flash_TMP[char_digit_ix] = '_';
		  		else
		  		   	LCD_Flash_TMP[char_digit_ix] = temp_char[char_digit_ix];
		  		
		  		// Special case to switch to the next character (only way to get there without changing the current character)
			  	char_ix = 0;
			  	char_digit_ix = 0;
			   	temp_char[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];

			   	char_ptr = char_ptr_tbl[table_ptr];
			   	tflmrk[floor_ptr][char_digit_ix] = char_ptr[char_ix];
			   	if (tflmrk[floor_ptr][char_digit_ix] == ' ')
					LCD_Flash_TMP[char_digit_ix] = '_';
			   	else
			   		LCD_Flash_TMP[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];
		  		mode_sel = 4;
		  	}
		  	else if (mode_sel == 4)
		  	{
		  		mode_sel = 2;
				tflmrk[floor_ptr][char_digit_ix] = temp_char[char_digit_ix];
		      	if (temp_char[char_digit_ix] == ' ')
		   			LCD_Flash_TMP[char_digit_ix] = '_';
		  		else
		  		   	LCD_Flash_TMP[char_digit_ix] = temp_char[char_digit_ix];
		  	}
  			else if (mode_sel == 5)
  			{
  				table_upd = 0;
				menu_level = 0;
				menu_ptr = menu_ptr_ret;
	 			return(lcd_menu);
  			}
  		}

#if(Simulator == 0)
    	if(chk_ins() == 0)  // Car not on inspection
    	{
    		table_upd = 0;
    		mode_sel = 0;
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_SD_Read_Write_info[0][i];
				LCD_Display[1][i] = LCD_SD_Read_Write_info[1][i];
				LCD_Display[2][i] = getcaps(LCD_Software_Menu[7][i]);
				LCD_Display[3][i] = ' ';
			}
 			return(lcd_menu);
    	}
    	else
#endif
		{

	  		if(LCD_Sub_Init == 1)	
	  		{
		    	LCD_Sub_Init = 0;
		    	file_read_ok = 0;
		    	yes_no = 0;
		    	floor_ptr = cons[bottomf];
		    	table_ptr = 0;
		    	mode_sel = 0;
		    	table_upd = 0;
  		    	char_ix = 0;
  		    	char_digit_ix = 1;
				j = fvarstoSD(15,1);	// read cons.dat file into MRAM
				if (j != 2)
				{
					for(i=0; i<=19; i++)
				 	{
  		    			LCD_Display[0][i] = getcaps(LCD_Software_Menu[7][i]);
					  	LCD_Display[1][i] = LCD_SD_Read_Write[15][i];
					    LCD_Display[2][i] = LCD_SD_Read_Write_info[j+4][i];
			  			LCD_Display[3][i] = LCD_Mod_Fl_Label[1][i]; 	// hit mode to exit
					}
				}
				else 
				{
					j = fvarstoSD(16,1);	// read io.dat file into MRAM
					if (j != 2)
					{
						for(i=0; i<=19; i++)
					 	{
	  		    			LCD_Display[0][i] = getcaps(LCD_Software_Menu[7][i]);
						  	LCD_Display[1][i] = LCD_SD_Read_Write[16][i];
						    LCD_Display[2][i] = LCD_SD_Read_Write_info[j+4][i];
				  			LCD_Display[3][i] = LCD_Mod_Fl_Label[1][i]; 	// hit mode to exit
						}
					}
					else
					{
						if (mram_get_fl_pi(tflmrk,cons[topf]) == 1)
							file_read_ok = 1;
							file_read_ok = 1;
					}
				}
	  		}
	  		
			if (mode_sel == 5)
			{		// special case to update PI and write file before exiting
				if (file_read_ok == 0)
				{
					table_upd = 0;	// just in case something gets screwed up allow mode button to exit
					mode_sel = 0;
				}
				
				if(upd_dpy == 1)
				{
					upd_dpy = 0;
		  		    for(i=0; i<=19; i++)
		  		    {
	  		    		LCD_Display[0][i] = ' ';
						LCD_Display[1][i] = LCD_Mod_Fl_Label[2][i];
						LCD_Display[2][i] = LCD_Mod_Fl_Label[3][i];
						LCD_Display[3][i] = ' ';
					}
					
					if (yes_no == 1)
					{
						LCD_Display[2][17] = 'Y';
						LCD_Display[2][18] = 'e';
						LCD_Display[2][19] = 's';
					}
					else
					{
						LCD_Display[2][17] = 'N';
						LCD_Display[2][18] = 'o';
						LCD_Display[2][19] = ' ';
					}

			  	}

				if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
				{
				    LCD_UP_PB = 1;  // incriment
			  	    upd_dpy = 1;
				    if (yes_no == 0)
				    	yes_no = 1;
				    else
				    	yes_no = 0;
				}
				if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
				{
				    LCD_DN_PB = 1;  // decriment
			  	    upd_dpy = 1;
				    if (yes_no == 1)
				    	yes_no = 0;
				    else
				    	yes_no = 1;
				}
				if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
				{
			  	    LCD_Enter_PB = 1;
					table_upd = 0;
					mode_sel = 0;
					if (yes_no == 1)
					{
			  			mram_write_floor_pi(tflmrk,cons[topf]);	
			  			Replace_Floor_Marking(tflmrk);
						j = fvarstoSD(17,1);	// write MRAM to cons.dat file 
						j = fvarstoSD(18,1);	// write MRAM to io.dat file 
						if (j == 1)
						{
				  		    for(i=0; i<=19; i++)
				  		    {
			  		    		LCD_Display[0][i] = LCD_Mod_Fl_Label[4][i];
								LCD_Display[1][i] = LCD_Mod_Fl_Label[5][i];
								LCD_Display[2][i] = LCD_Mod_Fl_Label[1][i];
								LCD_Display[3][i] = ' ';
							}
						}
						else
						{
							for(i=0; i<=19; i++)
						 	{
		  		    			LCD_Display[0][i] = getcaps(LCD_Software_Menu[7][i]);
							  	LCD_Display[1][i] = LCD_SD_Read_Write[16][i];
							    LCD_Display[2][i] = LCD_SD_Read_Write_info[j+4][i];
					  			LCD_Display[3][i] = LCD_Mod_Fl_Label[1][i]; 	// hit mode to exit
							}
						}
					}
					else
					{
			  		    for(i=0; i<=19; i++)
			  		    {
		  		    		LCD_Display[0][i] = LCD_Mod_Fl_Label[4][i];
							LCD_Display[1][i] = LCD_Mod_Fl_Label[6][i];
							LCD_Display[2][i] = LCD_Mod_Fl_Label[1][i];
							LCD_Display[3][i] = ' ';
						}
					}
			  	}
			}
			else
			{
				// Change the PI 
				
				if (file_read_ok == 1)
				{
					
					if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
					{
					    LCD_UP_PB = 1;  // incriment
					    if ((mode_sel == 3) || (mode_sel == 4))
					    {
						    upd_dpy = 1;

					    	char_ix ++;
					    	if (char_ix > tbl_len[table_ptr])
					    		char_ix = 0;
					    	
			  		    	char_ptr = char_ptr_tbl[table_ptr];
			  		    	tflmrk[floor_ptr][char_digit_ix] = char_ptr[char_ix];
			  		    	if (tflmrk[floor_ptr][char_digit_ix] == ' ')
				 	   			LCD_Flash_TMP[char_digit_ix] = '_';
			  		    	else
			  		    		LCD_Flash_TMP[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];
					    }
					    else if ((mode_sel == 0) || (mode_sel == 2))
					    {
						    upd_dpy = 1;
						    floor_ptr--;
						    if(floor_ptr < cons[bottomf])
							  floor_ptr = cons[topf];
					    }
					    else if (mode_sel == 1)
					    {
						    upd_dpy = 1;
					    	table_ptr++;
					    	if (table_ptr > 2)
					    		table_ptr = 0;
					    }
					}

					if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
					{
					    LCD_DN_PB = 1;  // decriment
					    if ((mode_sel == 3) || (mode_sel == 4))
					    {
						    upd_dpy = 1;

					    	char_ix --;
					    	if (char_ix < 0)
					    		char_ix = tbl_len[table_ptr];
					    	
			  		    	char_ptr = char_ptr_tbl[table_ptr];
			  		    	tflmrk[floor_ptr][char_digit_ix] = char_ptr[char_ix];
			  		    	if (tflmrk[floor_ptr][char_digit_ix] == ' ')
				 	   			LCD_Flash_TMP[char_digit_ix] = '_';
			  		    	else
			  		    		LCD_Flash_TMP[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];
					    }
					    else if ((mode_sel == 0) || (mode_sel == 2))
					    {
						    upd_dpy = 1;
						    floor_ptr++;
						    if(floor_ptr > cons[topf])
							  floor_ptr = cons[bottomf];
						    
					    }
					    else if (mode_sel == 1)
						{
						    upd_dpy = 1;
							table_ptr--;
						    if(table_ptr < 0)
							  table_ptr = 2;
						}
					}
					
			  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
			  		{
			  		    LCD_Enter_PB = 1;
			 			upd_dpy = 1;
			  		    if (mode_sel == 0)
			  		    	mode_sel = 1;	// Modify Table type
			  		    else if (mode_sel == 1)
			  		    	mode_sel = 2;	// Change to different floor
			  		    else if (mode_sel == 2)
			  		    {					
			  		    	char_ix = 0;
			  		    	char_digit_ix = 1;
			  		    	temp_char[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];
			  		    	
			  		    	char_ptr = char_ptr_tbl[table_ptr];
			  		    	tflmrk[floor_ptr][char_digit_ix] = char_ptr[char_ix];
			  		    	if (tflmrk[floor_ptr][char_digit_ix] == ' ')
				 	   			LCD_Flash_TMP[char_digit_ix] = '_';
			  		    	else
			  		    		LCD_Flash_TMP[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];
			  		    	
					    	table_upd = 1;

			  		    	mode_sel = 3;	// Modify Ones Digit on PI
			  		    }
			  		    else if (mode_sel == 3)
			  		    {			
			  		    	char_ix = 0;
			  		    	char_digit_ix = 0;
			  		    	temp_char[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];

			  		    	char_ptr = char_ptr_tbl[table_ptr];
			  		    	tflmrk[floor_ptr][char_digit_ix] = char_ptr[char_ix];
			  		    	if (tflmrk[floor_ptr][char_digit_ix] == ' ')
				 	   			LCD_Flash_TMP[char_digit_ix] = '_';
			  		    	else
			  		    		LCD_Flash_TMP[char_digit_ix] = tflmrk[floor_ptr][char_digit_ix];
			  		    	
					    	table_upd = 1;

			  		    	mode_sel = 4;	// Modify Tens Digit on PI
			  		    }
			  		    else if (mode_sel == 4)
			  		    	mode_sel = 2;	// Go back to change to different floors
			  		}

					line_ptr = (floor_ptr-1) % 3;
					start_ptr = floor_ptr - line_ptr;
					
					if(upd_dpy == 1)
					{
						upd_dpy = 0;
				  	    for(i=0; i<=19; i++)
				  	    {
				  			LCD_Display[0][i] = LCD_Mod_Fl_Label[0][i];
							LCD_Display[1][i] = ' ';
					  		LCD_Display[2][i] = ' ';
					  		LCD_Display[3][i] = ' ';
					  		if (table_ptr == 0)
					  		{
					  			LCD_Display[1][i] = LCD_Fl_Label[0][i];
					  			LCD_Display[2][i] = LCD_Fl_Label[1][i];
					  			LCD_Display[3][i] = LCD_Fl_Label[2][i];
					  		}
					  		else if (table_ptr == 1)
					  		{
					  			LCD_Display[1][i] = LCD_Fl_Label[3][i];
					  			LCD_Display[2][i] = LCD_Fl_Label[4][i];
					  		}
					  		else if (table_ptr == 2)
					  		{
					  			LCD_Display[1][i] = LCD_Fl_Label[5][i];
					  			LCD_Display[2][i] = LCD_Fl_Label[6][i];
					  		}
				  	    }
				  	    
				  	    tflr_ptr[0] = start_ptr;
				  	    tflr_ptr[1] = start_ptr+1;
				  	    tflr_ptr[2] = start_ptr+2;
				  	    if ((mode_sel == 3) || (mode_sel == 4))
				  	    {
				  	    	tflr_ptr[line_ptr] = floor_ptr;
				  	    }
						sprintf(LCD_String,"%2i",start_ptr);
					  	LCD_Display[1][1] = LCD_String[0];
					  	LCD_Display[1][2] = LCD_String[1];
						LCD_Display[1][17] = tflmrk[tflr_ptr[0]][0];
						LCD_Display[1][18] = tflmrk[tflr_ptr[0]][1];
						if ((start_ptr + 1) <= cons[topf])
						{
							sprintf(LCD_String,"%2i",start_ptr+1);
						  	LCD_Display[2][1] = LCD_String[0];
						  	LCD_Display[2][2] = LCD_String[1];
							LCD_Display[2][17] = tflmrk[tflr_ptr[1]][0];
							LCD_Display[2][18] = tflmrk[tflr_ptr[1]][1];
							if ((start_ptr + 2) <= cons[topf])
							{
								sprintf(LCD_String,"%2i",start_ptr+2);
							  	LCD_Display[3][1] = LCD_String[0];
							  	LCD_Display[3][2] = LCD_String[1];
								LCD_Display[3][17] = tflmrk[tflr_ptr[2]][0];
								LCD_Display[3][18] = tflmrk[tflr_ptr[2]][1];
							}
						}
						if (mode_sel == 0)
							LCD_Display[line_ptr+1][0] = '>';		// show cursor
						else if (mode_sel == 1)
							LCD_Display[1][6] = '>';		// show cursor
						else if (mode_sel >= 2)
							LCD_Display[line_ptr+1][16] = '>';		// show cursor
					}
					flash_digit(LCD_Flash_TMP[char_digit_ix],line_ptr+1,flash_column[char_digit_ix],(mode_sel>2));
				}
			}
		}
	}


	if (menu_level == 9)
	{			// Set Trace Condition
		menu_level = trace_trigger_menu(menu_level);
		if (menu_level == 0)
		{
			menu_level = 0;
 			upd_dpy = 1;
			menu_ptr = menu_ptr_ret;
		}
	}
	
	if (menu_level == 10)
	{			// Set Trace Condition
		menu_level = Send_NTS_Floors(menu_level);
		if (menu_level == 0)
		{
			menu_level = 0;
 			upd_dpy = 1;
			menu_ptr = menu_ptr_ret;
		}
	}
	return(lcd_menu);
}

/* 

Revision History:

	9/15/17 v8.0.10 mhd		1. Moved software utilitis from lcd.c to software_utils.c.
							2. Added menu_level 8 to allow the user to change the PI floor labels from the LCD interface.

*/
