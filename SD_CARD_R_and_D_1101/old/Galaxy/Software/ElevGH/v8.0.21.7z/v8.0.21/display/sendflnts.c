// Send Floor table to NTS-APS Selector
#define d_SENDFLNTS 1
#include "global.h"



static  const char LCD_Send_NTS_Fl_msg[14][21] = {
  " Car Must be placed ",	 // 0
  "    on Inspection   ",	 // 1
  " Hit Enter to Start ",	 // 2
  " Sending Floor Table",	 // 3
  " Hit Mode to Abord  ",	 // 4
  "  Transfer Aborted  ",	 // 5
  "  Transfer Complete ",	 // 6
  "Er:Command Different",	 // 7
  "Er:Count Different  ",	 // 8
  "Er:Offset Different ",	 // 9
  "Er:Floor Different  ",	 // 10
  "Er:Floor Index      ",	 // 11
  "Er:Comm Time-out    ",	 // 12
};

int16 Send_NTS_Floors (int16 lcd_menu);
int16 send_nts_fl(void);

#define nts_prog_cmd_WR   		0x01
#define nts_prog_cmd_CHAN_B 	0x02
#define nts_prog_cmd_BOTTOMF 	0x04
#define nts_prog_cmd_TOPF 		0x08

uint8 NTS_FL_prog_cmd;
uint8 NTS_FL_prog_chan_off;
uint8 NTS_FL_prog_floor;
uint32 NTS_FL_prog_count_1;
uint32 NTS_FL_prog_count_2;
uint32 NTS_FL_prog_count_3;
uint8 NTS_FL_prog_ret_rcvd;
uint8 NTS_FL_prog_ret_cmd_1;
uint8 NTS_FL_prog_ret_cmd_2;
uint8 NTS_FL_prog_ret_chan_off;
uint8 NTS_FL_prog_ret_floor;
uint32 NTS_FL_prog_ret_count_1;
uint32 NTS_FL_prog_ret_count_2;
uint32 NTS_FL_prog_ret_count_3;

int16 msg_dpy = 0;
int16 nts_prog_state = 0;
int16 nts_prog_dpy_status = 0;
int16 NTS_prog_fl = 1;
int16 car_fl = 1;
int16 num_valid_flrs = 2;
int16 send_flrs = 0;
int16 time_out_cnt = 0;
int32 count_diff = 0;

#define m_sending_P1 2
#define m_complete 6
#define m_cmd_diff 7
#define m_prog_fl_count_diff 8
#define m_prog_chan_off_diff 9
#define m_prog_fl_diff 10
#define m_fl_ix 11
#define m_time_out 12

static union {
		uint8 b[4];			// byte: char 0 - 3
		uint16 w[2];
		uint32 dw;			// double word: int
	}uiu;					// unsigned integer union


int16 send_nts_fl(void)
{
	
	switch(nts_prog_state)
	{
		case 0: //	Initialize for first pass
			NTS_prog_fl = 1;
			car_fl = 1;
			num_valid_flrs = hwl_num_floors;
			nts_prog_state = 1;
			timers[tnts_aps_ui] = 0;
			time_out_cnt = 0;
			confirm_nts_fls = 0;
			break;
			
		case 1:	// Send floors one at a time
			NTS_FL_prog_floor = (uint8)NTS_prog_fl;
			if (NTS_FL_prog_floor <= num_valid_flrs)
			{
				car_fl = get_valid_fl(car_fl, 1);		// start from 1 and go up
				if (sel_can.online == 1)
				{
					if (sel_can.ver == 2)
					{
						if (sel_can.Error_Warning.R == 0)
						{
							count_diff = sel_can.pos_cnt_A - sel_can.pos_cnt_B;
							if (count_diff < 140)
								NTS_FL_prog_chan_off = (uint8)count_diff;
							else
								NTS_FL_prog_chan_off = 130;
						}
						else
							NTS_FL_prog_chan_off = 130;
					}
					else if (sel_can.ver == 1)
						NTS_FL_prog_chan_off = 90;
					else if (sel_can.ver == 3)
						NTS_FL_prog_chan_off = 90;
				}
				else
					NTS_FL_prog_chan_off = 130;
				
				NTS_FL_prog_cmd = nts_prog_cmd_WR;
				NTS_FL_prog_count_1 = DPP_Floor_Pos[car_fl];
				if ((car_fl+1) <= cons[topf])
					NTS_FL_prog_count_2 = DPP_Floor_Pos[car_fl+1];
				else
					NTS_FL_prog_count_2 = 0;
				if ((car_fl+2) <= cons[topf])
					NTS_FL_prog_count_3 = DPP_Floor_Pos[car_fl+2];
				else
					NTS_FL_prog_count_3 = 0;
				
				put_nts_spi_msg_req(9);
				nts_prog_state = 2;		// wait for response
				timers[tnts_aps_ui] = 0;
				NTS_FL_prog_ret_rcvd = 0;
			}
			else
			{
				nts_prog_state = 4;
				msg_dpy = m_fl_ix;
			}
			break;
			
		case 2:		// wait for response
			if (timers[tnts_aps_ui] < 20)		// two seconds
			{
				if (NTS_FL_prog_ret_rcvd == 1)
				{
					msg_dpy = 0;
					if ((NTS_FL_prog_ret_cmd_1 != NTS_FL_prog_cmd) || (NTS_FL_prog_ret_cmd_1 != NTS_FL_prog_ret_cmd_2))
						msg_dpy = m_cmd_diff;

					if (NTS_FL_prog_ret_floor != NTS_FL_prog_floor)
						msg_dpy = m_prog_fl_diff;
					
					if (NTS_FL_prog_ret_chan_off != NTS_FL_prog_chan_off)
						msg_dpy = m_prog_chan_off_diff;
						
					if ((NTS_FL_prog_ret_count_1 != NTS_FL_prog_count_1))
						msg_dpy = m_prog_fl_count_diff;
					if ((NTS_FL_prog_count_2 != 0) && (NTS_FL_prog_ret_count_2 != NTS_FL_prog_count_2))
						msg_dpy = m_prog_fl_count_diff;
					if ((NTS_FL_prog_count_3 != 0) && (NTS_FL_prog_ret_count_3 != NTS_FL_prog_count_3))
						msg_dpy = m_prog_fl_count_diff;
					
					NTS_prog_fl+=3;		// increment count after data received (get three floor counts at a time)
					car_fl+=3;
					time_out_cnt = 0;

					if (msg_dpy != 0)
						nts_prog_state = 6;
					else if (NTS_prog_fl > num_valid_flrs)
					{
						timers[tnts_aps_ui] = 0;
						nts_prog_state = 3;
					}
					else
					{
						timers[tnts_aps_ui] = 0;
						nts_prog_state = 1;
					}
				}
			}
			else
			{
				time_out_cnt++;
				if (time_out_cnt <= 3)
				{
					nts_prog_state = 1;		// try again
					timers[tnts_aps_ui] = 0; 
				}
				else
				{
					nts_prog_state = 4;
					msg_dpy = m_time_out;
					NTS_FL_prog_cmd = 0;
				}
			}
			break;
			
		case 3:		// Finished Upload
			msg_dpy = m_complete;
			NTS_FL_prog_cmd = 0;
			nts_prog_state = 0;
			// confirm for controller tester
			confirm_nts_fls = 1;
			break;
		
		case 4:		// Fault during upload
			nts_prog_state = 0;
			NTS_FL_prog_cmd = 0;
			confirm_nts_fls = 2;
			break;
			
		default:
			nts_prog_state = 0;
			NTS_FL_prog_cmd = 0;
			break;
		

	}
	return nts_prog_state;
}


int16 Send_NTS_Floors (int16 lcd_menu)
{
	int16 i;
	int16 valid_trigger = 0;
	static int16 upd_dpy;
	static int16 mode_sel;
		
	
	if (PasswordFlag == false)
   	{
  		StoreLCDInfo();
		clrLCDdpy();
  		LCD_Menu = 25;
  		LCD_Init = 1;
		return(lcd_menu);
	}

	if(LCD_Sub_Init == 1)	
	{
		LCD_Sub_Init = 0;
		send_flrs = 0;
	    mode_sel = 0;
		nts_prog_state = 0;
		nts_prog_dpy_status = 0;
		hwl_num_floors = hwl_number_valid_fl();
		hwl_num_limits = 1;
		hwl_top_speed = cons[speed];

	}
	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	{
	    LCD_UP_PB = 1;  // incriment
	}

	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	{
	    LCD_DN_PB = 1;  // decriment
	}


	if(chk_ins() == 0)  
	{ 
		nts_prog_dpy_status = 0;		
		send_flrs = 0;
	    for(i=0; i<=19; i++)
	    {
	  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
			LCD_Display[1][i] = LCD_Send_NTS_Fl_msg[0][i];
			LCD_Display[2][i] = LCD_Send_NTS_Fl_msg[1][i];
			LCD_Display[3][i] = ' ';
	    }
	}
	else 
	{
		if ((send_flrs == 0) && (nts_prog_dpy_status == 0))
		{
	 	    for(i=0; i<=19; i++)
		    {
		  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
		  		LCD_Display[1][i] = LCD_Send_NTS_Fl_msg[2][i];
				LCD_Display[2][i] = ' ';
				LCD_Display[3][i] = ' ';
		    }
		}
	
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		    if (send_flrs == 0)
		    {

				upd_dpy = 0;
				if (hwl_num_floors != nts_fvars[nts_fvnum_floors])
				{
					nts_prog_dpy_status = 1;
		  		    for(i=0; i<=19; i++)
		  		    {
				  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
						LCD_Display[1][i] = Learn_Hw_CED[4][i];		// NTS Parameter error
						LCD_Display[2][i] = Learn_Hw_CED[5][i];		// Invalid number of floors
						LCD_Display[3][i] = ' ';
		  		    }
				}
/*				else if (hwl_num_limits != nts_fvars[nts_fvnum_limits])
				{
					nts_prog_dpy_status = 1;
		  		    for(i=0; i<=19; i++)
		  		    {
				  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
						LCD_Display[1][i] = Learn_Hw_CED[4][i];		// NTS Parameter error
						LCD_Display[2][i] = Learn_Hw_CED[6][i];		// Invalid number of limits
						LCD_Display[3][i] = ' ';
		  		    }
				} */
				else if (hwl_top_speed != nts_fvars[nts_fvtop_speed])
				{
					nts_prog_dpy_status = 1;
		  		    for(i=0; i<=19; i++)
		  		    {
				  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
						LCD_Display[1][i] = Learn_Hw_CED[4][i];		// NTS Parameter error
						LCD_Display[2][i] = Learn_Hw_CED[7][i];		// Invalid top speed
						LCD_Display[3][i] = ' ';
		  		    }
				}
		    	else if(chk_ins() == 1)  
				{ 	
					send_flrs = 1;	
					nts_prog_dpy_status = 2;
		  		    for(i=0; i<=19; i++)
		  		    {
				  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
						LCD_Display[1][i] = LCD_Send_NTS_Fl_msg[3][i];		// transferring floor data
						LCD_Display[2][i] = LCD_Send_NTS_Fl_msg[4][i];		// hit mode to abort
						LCD_Display[3][i] = ' ';
		  		    }
				}
		    }
		}
	}
	
	if ((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	{
  	  	LCD_Mode_PB = 1;  
		if (send_flrs != 0)
		{
			send_flrs = 0;
			nts_prog_state = 0;
			upd_dpy = 0;
			nts_prog_dpy_status = 3;
  		    for(i=0; i<=19; i++)
  		    {
		  		LCD_Display[0][i] = getcaps(LCD_Software_Menu[9][i]);
		  		LCD_Display[1][i] = LCD_Send_NTS_Fl_msg[5][i];
  				LCD_Display[2][i] = ' ';
				LCD_Display[3][i] = ' ';
		    }
		}
		else
		{
			nts_prog_dpy_status = 0;
			lcd_menu = 0;
	  		return(lcd_menu);
		}
	}

	if (send_flrs == 1)
	{
		if (send_nts_fl() == 0)
			send_flrs = 0;
		
		if (msg_dpy != 0)
		{
			nts_prog_dpy_status = 4;
			upd_dpy = 1;
		}
	}


	if(upd_dpy == 1)
	{
		upd_dpy = 0;
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Software_Menu[9][i];
		  	LCD_Display[1][i] = LCD_Send_NTS_Fl_msg[msg_dpy][i];
  			LCD_Display[2][i] = ' ';
			LCD_Display[3][i] = ' ';
	    }
	    msg_dpy = 0;
	}
	return(lcd_menu);
}

/* 

Revision History:


11/17/17 v8.0.19 mhd	1. Deleted check for NTS number of limits because it is always 1.

*/
