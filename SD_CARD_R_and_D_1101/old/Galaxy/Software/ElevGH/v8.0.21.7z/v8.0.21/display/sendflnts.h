
#define nts_prog_cmd_WR   		0x01
#define nts_prog_cmd_CHAN_B 	0x02
#define nts_prog_cmd_BOTTOMF 	0x04
#define nts_prog_cmd_TOPF 		0x08

extern uint8 NTS_FL_prog_cmd;
extern uint8 NTS_FL_prog_chan_off;
extern uint8 NTS_FL_prog_floor;
extern uint32 NTS_FL_prog_count_1;
extern uint32 NTS_FL_prog_count_2;
extern uint32 NTS_FL_prog_count_3;
extern uint8 NTS_FL_prog_ret_rcvd;
extern uint8 NTS_FL_prog_ret_cmd_1;
extern uint8 NTS_FL_prog_ret_cmd_2;
extern uint8 NTS_FL_prog_ret_chan_off;
extern uint8 NTS_FL_prog_ret_floor;
extern uint32 NTS_FL_prog_ret_count_1;
extern uint32 NTS_FL_prog_ret_count_2;
extern uint32 NTS_FL_prog_ret_count_3;

int16 Send_NTS_Floors (int16 lcd_menu);
int16 send_nts_fl(void);
