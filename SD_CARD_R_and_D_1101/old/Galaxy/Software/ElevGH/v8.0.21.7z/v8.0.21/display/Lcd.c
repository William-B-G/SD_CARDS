
//  All LCD Files 1.14

#define d_LCDDPY 1
#include "global.h"

#define ServiceTimer 1

// Prototypes of all functions in lcd.cpp
void init_LCD(void );
void reinit_LCD(void);
void Refresh_LCD(void );
void write_display(char *s, int16 row, int16 col);
void clrLCDdpy(void);
int16 set_date_and_time (int16 lcd_menu);
int16 adjust_field_variables(int16 lcd_menu);
int16 job_statistics(int16 lcd_menu);
int16 inputs_and_outputs(int16 lcd_menu);		  
int16 setup_car_and_hall_calls (int16 lcd_menu);
int16 run_elevator_status (int16 lcd_menu);
int16 view_fault_log (int16 lcd_menu);
int16 display_hoistway_floor_table (int16 lcd_menu);
int16 set_service_timers (int16 lcd_menu);
int16 cc_pb_security (int16 lcd_menu);
int16 adjust_lcd_display (int16 lcd_menu);
int16 password (int16 lcd_menu);
int16 display_immediate_fault(int16 lcd_menu);
void StoreLCDInfo(void);
void ReturnLCDMenu(void);
void write_LCD (void);
int16 display_hoistway(int16 lcd_menu);
int16 display_short_floor_sd(int16 lcd_menu);
int16 display_dz_off(int16 lcd_menu);
int16 display_cpu_limits(int16 lcd_menu);
int16 dpy_aps_valid_fl_table(int16 lcd_menu);
void Display_Var_Label(int16 menu, int16 fv_index, int16 var);
void Elevator_Status_Init (int16 Init_Flag);
void Elevator_Service (struct Fault *ptr);
void Elevator_Status (int16 Status_Dpy, struct Fault *ptr);
char getcaps (char c);
void Service_Timers (void);
void clear_timer(int16 Timer);
void copy_timer(int16 timer_number, int16 Timer_Ix_1, int16 Timer_Ix_2);
void get_month_day_timer(int16 timer_number,int16 Timer_Ix);
void set_month_day_timer(int16 timer_number,int16 Timer_Ix);
void get_dow_timer(int16 timer_number,int16 Timer_Ix);
void set_dow_timer(int16 timer_number,int16 Timer_Ix);
void fault_display (int16 fault_line, int16 flt_ix, int16 dpy_ix);
int16 set_adj_digit (int32 max,int16 digit,int16 num_digits);
void adjust_variable (int16 *pvar, int16 max, int16 min, int16 inc, int16 digit, int16 deci);
void adjust_variable_32 (int32 *varptr, int32 max, int32 min, int32 inc, int16 digit);
void flash_digit (char dchar, int16 row, int16 col, int16 enable);
void display_variable(int16 row, int16 col, int16 digit, int16 lcd_par, int16 flash);
void display_variable_11_digits(int16 row, int16 col, int16 digit, int32 lcd_par, int16 flash);
int16 rdLCDio(int16 bitloc);
void display_io_name (int16 ioloc);
void display_io_value (int16 ioloc, struct Fault *ptr);
int16 get_device_name_ix(int16 fault_port,int16 device);

extern int16 safe(void);

extern void dog_ints_off(void);
extern void dog_ints_on(void);
extern void keybrd_restore (void);
extern void keybrd_init(void);
extern void rotate_io_bd (int16 dir);
extern struct Fault S_Trace[max_trace_ix + 1];

int16 test_data[20] = 
{
	0x1122,0x3344,0x5566,0x7788,0x7900,
	0x1234,0x5678,0x0910,0x1112,0x1314,
	0x1516,0x1718,0x1920,0x2122,0x2324,
	0x2526,0x2728,0x2930,0x3132,0x3334
};


uint8 upd_row_0 = 0;
uint8 upd_row_1 = 0;

// Trace variables
int16 trace_dpy_ix = 0;
int16 next_trace = 0;
int8 set_dpy_ix = 0;
int8 trig_dpy_ix = 0;
int8 end_dpy_ix = 0;
int16 trace_dpy_offset = 0;
int16 dpy_offset_ix = 0;
int16 Trace_ix_dpy = 0;

// varaibales for the LCD Display

int16 LCD_Menu = 0;
int16 LCD_Pointer = 0;
int16 LCD_Upd_Dpy = 0;
int16 LCD_Init = 0;
int16 LCD_Sub_Init = 0;


char LCD_Display[4][21];
char LCD_Display_old[4][21];
int16 LCD_Cur_Pos = 0;
int16 LCD_Line = 0;
int16 LCD_UP_PB = 1;
int16 LCD_DN_PB = 1;
int16 LCD_Mode_PB = 1;
int16 LCD_Enter_PB = 1;
int16 LCD_Flash = 1;
int16 LCD_Old_Flash = 1;
int8 LCD_Month;
int16 LCD_Year;
int8 LCD_Day;
int8 LCD_Minute;
int8 LCD_Hour;
char LCD_String[30];
char LCD_Time_Date[24];
char LCD_Flash_TMP[6];
int16 LCD_Dig_Point=0;
int16 LCD_Dig_Loc=0;
int16 LCD_ver = 0;
int16 LCD_rev = 0;


unsigned char lcd_data[3]={0,0,0};
#define c_lcd_dbn_cnt 2

const uint16 bittbl[16] = {(uint16)0x01,(uint16)0x02,(uint16)0x04,(uint16)0x08,(uint16)0x10,(uint16)0x20,(uint16)0x40,(uint16)0x80,
							(uint16)0x100,(uint16)0x200,(uint16)0x400,(uint16)0x800,(uint16)0x1000,(uint16)0x2000,(uint16)0x4000,(uint16)0x8000};
const uint32 l_bit_mask[32] = 	
  {0x00000001L,0x00000002L,0x00000004L,0x00000008L,0x00000010L,0x00000020L,0x00000040L,0x00000080L,
   0x00000100L,0x00000200L,0x00000400L,0x00000800L,0x00001000L,0x00002000L,0x00004000L,0x00008000L,
   0x00010000L,0x00020000L,0x00040000L,0x00080000L,0x00100000L,0x00200000L,0x00400000L,0x00800000L,
   0x01000000L,0x02000000L,0x04000000L,0x08000000L,0x10000000L,0x20000000L,0x40000000L,0x80000000L
   };

static uint8 hex_to_ascii[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};



// fault display variables
static bool FaultInterrupt;

// Temp varibles && Password varibles for LCD menu
struct tag_LCD_State
	{
		int16 LCD_Menu;
		int16 LCD_Pointer;
		int16 LCD_Dig_Point;
		char LCD_Display[4][21];
	} LCD_State[3];

int16 LCD_State_ix;

int16 LCD_Pointer_Return;

int16 Password;
bool PasswordFlag;	   // a Flag that specified whether or not the password was enter correctly

int16 Timer_Number;
unsigned char Timer_Status;
char Timer_Service;
char Timer_Logic;

int16 date_time_var[6] = {0,0,0,0,0,0};
#define c_month 0
#define c_day 1
#define c_md_on_hour 2
#define c_md_on_minute 3
#define c_md_off_hour 4
#define c_md_off_minute 5

int16 dow_time_var[4] = {0,0,0,0};
#define c_on_hour 0
#define c_on_minute 1
#define c_off_hour 2
#define c_off_minute 3


// Security Code Varibles

int16 LCD_FloorNum = 1;
unsigned char Code_Num[4]={1,1,1,1};
int16 code_floor_access;
int16 CodeOption;
int16 Security_Dpy_Index;

int16 line_select;
int16 status_select;
int16 error_select;


#pragma section const_type

const char LCD_Main_Menu[15][21] = {
  "       GALaxy       ",	   // 0
  " DATE AND TIME      ",	   // 1
  " ADJUSTABLE VARIABLE",	   // 2
  " JOB STATISTICS     ",	   // 3
  " INPUTS AND OUTPUTS ",	   // 4
  " SET CALLS & LOCKOUT",	   // 5
  " ELEVATOR STATUS    ",	   // 6
  " FAULT LOG          ",	   // 7
  " ELEVATOR SETUP     ",	   // 8
  " HOISTWAY TABLES    ",	   // 9
  " SERV ACTIVATION TMR",	   // 10
  " CAR CALL PB SECURTY",	   // 11
  " ADJUST LCD DISPLAY ",	   // 12
  " SOFTWARE UTILITIES ",	   // 13
  " DIAGNOSTICS        ",	   // 14
};

#if (Traction == 1)
#define Last_Menu 14
static const char Main_Menu_list[15] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14};
#else
#define Last_Menu 12
static const char Main_Menu_list[15] = {0,1,2,3,4,5,6,7,8,9,12,13,14};
#endif

char Menu_list[50];

static  const char LCD_Date_Time_Menu[2][21] = {
  " Set Date and Time  ",
  " View Day of Week   ",
};

static  const char LCD_DOW__Menu[8][21] = {
  "      Saturday      ",
  "       Sunday       ",
  "       Monday       ",
  "       Tuesday      ",
  "      Wednesday     ",
  "      Thursday      ",
  "       Friday       ",
  " Day of the Week:   ",
};

#define Car_Motion_Menu 0
#define Car_Timers_Menu 1
#define Car_Options_Menu 2
#define Service_Options_Menu 3
#define Emergency_Service_Menu 4
#define Group_Dispatch_Menu 5
#define Group_Options_Menu 6
#define Color_Lights_Menu 7
#define System_Options_Menu 8
#define NTS_Proc_Adj_Vars_Menu 9

const char LCD_Field_Variables[10][21] = {
  " Car Motion         ",	// menu 0
  " Car Timers         ",	// menu 1
  " Car Options        ",	// menu 2
  " Service Options    ",	// menu 3
  " Emergency Services ",	// menu 4
  " Group Dispatch     ",  	// menu 5 
  " Group Options      ",	// menu 6
  " Color Lights       ",	// menu 7
  " System Options     ",	// menu 8
  " NTS Proc Adj Vars  ",	// menu 9
};

#define FV_Last_Menu 9				//0,1,2,3,4,5,6,7,8,9
static const char FV_Menu_list[10] = {0,1,2,3,4,5,6,7,8,9};

static  const char LCD_Job_Statistics[2][21] = {
  " View Job Statistics",
  " Clear Job Statistic",
};

const char LCD_Input_Output[5][21] = {
  " Car Inputs & Output",
  " Grp Inputs & Output",
  " NTS Inputs & Output",
  " FPGA Input & Output",
  " Relocate IOs       ",
};

#define Last_IO_Menu 4				//0,1,2,3,4
static const char IO_Menu_list[5] = {0,1,2,3,4};



static  const char LCD_Fault_Log[2][21] = {
  "  View Fault Log    ",
  "  Clear Fault Log   ",
};

static  const char LCD_Detail_Fault[40][21] = {

  "Dpp Count=0000000000",   // 0  - 10
  "SD Count =0000000000",   // 1  - 10
  "EncV=0000,Enc Dir=No",   // 2  - 5, 18
  "%Load=000,          ",   // 3  - 6
  
  "NTS Count=0000000000",   // 4  - 6, 15
  "NTS Vel=      Dir=  ",   // 5  - 8, 15
  "UN*|UT*| DZ*|HWLrn=1",   // 6  - 4, 11, 18
  "DN*|DT*|FLT*|OnLin=1",   // 7  - 4, 11, 18

  "servf=   , procf=   ",	// 8  - 6, 17
  "doorf=   .rdpprf=   ",   // 9  - 6, 17
  "dpref=   ,  dirf=   ",   // 10 - 6, 17
  "firef=   ,rfiref=   ",   // 11 - 6, 17
  
  "codeb=   ,   eqf=   ",   // 12 - 6, 17
  " empf=   ,  medf=   ",	// 13 - 6, 17
  "  hsf=   ,startf=   ",   // 14 - 6, 17
  "stepf=   ,estopf=   ",   // 15 - 6, 17
  
  "callf=   ,dcalls=   ",   // 16 - 6, 17
  "nstop=   ,nxstop=   ",   // 17 - 6, 17
  "Relev=   ,LevStr=   ",   // 18 - 6, 17
  "NCUds=   ,DOseqf=   ",   // 19 - 6, 17
  
  "NudSt=   ,DoorRq=   ",   // 20 - 6, 17
  "FSd=     ,RSd=      ",   // 21 - 4, 14
  "InsSt=   ,InsSvc=   ",   // 22 - 6, 17
  "Motion Tmr =        ",   // 23 - 13
  
  " statusf =          ",   // 24 - 11
  "statusf3 =          ",   // 25 - 11
  "statusf4 =          ",   // 26 - 11
  "statusf2 =          ",   // 27 - 11
  
  "Run Stat =          ",   // 28 - 11
  "ssSt=    ,pwrSt=    ",   // 29 - 5, 16
  "HWLearn= ,Online=   ",   // 30 - 11
  "SelOk  = ,          ",   // 31 - 11

  " CkDrS=             ",	// 32 - 6, 17
  " CkStS=             ",	// 33 - 6, 17
  "CkRunS=             ",	// 34 - 6, 17
  "CkLevS=             ",	// 35 - 6, 17
  
  "Up 10   -10    fpm/s",	// 36 - 6, 17
  "Dn 10   -10    fpm/s",	// 37 - 6, 17
  "USD 40.0 ULD 20.0 in",	// 38 - 6, 17
  "DSD 40.0 DLD 20.0 in",	// 39 - 6, 17
};

static char Can_Dev_Name[23][8] = {
"SEL    ", // 0 c_ctcan_ENC_SEL
"NTS    ", // 1 c_mrcan_NTS
"BRK    ", // 2 Not used at this time
"SPB    ", // 3 c_mrcan_SPB
"SEL    ", // 4 c_ctcan_SEL
"DOOR   ", // 5 c_ctcan_DOOR
"RDOR   ", // 6 c_ctcan_RDOOR
"LW M   ", // 7 c_mrcan_LW, c_ctcan_LW
"LW C   ", // 8 c_mrcan_LW, c_ctcan_LW
"VS M   ", // 9 c_mrcan_VS, c_ctcan_VS
"VS C   ", // 10 c_mrcan_VS, c_ctcan_VS
"VS G   ", // 11 c_mrcan_VS, c_ctcan_VS
"PI M   ", // 12 c_mrcan_PI_LANT, c_ctcan_PI_LANT
"PI C   ", // 13 c_mrcan_PI_LANT, c_ctcan_PI_LANT
"SEBM   ", // 14 c_mrcan_SEB_1, c_ctcan_SEB_4, c_grcan_SEB_1
"SEBC   ", // 15 c_mrcan_SEB_1, c_ctcan_SEB_4, c_grcan_SEB_1
"SEBG   ", // 16 c_mrcan_SEB_1, c_ctcan_SEB_4, c_grcan_SEB_1
"FI     ", // 17 c_grcan_FI_DPY
"COP    ", // 18 c_ctcan_SEB_1, c_ctcan_COP
"SDZ    ", // 19 c_ctcan_SEB_2, c_ctcan_SEL_DZ
"SLM    ", // 20 c_ctcan_SEB_3, c_ctcan_SEL_LIM
"HCD    ", // 21 c_grcan_HCDB_1
"HCB    ", // 22 c_grcan_HCB_1
};


// Only use 20 characters due to limited space on video display
const char LCD_device_Fault[8][14] = 
{
  "Dev:     Cnt:",	// 0
  "Comm Fault   ",	// 1
  "APS Com Fault",	// 2
  "SPI Com Fault",	// 3
  "HW Fl Cnt=0 F",	// 4
  "HW Fl Cnt Inv",	// 5
  "HW Valad Fl F",	// 6
  "DZ Clip Fault",	// 7
};


const char LCD_CCDB_device_Fault[15][14] = 
{
  "Dev:     Cnt:",   // 0
  "LED Short Red",   // 1 CF - Car Call Board LED short red 
  "LED Sht Green",   // 2 CF - Car Call Board LED short green
  "LED Shrt Blue",   // 3 CF - Car Call Board LED short blue
  "LED Open Red ",   // 4 CF - Car Call Board LED open red
  "LED Open Grn ",   // 4 CF - Car Call Board LED open green
  "LED Open Blue",   // 6 CF - Car Call Board LED open blue
  "FET Short Red",   // 7 CF - Car Call Board FET short red 
  "FET Short Grn",   // 8 CF - Car Call Board FET short green 
  "FET Shrt Blue",   // 9 CF - Car Call Board FET short blue 
  "FET Open Red ",   // 10 CF - Car Call Board FET open red 
  "FET Open Grn ",   // 11 CF - Car Call Board FET open green 
  "FET Open Blue",   // 12 CF - Car Call Board FET open blue
  "No LED Board ",	 // 13 CF - Car Call LED board missing
  "Stuck Button ",	 // 14 CF - Car Call Board stuck button
};

const char LCD_HCDB_device_Fault[49][14] = 
{
  "Dev:     Cnt:",   	// 0
  "Tx->below fl ",		// 1 HF - HCB Tx fault down to below floor
  "Tx->above fl ",		// 2 HF - HCB tx fault up to above floor
  "Rx<-below fl ",		// 3 HF - HCB rx fault down from below floor
  "Rx<-above fl ",		// 4 HF - HCB rx fault up to above floor
  "Stck Dn Buttn",   	// 5 HF - HCB stuck button down
  "Stck Up Buttn",		// 6 HF - HCB stuck button up
  "Dn LED Open  ",		// 7 HF - HCB led open down
  "Up LED Open  ",		// 8 HF - HCB led open up
  "Dn LED Short ",   	// 9 HF - HCB led short down
  "Up LED Short ",   	// 10 HF - HCB led short up
  "Dn FET Open  ",   	// 11 HF - HCB fet open down
  "Up FET Open  ",   	// 12 HF - HCB fet open up
  "Dn FET Short ",   	// 13 HF - HCB fet short down
  "Up FET Short ",   	// 14 HF - HCB fet short up
  "Invalid Floor",   	// 15 HF - HCB has invalid floor
  "Dev Comm Loss",		// 16 HF - HCB no comm to individual hc board
  "Device Reset ",		// 17 HF - HCB device reset
  "No Dn LED Brd",		// 18 HF - HCB No Down Led Board Detected
  "No Up LED Brd",		// 19 HF - HCB No Up Led Board Detected
  "LED Shrt RedU", 		// 20 HF - HCB led short red up
  "LED Shrt GrnU", 		// 21 HF - HCB led short green up
  "LED Shrt BluU", 		// 22 HF - HCB led short blue up
  "LED Shrt BluD", 		// 23 HF - HCB led short blue down
  "LED Shrt GrnD", 		// 24 HF - HCB led short green down
  "LED Shrt RedD", 		// 25 HF - HCB led short red down
  "LED Open RedU", 		// 26 HF - HCB led short red up
  "LED Open GrnU", 		// 27 HF - HCB led open green up
  "LED Open BluU", 		// 28 HF - HCB led open blue up
  "LED Open BluD", 		// 29 HF - HCB led open blue down
  "LED Open GrnD", 		// 30 HF - HCB led open green down
  "LED Open RedD", 		// 31 HF - HCB led open red down
  "FET Shrt RedU", 		// 32 HF - HCB fet short red up
  "FET Shrt GrnU", 		// 33 HF - HCB fet short green up
  "FET Shrt BluU", 		// 34 HF - HCB fet short blue up
  "FET Shrt BluD", 		// 35 HF - HCB fet short blue down
  "FET Shrt GrnD", 		// 36 HF - HCB fet short green down
  "FET Shrt RedD", 		// 37 HF - HCB fet short red down
  "FET Open RedU", 		// 38 HF - HCB fet short red up
  "FET Open GrnU", 		// 39 HF - HCB fet open green up
  "FET Open BluU", 		// 40 HF - HCB fet open blue up
  "FET Open BluD", 		// 41 HF - HCB fet open blue down
  "FET Open GrnD", 		// 42 HF - HCB fet open green down
  "FET Open RedD", 		// 43 HF - HCB fet open red down
  "Low Sply Volt",		// 44 HF - Hall call board has low supply voltage
  "Up Input Ovld",   	// 45 HF - HCB Up input overload
  "Dn Input Ovld",   	// 46 HF - HCB Down input overload
  "Ax Up In Ovld",   	// 47 HF - HCB Aux Up input overload
  "Ax Dn In Ovld",   	// 48 HF - HCB Aux Down input overload
};

const char LCD_device_Reset[14] = 
{
  "Device Reset  ",	// 0
};

static  const char LCD_Dbg_Status[4][21]={
  "Debug 1 =           ",
  "Debug 2 =           ",
  "Debug 3 =           ",
  "Debug 4 =           ",
};

static  const char LCD_Dbg_Status2[4][21]={
  "Debug 5 =           ",
  "Debug 6 =           ",
  "Debug 7 =           ",
  "Debug 8 =           ",
};

static  const char LCD_Fire_dpy_Status[3][21]={
  "f1ef =    ,frst =    ",  
  "gfct =    ,f2t1 =    ",
  "fsen =    ,fsts =    ",
};


			// medf = 1 recall car to medical emergency floor
			// medf = 2 car at medical emergency floor with door open (return complete)
			// medf = 3 On EMS car call service
			// codebf = 2 at code blue floor
			// codebf = 3 at code blue floor with door open
			// codebf = 4 finished code blue return 


static  const char LCD_ckdoor_tbl[41][14] = {
  "No Door Op   ", 	// 0 
  "Fire Door    ",	// 1
  "Med Em Svc   ",	// 2
  "EAQ Door Open",	// 3
  "EMP Wait DC  ",	// 4
  "EMP Home DO  ",	// 5
  "EMP Home DC  ",	// 6
  "EMP RCL Door ",	// 7
  "Stall Op Door",	// 8
  "Hot Oil Door ",	// 9
  "MedEm RCL @Fl",	// 10
  "MedEm RCL    ",	// 11
  "MedEm Wait Sw",	// 12
  "MedEm Svc Op ",	// 13
  "Hospital Svc ",	// 14
  "CB Ovr FS RCL",	// 15
  "CB Ovr FS Svc",	// 16
  "F1 Recall @FL",	// 17
  "F1 Recall    ",	// 18
  "F1 Complete  ",	// 19
  "F1 or F2     ",	// 20
  "At Floor Chk ",	// 21
  "Front DPM    ",	// 22
  "Rear DPM     ",	// 23
  "CodeBlue RCL ",	// 24
  "CodeBlue Svc ",  // 25
  "VIP Recall   ",  // 26
  "VIP Service  ",  // 27
  "Independent  ",  // 28
  "Overload     ",	// 29
  "Elevator Off ",	// 30
  "Prison Svc   ",	// 31
  "Push Button  ",	// 32
  "Attendant    ",	// 33
  "Extended Door",	// 34
  "Sabbath      ",	// 35
  "RTL Door Cl  ",	// 36
  "Lobby Recall ",	// 37
  "Car Elev Off ",	// 38
  "HW Elev Off  ",	// 39
  "Automatic    ",	// 40
};
static  const char LCD_ckstart_tbl[44][14] = {
  "No Start Op  ", 	// 0 
  "CCF Off Up   ",  // 1
  "CPU UN Off   ",	// 2
  "FSTU Fail On ",	// 3
  "SPD Failed On",	// 4
  "MC Failed On ",	// 5
  "MC Failed Off",	// 6
  "SPD Fail Off ",	// 7
  "RUNU Fail On ",	// 8
  "RUNU Fail Off",	// 9
  "CPU Out On Up",	// 10
  "CCF On w/RunU",	// 11
  "NTS Out On Up",	// 12
  "NTS UN Off   ",	// 13
  "SU Failed On ",	// 14
  "CPU UT Off   ",	// 15
  "NTS UT Off   ",	// 16
  "SUF Failed On",	// 17
  "SU Failed Off",	// 18
  "CCF On w/SU  ",	// 19
  "SUF Fail Off ",	// 20
  "SUF On w/SU  ",	// 21
  "Run Up       ",	// 22
  "CPU DN Off   ",	// 23
  "FSTD Fail On ",	// 24
  "RUND Fail On ",	// 25
  "RUND Fail Off",	// 26
  "CPU Out On Dn",	// 27
  "CCF On w/RunD",	// 28
  "NTS Out On Dn",	// 29
  "NTS DN Off   ",	// 30
  "SD Failed On ",	// 31
  "CPU DT Off   ",	// 32
  "NTS DT Off   ",	// 33
  "SDF Failed On",	// 34
  "SD Failed Off",	// 35
  "CCF On w/SD  ",	// 36
  "SDF Fail Off ",	// 37
  "SDF On/W SD  ",	// 38
  "RUN Down     ",	// 39
  "40           ",  // 40
  "41           ",  // 41
  "42           ",  // 42
  "43           ",  // 43
};
static  const char LCD_ckrun_tbl[41][14] = {
  "No Run Op    ", 	// 0 
  "HW Learn Flt ",	// 1
  "PAL Fault    ",	// 2
  "Comm Error   ",	// 3
  "IO Test      ",	// 4
  "Norm Stop Tmr",	// 5
  "ATT No DC CC ",	// 6
  "ATT No UP/DN ",	// 7
  "ATT No DClose",	// 8
  "No ATT UP    ",	// 9
  "No ATT No DC ",	// 10
  "CarSw No DC  ",	// 11
  "CarSw DC Hold",	// 12
  "Man Door Time",	// 13
  "SafeTest Year",	// 14
  "SafeTst Month",	// 15
  "SafeTest Day ",	// 16
  "Door Request ",	// 17
  "Door Open    ",	// 18
  "Door Closing ",	// 19
  "DC No DO Seq ",	// 20
  "UC No DO Seq ",	// 21
  "LC No DO Seq ",	// 22
  "RDC No DO Seq",	// 23
  "RUC No DO Seq",  // 24
  "Viscosity    ",  // 25
  "Relevel Req  ",  // 26
  "No Calls     ",  // 27
  "Earthquake   ",	// 28
  "No DCl       ",	// 29
  "No Rear DCL  ",	// 30
  "No SAFE      ",	// 31
  "Running      ",	// 32
  "33           ",	// 33
  "34           ",	// 34
  "35           ",	// 35
  "36           ",	// 36
  "37           ",	// 37
  "38           ",	// 38
  "39           ",	// 39
  "40           ",	// 40
};
static  const char LCD_cklevel_tbl[21][14] = {
  "No Level Op  ", 	// 0 
  "CPU UN Off   ",	// 1
  "MC Failed Off",	// 2
  "SPD Fail Off ",	// 3
  "RUNU Fail On ",	// 4
  "RUNU Fail Off",	// 5
  "CPU Out On Up",	// 6
  "NTS UN Off   ",	// 7
  "SU Failed Off",	// 8
  "SUF Failed On",	// 9
  "Level Up     ",	// 10
  "CPU DN Off   ",	// 11
  "RUND Fail On ",	// 12
  "RUND Fail Off",	// 13
  "CPU Out On Dn",	// 14
  "NTS DN Off   ",	// 15
  "SD Failed Off",	// 16
  "SDF Failed On",	// 17
  "Level Down   ",	// 18
  "19           ",	// 19
  "20           ",	// 20
};


static  const char LCD_Dpy_Hoistway[5][21] = {
  " Floor & SD Counts  ",
  " Short FL SD Counts ",
  " CPU Term Limit Dist",
  " UL & DL Distance   ",
  " Valid Floor & Clips",
};

#define Last_Hoistway_Menu 4			 //0,1,2,3,4
static const char Hoistway_Menu_list[5] = {0,1,2,3,4};


static  const char LCD_Set_Time_Date[2][21] = {
  " Press Mode for Next",
  " and Enter to Set   ",
};




#define MainMenu_Dpy_Offset 0
#define Function_Dpy_Offset 2
#define NO_YES_Dpy_Offset 6
#define Floor_Dpy_Offset 8
#define Code_Tbl_Empty_Offset 9


// Security Options
static  const char Security_dpy[14][21] = {
  " Sec Codes Per Floor", //0
  "Sec Codes All Floors", //1
  " View Security Codes", //2
  "  Add Security Code ", //3
  "Delete Security Code", //4
  "Del All Codes On Flr", //5
  "         NO         ", //6
  "         YES        ", //7 
  "    Floor #    1    ", //8
  "  Code Table Empty  ", //9
  "Add Code On All Flrs", //10
  "Delete Code All Flrs", //11
  " Del All Codes/Flrs ", //12
  "   Code Table Full  ", //13
};								  



static const char LCD_Par[lastfvar+1][21] ={
  "Min=0   Max=5.0  Sec",   // 000 - Y Delta Time
  "Min=0   Max=10.0 Sec",   // 001 - Fault Time
  "Min=0   Max=10.0 Sec",   // 002 - Reset Time
  "0=1 Gong,  1=2 Gongs",   // 003 - Double Stroke
  "Min=0   Max=2.0  Sec",   // 004 - Lant On Time
  "Min=0   Max=2.0  Sec",   // 005 - Lant Off Time
  "Min=.2  Max=2.0  Sec",   // 006 - Pas Chime Time
  "Mn=10  Mx=3200.0 Sec",   // 007 - Door Fail Time
  "Mn=20  Mx=3200.0 Sec",   // 008 - Nudging Time
  "Min=0  Mx=3200.0 Sec",   // 009 - Preopen Delay
  "Min=1.0 Max=60.0 Sec",   // 010 - Car Call Dwell
  "Min=1.0 Max=60.0 Sec",   // 011 - Hall Call Dwell
  "Min=1.0 Max=60.0 Sec",   // 012 - Lobby Dwell
  "Min=1.0 Max=120  Sec",   // 013 - Handicap Dwell
  "Min=1.0 Max=60.0 Sec",   // 014 - Non Interfer T
  "Min=Bot Max=Top Flr ",   // 015 - Lobby Floor
  "Min=Bot Max=Top Flr ",   // 016 - Fire Main Floor
  "Min=Bot Max=Top Flr ",   // 017 - ALT Fire Floor
  "Mn=20  Mx=3200.0 Sec",   // 018 - Stall Time
  "Min=0.2 Max=5.0  Sec",   // 019 - Soft Stop Time
  "Mn=30  Mx=3200.0 Sec",   // 020 - Gen/Lt/Fan Time
  "Min=2000 Max=2999 yr",   // 021 - Year
  "Min=1   Max=12 month",   // 022 - Month
  "Min=1   Max=31   day",   // 023 - Day
  "Min=0   Max=23    hr",   // 024 - Hour
  "Min=0   Max=59   min",   // 025 - Minute
  "Min=2000 Max=2999 yr",   // 026 - Safe Test Year
  "Min=1   Max=12 month",   // 027 - Safe Test Month
  "Min=1   Max=31   day",   // 028 - Safe Test Day
  "0-3=19.2,38.4,57.6, ",   // 029 - User Baud Rate
  "Min=0 Mx=#Cars #cars",   // 030 - Parking
  "Min=Bot Max=Top Flr ",   // 031 - Em Power Floor
  "Min=1 Mx=#Cars #cars",   // 032 - Em Power Cars
  "Min=0 Max=#Cars car#",   // 033 - 1st Recall Car
  "Min=0 Max=#Cars car#",   // 034 - 1st EP Run Car
  "Min=1 Max=600.0  Sec",   // 035 - Recall Timeout
  "0 = OFF    1 = ON   ",   // 036 - DOB Over Nudg
  "0=OFF,1=ON,2=Ft;4=Rr",   // 037 - Emerg Dispatch
  "Min=0 Mx=#Cars #cars",   // 038 - Lobby Request
  "0=OF,1=NU,2=NDC,4=Pk",   // 039 - Next Car Up
  "Min=0 Max=#Cars car#",   // 040 - Code Blue Car
  "Min=0 Max=#Cars car#",   // 041 - IR Car
  "0=OFF,  Max=50  #CCs",   // 042 - LW Anti-nuisan
  "Alt|M 0=ff,1=fr,2=rf",   // 043 - Fire Sw Loc
  "Min=0   Max=60   Sec",   // 044 - ETA Min Time
  "Min=0   Max=60   Sec",   // 045 - ETA Co CC Time
  "  0 = OFF  1 = ON   ",   // 046 - High Speed Inspection Output
  "Min=0 Max=#Cars loc#",   // 047 - Vid Pos Car 1
  "Min=0 Max=#Cars loc#",   // 048 - Vid Pos Car 2
  "Min=0 Max=#Cars loc#",   // 049 - Vid Pos Car 3
  "Min=0 Max=#Cars loc#",   // 050 - Vid Pos Car 4
  "Min=0 Max=#Cars loc#",   // 051 - Vid Pos Car 5
  "Min=0 Max=#Cars loc#",   // 052 - Vid Pos Car 6
  "Min=0 Max=#Cars loc#",   // 053 - Vid Pos Car 7
  "Min=0 Max=#Cars loc#",   // 054 - Vid Pos Car 8
  "0=OFF,Mx=10 #of runs",   // 055 - No Psg Run Cnt
  "1=CCS.2=SEC,4=Remote",   // 056 - Ind Over Sec
  "Min=0 Max=3200.0 Sec",   // 057 - Up Pk Trig Time
  "Min=1 Mx=100 #PkTrig",   // 058 - Up Pk Trig Cnt
  "Min=1  Max=40   #CCs",   // 059 - Up Pk CC Count
  "Mn=0.0 Mx=3200.0 Sec",   // 060 - Up Peak Time
  "Mn=0.0 Mx=3200.0 Sec",   // 061 - Dn Pk Trig Time
  "Min=0  Mx=100 #Dn HC",   // 062 - Dn Pk Trig Cnt
  "Mn=0.0 Mx=3200.0 Sec",   // 063 - Down Peak Time
  "Mn=0.0  Mx=120.0 Sec",   // 064 - Park Delay Time
  "1=XASG,2=XCAN,4=RXAS",   // 065 - HC X-Assign En
  "Min=0  Max=500   Sec",   // 066 - HC X-Assign ETA
  "Min=Bot Max=Top Flr ",   // 067 - Med Em Floor
  "0=Front, 1=Rear  Flr",   // 068 - Med Em Sw Loc
  "0=Main, 1=Alt, Floor",   // 069 - MachRm Fire Ret
  "0=Main, 1=Alt, Floor",   // 070 - Hoistw Fire Ret
  "AftRec,1=Imm,2=FS OF",   // 071 - Recall Reset
  "0=IS,1=Inv,2=IU,4=OS",   // 072 - Invert ISER
  "Min=0  Mx=3200.0 Sec",   // 073 - Video time out
  "0 = OFF    1 = ON   ",   // 074 - Door Close Outp. Ins.
  "Min=1 Max=Top  Floor",   // 075 - Parking floor 1
  "Min=1 Max=Top  Floor",   // 076 - Parking floor 2
  "Min=1 Max=Top  Floor",   // 077 - Parking floor 3
  "Min=1 Max=Top  Floor",   // 078 - Parking floor 4
  "Min=1 Max=Top  Floor",   // 079 - Parking floor 5
  "Min=1  Max=Top   Flr",   // 080 - Parking floor 6
  "Min=1  Max=Top   Flr",   // 081 - Parking floor 7
  "Min=1 Max=Top  Floor",   // 082 - Parking width
  "0=#HC/F,1=DivH,2=Var",   // 083 - Parking Type
  "Min=0 Max=100  %Load",   // 083 - Load Bypass percent
  "Min=0 Max=100  %Load",   // 085 - Load Antinuisance percent
  "Min=0 Max=100  %Load",   // 086 - Load Dispatch percent
  "Min=0 Max=125  %Load",   // 087 - Load Overload percent
  "IREn,2=AnCB4S,AnCB4F",   // 088 - IR ControlFinishing
  "Mn=0.0 Mx=900.0  Sec",   // 089 - Attendant Buzzer Delay
  "0=No FSX Sw,1=FSX Sw",   // 090 - Aux. Hall Fire Sw
  "0=F1&2,F1,BLK,4=FSL ",   // 091 - Hall fire light
  "0=Bo,1=Sep,C-R,4=R-C",   // 092 - COP/Remote CC Select
  "Min=0  Max=1.5   Sec",   // 093 - Door Open or close delay time
  "1=Rcl,fD,4=rD,AlwRcl",   // 094 - Security Recall
  "1=CCS,2=SECF,4=R CCS",   // 095 - DOB override securityCCS Rear Only.
  "Mn=0.0 Mx=900.0  Sec",   // 096 - Manual Door Buzzer Delay
  "Min=0  Max=Top   Flr",   // 097 - Security Floor
  "Min=0  Max=7.0   Sec",   // 098 - Retiring Cam pick delay timer
  "Min=0.0  Mx=60.0 Sec",   // 099 - Short dwell door time
  "Min=0 Mx=#Cars  car#",   // 100 - 2nd IR Car
  "1=Up,2=Dn,4=HC,8=RTL",   // 101 - Stop At lobby
  " 0 = N/O  1 = N/C   ",   // 102 - Invert CLF
  " 0 = N/O  1 = N/C   ",   // 103 - Invert TPL
  " 0 = N/O  1 = N/C   ",   // 104 - Invert LPS
  " 0 = N/O  1 = N/C   ",   // 105 - Invert LOS
  "0=Norm,1=Nud No Call",   // 106 - Nudge No Calls
  "F1:1=No Blk,2=BZ Off",   // 107 - Fire Option
  "  0 = OFF  1 = ON   ",   // 108 - Attendant HC sets car call
  "Mn=1.0 Mx=3200.0 Sec",   // 109 - Code blue door open time
  "  0 = OFF  1 = ON   ",   // 110 - CB Req Ind Car
  "  0 = OFF  1 = ON   ",   // 111 - Code blue light
  "  0 = OFF  1 = ON   ",   // 112 - HSV door close on Car call
  "  0 = OFF  1 = ON   ",   // 113 - Ind Door CL CC
  "1=EN Aut,2=DIS,4=1CC",   // 114 - Single Auto PB
  "  0 = 0FF  1 = ON   ",   // 115 - Door Open when no DOL
  "+1 = Remote Over CCS",	// 116 - Remote Station Override Security
  "Min=0 Max=3200.0 Sec",	// 117 - Freight Auto Door Close Output Delay Time
  "  0 = ON   1 = OFF  ",   // 118 - Disable DCB cancel dwell time
  "1=CyDo,2=CCC,4=RevDo",   // 119 - Return to lobby option
  "1=Frnt 1st, 2=Rr 1st",   // 120 - Non-Simultaneous Doors
  "0=OFF,1=ON,2=Off SFl",   // 121 - Preopen Doors
  "Min=0.0 Max=2.0  Sec",   // 122 - Relevel Delay Time
  "1=Ph2RclDO,2=NoBlkF2",   // 123 - Fire Option  2
  "  0 = OFF  1 = ON   ",   // 124 - Close gate,swing door no pref
  "Mn=0.0 Mx=3200.0 Sec",   // 125 - Electric Eye Time-out Time
  "  0 = OFF  1 = ON   ",   // 126 - OTS No HC Canc
  "1=Dis,2=Reopen,4=Buz",   // 127 - Nudge Dis Ctrl
  "Mn=10.0 Mx=60.0  Sec",   // 128 - Phase 1 door close time-out
  "0=0FF +1=Alwys +2=Pk",   // 129 - No HC Door Reop
  "Mn=1.0  Mx=60.0  Sec",   // 130 - Return to Lobby Door Dwell Time
  "TimOut:+1=HUL,+2=CUL",   // 131 - Next Up Direction Lant Ctl
  "0=OnDCL,1=Aft NU Tim",   // 132 - Next Up Preference Ctl
  "1=No HC,2=Or SR/w HC",   // 133 - Second Riser Ctrl
  "1=Cab Lant          ",   // 134 - SR Lantern Ctl
  "Min=0   Max=60   Sec",   // 135 - Attendant ETA Pref
  "  0 = 0FF  1 = ON   ",   // 136 - HBZ/PI Dis at non-valid fl
  "Mn=1.0 Mx=3200.0 Sec",   // 137 - Vip Door Time
  "+1=Canc VIPC,+2=CCC ",   // 138 - Vip Operation Flags
  "Mn=0 Mx=#Cars  #cars",   // 139 - Number of Vip Cars
  "0=Op,Norm,2=EmP,Rcal",   // 140 - EP Op LED function
  " 0=Prkd,Rcld,2=epflr",   // 141 - EP Park LED funct
  "1=RC,2=DO,4=LFof8=DC",   // 142 - Hall Elevator Off options
  "Min=1  Max=Top   Flr",   // 143 - Alternate Lobby Fl
  "Min=1  Max=Top   Flr",   // 144 - Alt Parking Fl
  "0=Always,1=NCU/Up Pk",   // 145 - Lobby Req Cntrl
  "Min=0 Max=100  %Load",   // 146 - Handicap Capacity percent
  "Mn=1.0 Mx=3200.0 Sec",   // 147 - Freight door close time-out
  "Min=0   Max=255  Sec",   // 148 - Handicap Car Wait
  "Mn=10.0 Mx=72.0 Inch",   // 149 - Short floor distance in inches
  "0=Norm,+1=Hld,+2=Adv",   // 150 - Retiring Cam Control
  "0=Main+Aux Sw,1=Main",   // 151 - Recall from FS1 Alt Floor
  "0=On   Max=30.0  Sec",   // 152 - Attendant Buzzer Off Time
  "Min=1.0 Max=30.0 Sec",   // 153 - Attendant Buzzer On Time
  "Min=0.0 Max=30.0 Sec",   // 154 - Short Fl Dn SD
  "Min=0.0 Max=30.0 Sec",   // 155 - Mid Shrt Fl Dn SD
  "Min=0.0 Max=30.0 Sec",   // 156 - Short Fl Up SD
  "Min=0.0 Max=30.0 Sec",   // 157 - Mid Shrt Fl Up SD
  "0=Lobby Max=Top  Flr",   // 158 - HS Elevator Off floor
  "Min=0 Max=30 Svc Num",   // 159 - Service msg 1 display
  "Min=0 Max=30 Svc Num",   // 160 - Service msg 2 display
  "1=SFR,2=SDSF,4=SDMSF",   // 161 - Short Floor Control
  "0=1stRcl,1=All,2=no ",   // 162 - Security Recall 2group recalls
  "Mn=0.0 Mx=3200.0 Sec",   // 163 - EP Recall Delay
  "Min=1   Max=240  Sec",   // 164 - Grp cc sec ovr tim
  "Min=0.0 Max=100.0  %",   // 165 - HC on brightness
  "Min=0.0 Max=100.0  %",   // 166 - HC off brightness
  "Min=Bot Max=Top  Flr",   // 167 - Access Top Floor
  "Min=Bot Max=Top  Flr",   // 168 - Access Bottom Floor
  "0=UL,DL, 1=PLS CNT  ",   // 169 - Stop on position pulse
  "Mn=0.0 Mx=3200.0 Sec",   // 170 - Sabbath restart
  "Mn=0.0 Max=30.0  Sec",   // 171 - Freight Power Door open time
  "  0 = 0FF  1 = ON   ",   // 172 - Automatically Display Fault
  "Min=0000  Max=9999  ",   // 173 - Password
  "Mn=0.0 Mx=3200.0 Sec",   // 174 - Password time-out
  "  0 = 0FF  1 = ON   ",   // 175 - Behind car call cancel
  "Min=0.0 Mx=240.0 Sec",   // 176 - Adv de time non-simult doors
  "Mn=0 Mx=#Cars  #cars",   // 177 - Grp Timer Parking
  "0=HS Out,1=No HS Out",   // 178 - Shrt fl hsf/no hsout
  "0=Norm UPk,1=Hvy UPk",   // 179 - Up peak control
  "Mn=0 Mx=#Cars  #cars",   // 180 - Up peak pool
  "0=Norm DPk,1=Hvy DPk",   // 181 - Down peak control
  "Min=0 Mx=#Cars #cars",   // 182 - Down peak pool
  "Min=0 Mx=#Cars #cars",   // 183 - HC X-Assign Cars
  "0=No,1=ALTof,3=ALTon",   // 184 - Fire alt rcl after fs off
  "Min=0  Max=10.0  Sec",   // 185 - Auto Swing Door Open Delay Sec
  "Min=0  Max=320   Sec",   // 186 - CL Pulse Time
  "Min=0  Max=300  hour",   // 187 - Cycle Run time in hours
  "1fs1,rtl,emp,8@L,all",   // 188 - Door Open Light control
  "Min=0   Max=15    ix",   // 189 - HCUp On Color
  "Min=0   Max=15    ix",   // 190 - HCUp Off Color
  "Min=0   Max=15    ix",   // 191 - HC Sec Color
  "+1=Inv,+2=Flsh,+4=En",   // 192 - HC Sec Lt
  "Min=0.0 Max=100.0  %",   // 193 - HC Sec brightness
  "0=Main, 1=Alt, Floor",   // 194 - Hoistway 2 fire ret
  "Min=0   Max=15    ix",   // 195 - CC Button On Color
  "Min=0   Max=15    ix",   // 196 - CC Button Off Color
  "Min=0.0 Max=100.0  %",   // 197 - CC output on brightness
  "Min=0.0 Max=100.0  %",   // 198 - CC output off brightness
  "1=Flsh Sec,2=ATT Seq",   // 199 - CC Button Light Control
  "Min=0   Max=15    ix",   // 200 - CC Button Security Color
  "Min=0.0 Max=100.0  %",   // 201 - CC Security brightness
  "1=IR,Lby Dwel,LbyOff",   // 202 - Sabbath Enable variabletimer, 4= Lobby off 
  "Mn=0.0 Mx=600.0 Vrms",   // 203 - Low Line Voltage (RMS value)
  "Mn=0.0 Mx=600.0 Vrms",   // 204 - Low Door Voltage (RMS value)
  "Min=1.0 Max=60.0 sec",   // 205 - EP Recover Timeout
  "1=FL Off Not Select ",   // 206 - Fire Light control during EP
  "0=Stop,1=Recll,2=Seq",   // 207 - EP Manual Sel En
  "1=FL Off Can't Recll",   // 208 - Fire Light control OTS
  "Min=10.0 Mx=60.0 Sec",   // 209 - Sabbath Door Dwell Time
  "Min=1.0 Max=10.0 Sec",   // 210 - Sabbath Door Buzzer timer b4 DC
  "1=PI,+2=Lant,4=Arrow",   // 211 - Sabbath disable variable
  "  0 = ON   1 = OFF  ",   // 212 - Electric Eye cancel door time
  "0=Immediate, 1=delay",   // 213 - EP @ Rcl FL W/DOtime-delay
  "0=Immediate, 1=delay",   // 214 - EP NOT @Rcl FL DOafter time-delay
  "0=DrClosed,1=DoorOpn",   // 215 - Asgn Park Fl DO
  "Min=1.0 Max=15.0 Sec",   // 216 - Hall Lantern Delay
  "1=LbyOn,2=CLD,4=NoSi",   // 217 - Sabbath Enable control 2
  " 1=DoorOpening,2=DPM",   // 218 - CLant Ctl
  "0=Dis,Max=3200.0 Sec",   // 219 - Max Door Hold time from ED
  "  0 = 0FF  1 = ON   ",   // 220 - Access run door close
  "Min=0   Max=15    ix",   // 221 - Car Call Button Att Up Color
  "Min=0.0 Max=100.0  %",   // 222 - Car Call Att Up brightness
  "Min=0   Max=15    ix",   // 223 - Car Call Button Att Dn Color
  "Min=0.0 Max=100.0  %",   // 224 - Car Call Att Dn brightness
  "Min=0   Max=15    ix",   // 225 - Fire light Color
  "Min=0.0 Max=100.0  %",   // 226 - Fire light brightness
  "Min=0   Max=15    ix",   // 227 - Medical light Color
  "Min=0.0 Max=100.0  %",   // 228 - Medical light brightness
  "Min=0   Max=15    ix",   // 229 - Emergency light Color
  "Min=0.0 Max=100.0  %",   // 230 - Emergency light brightness
  "Min=0   Max=15    ix",   // 231 - OTS light Color
  "Min=0.0 Max=100.0  %",   // 232 - OTS light brightness
  "Min=0   Max=63      ",   // 233 - Backlight Output lightsOTS,Bit4:Att,Bit5:non-cc
  "Min=0   Max=7 1/4sec",   // 234 - Can Sync Count 1/4sec
  "Min=0   Max=15    ix",   // 235 - HCDn On color
  "Min=0.0 Max=100.0  %",   // 236 - HCDn On brightness
  "Min=0   Max=15    ix",   // 237 - HCDn Off color
  "Min=0.0 Max=100.0  %",   // 238 - HCDn Off brightness
  "Min=0   Max=15    ix",   // 239 - HC CB On color
  "Min=0.0 Max=100.0  %",   // 240 - HC CB On brightness
  "Min=0   Max=15    ix",   // 241 - HC Vip On color
  "Min=0.0 Max=100.0  %",   // 242 - HC Vip On brightness
  "Min=0   Max=15    ix",   // 243 - HCIR Up On color
  "Min=0.0 Max=100.0  %",   // 244 - HCIR Up On brightness
  "Min=0   Max=15    ix",   // 245 - HCIR Dn On color
  "Min=0.0 Max=100.0  %",   // 246 - HCIR Dn On brightness
  "Min=0   Max=15    ix",   // 247 - HCIR Up Off color
  "Min=0.0 Max=100.0  %",   // 248 - HCIR Up Off brightness
  "Min=0   Max=15    ix",   // 249 - HCIR Dn Off color
  "Min=0.0 Max=100.0  %",   // 250 - HCIR Dn Off brightness
  "Min=0.0 Max=100.0  %",   // 251 - HCUp On brightness
  "Min=0.0 Max=100.0  %",   // 252 - HCUp On brightness
  " 1=On HC,  2=On IR  ",   // 253 - CB Button Loc
  " 1=On HC,  2=On IR  ",   // 254 - Vip Location
  "0=IR,1=HC IR Not On ",   // 255 - IR light color control
  "Min=0   Max=15    ix",   // 256 - HC CB Off color
  "Min=0.0 Max=100.0  %",   // 257 - HC CB Off brightness
  "Min=0   Max=15    ix",   // 258 - HC Vip Off color
  "Min=0.0 Max=100.0  %",   // 259 - HC Vip Off brightness
  "0=No,+1=Cab,+2=Hall ",   // 260 - Vip lantern control
  "0=Specl Serv,1=KeySw",   // 261 - Group CC Override Ctrl
  "Min=0  Max=Last  Flt",   // 262 - Exclusion fault 1
  "Min=0  Max=Last  Flt",   // 263 - Exclusion fault 2
  "Min=0  Max=Last  Flt",   // 264 - Exclusion fault 3
  "Min=0  Max=Last  Flt",   // 265 - Exclusion fault 4
  "Min=0  Max=Last  Flt",   // 266 - Exclusion fault 5
  "Min=0  Max=Last  Flt",   // 267 - Exclusion fault 6
  "0=115.2,1=57.6K Baud",   // 268 - Can Baud Rate
  "0=Norm,1=No Fwd Call",   // 269 - Arrival Lantern
  "Min=0 Mx=#Cars  car#",   // 270 - Code Blue SR Car
  "0=No, 1=IR Car CB En",   // 271 - Code blue over IR car
  "Min=0   Max=60   Sec",   // 272 - IR Car CB penalty
  "0=IN Sec,1=UNSecured",   // 273 - In security Output invert
  "1=ATU/D,+2=ATU,+4=CC",   // 274 - Attendent manual dir enable
  "Min=1   Max=5   10ms",   // 275 - Encoder Debounce Interval
  "Min=2   Max=10     #",   // 276 - Encoder number of samples
  "Min=.1  Max=2.0  Sec",   // 277 - Handicap buzzer on CC beep time
  "1=Dbg,2=Galcm,3=DL20",   // 278 - Com 1 Port sel
  "0-3=19.2,38.4,57.6, ",   // 279 - User 2 Baud Rate
  "Min=0 Mx=0xFFFF Bits",   // 280 - Cpu timing output control
  "Min=0 Max=30 Svc Num",   // 281 - Service msg 3 display
  "1=up,2=dn,4=ur,8=dnr",   // 282 - HC Asgn Secure Type
  "0=2.4,1=4.8,2=9.6,  ",   // 283 - COM3 baud rate
  "0=Dis 1=Buzz Once/HC",   // 284 - HC Acknowledge ATT Buzzer
  "Min=0 Max=#Cars car#",   // 285 - Second Code Blue Car
  "1=DC,2=HEOFL,4=AuRst",   // 286 - Hall Elevator Off options 2timer 
  "  0 = OFF  1 = ON   ",   // 287 - Code blue Buzzer
  "  0 = OFF  1 = ON   ",   // 288 - Code Blue Override Independent
  "  0 = OFF  1 = ON   ",   // 289 - Code Blue Recall any
  "  +1=IND   +2=ATT   ",   // 290 - HEOF override independent
  "0=deflt,1=reOpn Stop",   // 291 - NYC FS2 Door Reopen on STP
  "  0 = OFF  1 = ON   ",   // 292 - Select/Prioritize ATT
  "  0 = CW   1 = CCW  ",   // 293 - Encoder Direction
  "0=OFF,1=ON (Cyc Pwr)",   // 294 - EMP recalled output en
  "0=OS,NCall,BTFL,4=SS",   // 295 - OSER control 1
  "Min=Bot  Max=Top Flr",   // 296 - Extra door time Location
  "0=OS,1=OSERL OutCtl1",   // 297 - OSER control 2
  "Min=0   Max=600  Sec",   // 298 - Timer for OSERL no asnwering call
  "Min=0   Max=600  Sec",   // 299 - Timer for OSERL car between floors
  "Min=0   Max=600  Sec",   // 300 - Timer for OSERL Safety String Open
  "0=same HW 1=diff HW ",   // 301 - Hoistway 2 fire loc
  "Min=0.5 Max=5.5  Sec",   // 302 - Retiring cam drop fail safe delay
  "0=Stp,1=CPrs,2=Momen",   // 303 - Med door reopen
  "0=Imm,1=Delayed,2=No",   // 304 - Med Ind override
  "0=std  1= CB -> EMS ",   // 305 - Code Blue Bypass Disable
  "0=no   1= DH in PI  ",   // 306 - Extended Door PI Message
  "Min=0 Max=#Cars car#",   // 307 - 1st Recall Car
  "Min=0 Max=#Cars car#",   // 308 - 1st EP Run Car
  "0=dis, 1=enable RCF ",   // 309 - RCM Cam out for freight
  "Min=0.0 Max=3.0  Sec",   // 310 - Lantern preference change delay
  "  0 = Off  1 = ON   ",   // 311 - DOB overrides DCB on phase 2
  "  0 = Off  1 = ON   ",   // 312 - Denver-Cl door after f1 recl
  "Min=1.0 Max=90.0 Sec",   // 313 - Denver FS phase 1 dwell time
  " 0=std, 1=both, 2=SR",   // 314 - HC Security ctrl
  "0=HC only,1=HC + CC ",   // 315 - Attendant Buzzer control
  " 0=Off    1=Enable  ",   // 316 - Recall in ind service
  "Min=10.0 Mx=60.0 Sec",   // 317 - Recall in ind service tmr
  "0=one,1=multi calls ",   // 318 - VIP Multiple Calls enable
  "Min=0 Max=30 Svc Num",   // 319 - Service Output Control
  "0=250k,1=125k   Baud",   // 320 - Can Encoder Baud Rate
  "Min=1  Max=127 Node#",   // 321 - Can Encoder Node ID
  "0=Disabled,1=Enabled",   // 322 - Code Blue allow single call
  "   0 = Dn  1 = Up   ",   // 323 - Sabbath collective mode
  "0=Frnt,1=Rear,2=Both",   // 324 - Return to lobby door open type
  "0=Not NCU/IR 1=Alwys",   // 325 - Ring the lantern in IR/NCU
  "0=dis  Max=Top Floor",   // 326 - High Priority Fl Number
  "Min=6.0 Mx=254.0 Sec",   // 327 - High Priority Fl Time
  "0=Run,1=RclRun,2=Rcl",   // 328 - EPS Sel
  "Min=5 Max=1500.0 Sec",	// 329 - Shutdown Alarm Timer
  "0=Disabled,1=Enabled",   // 330 - Auto service time-out
  " Mn=10 Mx=3200.0 Sec",   // 331 - Auto service time-out Time
  "0=Disabled,1=Enabled",   // 332 - Car call lockouts on sabbath
  "0=Disabled,1=Enabled",   // 333 - Med svc override car call sec
  "Min=0 Max=3200.0 Sec",   // 334 - HEOF Auto reset time
  "0=Disabled,1=Enabled",   // 335 - CCPBS on group car call sec
  "Min=1   Max=15   Sec",	// 336 - Governor Reset Pulse Time
  "Min=0.0 Max=120.0 in",   // 337 - Access UT distance in inches (G4 Only)
  "Min=0.0 Max=120.0 in",   // 338 - Access DT distance in inches (G4 Only)
  "1=Dbg,2=Galcm,3=DL20",   // 339 - Com 2 Port sel
  "0-3=19.2,38.4,57.6  ",   // 340 - 485 port baud rate
  " 1=Down Dir,2=Up Dir",   // 341 - Second riser CC Security by dir
  "0=Disabled,1=Enabled",   // 342 - Minimum short door time enable
  "0=Any Flr,+1=Rcl Flr",   // 343 - Recall Reset 2
  "   0 = N/O  1 = N/C ",   // 344 - Invert hall call security input (G4 Only)
  "Min=0.1 Max=0.500 in",	// 345 - Dead Zone for APS selector.
  "Min=10 Mx=3200.0 Sec",   // 346 - Security Disable time
  "Min=0.0 Max=2.0  Sec",   // 347 - EE Test Time
  "+1=F as R, +2=R as F",   // 348 - Reassign CC's when on security
  "1=F,+2=R,4=FIR,+8=RI",   // 349 - Disable opposite hc
  " Min=10  Max=30  Sec",   // 350 - Disable opposite hc tim
  "+1=Activate On DorCl",   // 351 - Hall Elevator Off options 3
  "+1=RC+2=DO,+4=CLF=DC",   // 352 - Car  Elevator Off options
  "+1=DC, ELOO, Aut Rst",   // 353 - Car  Elevator Off options 2
  "1=CB before FS Recll",   // 354 - Code Blue over Fire Service
  "+1=U-C,D-C+4=U-R,D-R",   // 355 - COP/Remote Disable Select
  "1=wait for CC in FS2",   // 356 - Fire Service 2 with special dev
  "1=PI Up,+2=PI Dn Dir",	// 357 - Sabbath disable variable 2
  "Min=1.0 Max=60.0 Sec",	// 358 - Hall Swing Door Dwell Time
  "Min=0 Max=3200.0 Sec",	// 359 - Independent service time-out timer
  "1=SD,2=DO,3=DM,4=DOL",	// 360 - Activate Voice
  " 0=Dis CC 1=Dis All ",	// 361 - Disable COP Control
  "Min=0 Max=3200.0 Sec",	// 362 - Auto IR Time-out delay
  "Min=0 Max=3200.0 Sec",	// 363 - Clocked output staying ON time
  "Min=0   Max=7       ",   // 364 - Gal Monitor Serial output packet control 1 = all cars, 2 = all floors, 4 = rear doors
  "Min=0   Max=10.0 Sec",   // 365 - GAL Monitor Serial interval timer 100 msec timer 
  "Min=0   Max=3       ",   // 366 - GAL Monitor Serial Update control 1 = change of state, 2 = packet request
  "0=Disable, 1=Enable ",	// 367 - Automatic Wifi Setup
  "Min=0   Max=9       ",	// 368 - Automatic Wifi Setup
};

const char LCD_Field_Vars[lastfvar+1][21] = {
  " Y Delta Time=      ",   // 000 - Y Delta Time
  "   Fault Time=      ",	// 001 - Fault Time
  "   Reset Time=      ",	// 002 - Reset Time
  "Double Stroke=      ",	// 003 - Double Stroke
  " Lant On Time=      ",	// 004 - Lant On Time
  "Lant Off Time=      ",	// 005 - Lant Off Time
  "Pas Chime Tim=      ",	// 006 - Pas Chime Time
  "Door Fail Tim=      ",	// 007 - Door Fail Time
  "Nudging Time =      ",	// 008 - Nudging Time
  "Preopen Delay=      ",	// 009 - Preopen Delay
  "     CC Dwell=      ",	// 010 - Car Call Dwell
  "     HC Dwell=      ",	// 011 - Hall Call Dwell
  "  Lobby Dwell=      ",	// 012 - Lobby Dwell
  "Handicap Dwll=      ",	// 013 - Handicap Dwell
  "NonInterfer T=      ",	// 014 - Non Interfer T
  "  Lobby Floor=      ",	// 015 - Lobby Floor
  "Fire Main Flr=      ",	// 016 - Fire Main Floor
  " ALT Fire Flr=      ",	// 017 - ALT Fire Floor
  "   Stall Time=      ",	// 018 - Stall Time
  "Soft Stop Tim=      ",	// 019 - Soft Stop Time
  "  Lt/Fan Time=      ",	// 020 - Gen/Lt/Fan Time
  "         Year=      ",	// 021 - Year
  "        Month=      ",	// 022 - Month
  "          Day=      ",	// 023 - Day
  "         Hour=      ",	// 024 - Hour
  "       Minute=      ",	// 025 - Minute
  "SafeTest Year=      ",	// 026 - Safe Test Year
  "SafeTst Month=      ",	// 027 - Safe Test Month
  "Safe Test Day=      ",	// 028 - Safe Test Day
  "    COM1 Baud=      ",	// 029 - User Baud Rate
  "      Parking=      ",	// 030 - Parking
  " Em Pwr Floor=      ",	// 031 - Em Power Floor
  "Em Power Cars=      ",	// 032 - Em Power Cars
  "1stRecall Car=      ",	// 033 - 1st Recall Car
  "1stEP Run Car=      ",	// 034 - 1st EP Run Car
  "Recall Timout=      ",	// 035 - Recall Timeout
  "DOB Over Nudg=      ",   // 036 - DOB Over Nudg
  "Emer Dispatch=      ",   // 037 - Emerg Dispatch
  "Lobby Request=      ",   // 038 - Lobby Request
  "  Next Car Up=      ",   // 039 - Next Car Up
  "Code Blue Car=      ",  	// 040 - Code Blue Car
  "       IR Car=      ",	// 041 - IR Car
  "LW Anti-nuisn=      ",	// 042 - LW Anti-nuisan
  "  Fire Sw Loc=      ", 	// 043 - Fire Sw Loc
  " ETA Min Time=      ",	// 044 - ETA Min Time
  "ETA Co CC Tim=      ",	// 045 - ETA Co CC Time
  " High Spd Ins=      ",	// 046 - High Speed Inspection Output
  "Vid Pos Car 1=      ",	// 047 - Vid Pos Car 1
  "Vid Pos Car 2=      ",	// 048 - Vid Pos Car 2
  "Vid Pos Car 3=      ",	// 049 - Vid Pos Car 3
  "Vid Pos Car 4=      ",	// 050 - Vid Pos Car 4
  "Vid Pos Car 5=      ",	// 051 - Vid Pos Car 5
  "Vid Pos Car 6=      ",	// 052 - Vid Pos Car 6
  "Vid Pos Car 7=      ",	// 053 - Vid Pos Car 7
  "Vid Pos Car 8=      ",	// 054 - Vid Pos Car 8
  "No Psg RunCnt=      ",	// 055 - No Psg Run Cnt
  " Ind Over Sec=      ",	// 056 - Ind Over Sec
  "UpPk Trig Tim=      ",	// 057 - Up Pk Trig Time
  "UpPk Trig Cnt=      ",	// 058 - Up Pk Trig Cnt
  "UpPk CC Count=      ",	// 059 - Up Pk CC Count
  "Up Peak Time =      ",	// 060 - Up Peak Time
  "DnPk Trig Tim=      ",	// 061 - Dn Pk Trig Time
  "DnPk Trig Cnt=      ",	// 062 - Dn Pk Trig Cnt
  "DownPeak Time=      ",	// 063 - Down Peak Time
  "Park Dly Time=      ",	// 064 - Park Delay Time
  "HC X-AssignEn=      ",	// 065 - HC X-Assign En
  "HCX-AssignETA=      ",	// 066 - HC X-Assign ETA
  " Med Em Floor=      ",	// 067 - Med Em Floor
  "Med Em Sw Loc=      ",	// 068 - Med Em Sw Loc
  "MachRm FirRet=      ", 	// 069 - MachRm Fire Ret
  "Hoistw FirRet=      ", 	// 070 - Hoistw Fire Ret
  " Recall Reset=      ",	// 071 - Recall Reset
  "ISER Outp Ctl=      ",	// 072 - Invert ISER
  "Display T-out=      ",   // 073 - Video time out
  "Ins Door Clos=      ",   // 074 - Door Close Outp. Ins.
  "Parking Flr 1=      ",   // 075 - Parking floor 1
  "Parking Flr 2=      ",   // 076 - Parking floor 2
  "Parking Flr 3=      ",   // 077 - Parking floor 3
  "Parking Flr 4=      ",   // 078 - Parking floor 4
  "Parking Flr 5=      ",   // 079 - Parking floor 5
  "Parking Flr 6=      ",   // 080 - Parking floor 6
  "Parking Flr 7=      ",   // 081 - Parking floor 7
  "Parking Width=      ",   // 082 - Parking width
  " Parking Type=      ",	// 083 - Parking Type
  "  Load Bypass=      ", 	// 083 - Load Bypass percent
  "Load Antinuis=      ", 	// 085 - Load Antinuisance percent
  "Load Dispatch=      ", 	// 086 - Load Dispatch percent
  "Load Overload=      ", 	// 087 - Load Overload percent
  "   IR Control=      ", 	// 088 - IR ControlFinishing
  "Att Buz Delay=      ",   // 089 - Attendant Buzzer Delay
  " Aux. Fire Sw=      ",   // 090 - Aux. Hall Fire Sw
  " Hall Fire Lt=      ",	// 091 - Hall fire light
  "COP/Remote CC=      ",	// 092 - COP/Remote CC Select
  "Door Dly Time=      ",	// 093 - Door Open or close delay time
  " Security Rcl=      ",	// 094 - Security Recall
  " DOB Over Sec=      ",   // 095 - DOB override securityCCS Rear Only.
  "ManDo Buz Dly=      ",   // 096 - Manual Door Buzzer Delay
  " Security Flr=      ",	// 097 - Security Floor
  "RC Pick Delay=      ",   // 098 - Retiring Cam pick delay timer
  "Shrt Dwll Tim=      ",	// 099 - Short dwell door time
  "   2nd IR Car=      ",	// 100 - 2nd IR Car
  "Stop At Lobby=      ", 	// 101 - Stop At lobby
  "   Invert CLF=      ",	// 102 - Invert CLF
  "   Invert TPL=      ", 	// 103 - Invert TPL
  "   Invert LPS=      ",   // 104 - Invert LPS
  "   Invert LOS=      ",   // 105 - Invert LOS
  "Nudg No Calls=      ",   // 106 - Nudge No Calls
  "  Fire Option=      ",   // 107 - Fire Option
  "Att CC frm HC=      ",	// 108 - Attendant HC sets car call
  " CB Door Time=      ",	// 109 - Code blue door open time
  "CB Req IndCar=      ",	// 110 - CB Req Ind Car
  "Flash CBLight=      ",	// 111 - Code blue light
  "HSV DoorCl CC=      ",   // 112 - HSV door close on Car call
  "IND DoorCl CC=      ",   // 113 - Ind Door CL CC
  "Single AutoPB=      ",   // 114 - Single Auto PB
  "DO No ActvDOL=      ",	// 115 - Door Open when no DOL
  "Remote OvrSec=      ", 	// 116 - Remote Station Override Security
  "FR ACO Dly Tm=      ", 	// 117 - Freight Auto Door Close Output Delay Time
  "DCB Canc Dwll=      ",	// 118 - Disable DCB cancel dwell time
  "Retrn To Lbby=      ",	// 119 - Return to lobby option
  "Non-Simul Dor=      ",	// 120 - Non-Simultaneous Doors
  "Preopen Doors=      ",	// 121 - Preopen Doors
  "Relev Dly Tim=      ",	// 122 - Relevel Delay Time
  "Fire Option 2=      ",   // 123 - Fire Option  2
  "ClGate NoPref=      ",   // 124 - Close gate,swing door no pref
  "  EE Time-out=      ",	// 125 - Electric Eye Time-out Time
  "OTS No HCCanc=      ",	// 126 - OTS No HC Canc
  "Nudge Dis Ctl=      ",	// 127 - Nudge Dis Cgrl
  "F1 DC Tim-out=      ",	// 128 - Phase 1 door close time-out
  "NoHC Dor Reop=      ",   // 129 - No HC Door Reop
  "RTL Dwell Tim=      ",	// 130 - Return to Lobby Door Dwell Time
  "NCU Lant Ctrl=      ",   // 131 - Next Up Direction Lant Ctl
  "NCU Pref Ctrl=      ",	// 132 - Next Up Preference Ctl
  "2nd Riser Ctl=      ",   // 133 - Second Riser Ctrl
  "2nd Risr Lant=      ",	// 134 - SR Lantern Ctl
  "ATT Pref Time=      ",   // 135 - Attendant ETA Pref
  "HB/PI DisNoFl=      ",   // 136 - HBZ/PI Dis at non-valid fl
  "VIP Door Time=      ",	// 137 - Vip Door Time
  "VIP Operation=      ",   // 138 - Vip Operation Flags
  "Nmbr Vip Cars=      ",   // 139 - Number of Vip Cars
  "EmPwr Op Outp=      ",   // 140 - EP Op LED function
  "EmPwr Pk Outp=      ",   // 141 - EP Park LED funct
  " HEOF Control=      ",   // 142 - Hall Elevator Off options
  " Alt Lbby Flr=      ",   // 143 - Alternate Lobby Fl
  "Alt Parkin Fl=      ",	// 144 - Alt Parking Fl
  "Lobby Req Ctl=      ",	// 145 - Lobby Req Cntrl
  "Handicap Load=      ",	// 146 - Handicap Capacity percent
  "FR DC Tim-out=      ",	// 147 - Freight door close time-out
  "Handicap Wait=      ",	// 148 - Handicap Car Wait
  "Short Fl Dist=      ",	// 149 - Short floor distance in inches
  "  RCM Control=      ",   // 150 - Retiring Cam Control
  "Rcl frm F1Alt=      ",	// 151 - Recall from FS1 Alt Floor
  "AttBuzOff Tim=      ",	// 152 - Attendant Buzzer Off Time
  "AttBuz On Tim=      ",	// 153 - Attendant Buzzer On Time
  "Shrt Fl Dn SD=      ",	// 154 - Short Fl Dn SD
  "ShrtMidF DnSD=      ",	// 155 - Mid Shrt Fl Dn SD
  "Shrt Fl Up SD=      ",	// 156 - Short Fl Up SD
  "ShrtMidF UpSD=      ",	// 157 - Mid Shrt Fl Up SD
  "ElevOff RetFl=      ",	// 158 - HS Elevator Off floor
  "PI Serv Msg 1=      ", 	// 159 - Service msg 1 display
  "PI Serv Msg 2=      ",  	// 160 - Service msg 2 display
  "ShortFl Cntrl=      ",   // 161 - Short Floor Control
  " Sec Recall 2=      ",	// 162 - Security Recall 2group recalls
  "EP Recall Dly=      ",   // 163 - EP Recall Delay
  "GrpCC Sec OvT=      ",   // 164 - Grp cc sec override tim
  "  HC On Brght=      ",	// 165 - HC on brightness
  "HC Off Bright=      ",   // 166 - HC off brightness
  "Access Top Fl=      ", 	// 167 - Access Top Floor
  "Access Bot Fl=      ",	// 168 - Access Bottom Floor
  "StopOn PosCnt=      ",   // 169 - Stop on position pulse
  " Sabb Restart=      ",   // 170 - Sabbath restart
  "FR Pwr DO Tim=      ",   // 171 - Freight Power Door open time
  " Auto Flt Dpy=      ",   // 172 - Automatically Display Fault
  "     Password=      ",   // 173 - Password
  "Pword Tim-out=      ",   // 174 - Password time-out
  "Behnd CC Canc=      ",	// 175 - Behind car call cancel
  "AdvDoor EnTim=      ",	// 176 - Adv de time non-simult doors
  "Grp TimerPark=      ",	// 177 - Grp Timer Parking
  " Short Fl hsf=      ",  	// 178 - Shrt fl hsf/no hsout
  " Up Pk Contrl=      ",	// 179 - Up peak control
  " Up Peak Pool=      ",	// 180 - Up peak pool
  "DnPeak Contrl=      ",	// 181 - Down peak control
  "DownPeak Pool=      ",	// 182 - Down peak pool
  "X-Assign Cars=      ",	// 183 - HC X-Assign Cars
  "AltRcl FS Off=      ",   // 184 - Fire alt rcl after fs off
  "AutoSwg DODly=      ",	// 185 - Auto Swing Door Open Delay Sec
  "CL Pulse Time=      ",	// 186 - CL Pulse Time
  "Run Cycle Tim=      ",	// 187 - Cycle Run time in hours
  "DoorOpenL Ctl=      ",	// 188 - Door Open Light control
  "HCUp On Color=      ",	// 189 - HCUp On Color
  "HCU Off Color=      ",	// 190 - HCUp Off Color
  " HC Sec Color=      ",   // 191 - HC Sec Color
  "   HC Sec Ctl=      ",   // 192 - HC Sec Lt
  "HC Sec Bright=      ",	// 193 - HC Sec brightness
  "HWS2 Fire Ret=      ", 	// 194 - Hoistway 2 fire ret
  "  CC On Color=      ",	// 195 - CC Button On Color
  " CC Off Color=      ",	// 196 - CC Button Off Color
  " CC On Bright=      ",	// 197 - CC output on brightness
  "CC Off Bright=      ",   // 198 - CC output off brightness
  " CC Light Ctl=      ",   // 199 - CC Button Light Control
  " CC Sec Color=      ",   // 200 - CC Button Security Color
  "CC Sec Bright=      ",	// 201 - CC Security brightness
  "  Sabb En Ctl=      ",   // 202 - Sabbath Enable variabletimer, 4= Lobby off 
  "Low Line Volt=      ",	// 203 - Low Line Voltage (RMS value)
  "Low Door Volt=      ",	// 204 - Low Door Voltage (RMS value)
  "EP Recovr Tim=      ",	// 205 - EP Recover Timeout
  " FireL Em Pwr=      ",	// 206 - Fire Light control during EP
  "EP Man Sel En=      ",	// 207 - EP Manual Sel En
  "FireL OTS Ret=      ",   // 208 - Fire Light control OTS
  "Sabbath Dwell=      ",   // 209 - Sabbath Door Dwell Time
  "Sabb Buzz Dly=      ",   // 210 - Sabbath Door Buzzer timer b4 DC
  " Sabb Dis Ctl=      ",	// 211 - Sabbath disable variable
  "EE Canc Dwell=      ",	// 212 - Electric Eye cancel door time
  "SkpCar@RcFLDO=      ",	// 213 - EP @ Rcl FL W/DOtime-delay
  "SkpCarN@RcFDO=      ",	// 214 - EP NOT @Rcl FL DOafter time-delay
  "Asgn ParkF DO=      ",	// 215 - Asgn Park Fl DO
  "Hall Lant Dly=      ",	// 216 - Hall Lantern Delay
  " Sabb En Ctl2=      ",	// 217 - Sabbath Enable control 2
  "Cab Lant Ctrl=      ",	// 218 - CLant Ctl
  "Mx Door Hld T=      ",	// 219 - Max Door Hold time from ED
  " Acc Door Cls=      ",	// 220 - Access run door close
  "CCAttUp Color=      ",   // 221 - Car Call Button Att Up Color
  "CCAttUpBright=      ",	// 222 - Car Call Att Up brightness
  "CCAttDn Color=      ",   // 223 - Car Call Button Att Dn Color
  "CCAttDnBright=      ",	// 224 - Car Call Att Dn brightness
  "Fire Lt Color=      ",   // 225 - Fire light Color
  "Fir Lt Bright=      ",	// 226 - Fire light brightness
  " Med Lt Color=      ",   // 227 - Medical light Color
  "Med Lt Bright=      ",	// 228 - Medical light brightness
  "Emer Lt Color=      ",   // 229 - Emergency light Color
  " Em Lt Bright=      ",	// 230 - Emergency light brightness
  " OTS Lt Color=      ",   // 231 - OTS light Color
  "OTS Lt Bright=      ",	// 232 - OTS light brightness
  " Backlight Lt=      ",   // 233 - Backlight Output lightsOTS,Bit4:Att,Bit5:non-cc
  " CAN Sync Cnt=      ",	// 234 - Can Sync Count 1/4sec
  "HCDn On Color=      ",   // 235 - HCDn On color
  "HCDn OnBright=      ",	// 236 - HCDn On brightness
  "HCD Off Color=      ",   // 237 - HCDn Off color
  "HCD Off Brght=      ",	// 238 - HCDn Off brightness
  "  CB On Color=      ",   // 239 - HC CB On color
  " CB On Bright=      ",	// 240 - HC CB On brightness
  " Vip On Color=      ",   // 241 - HC Vip On color
  "Vip On Bright=      ",	// 242 - HC Vip On brightness
  "IRUp On Color=      ",   // 243 - HCIR Up On color
  "IRU On Bright=      ",	// 244 - HCIR Up On brightness
  "IRDn On Color=      ",   // 245 - HCIR Dn On color
  "IRD On Bright=      ",	// 246 - HCIR Dn On brightness
  "IRU Off Color=      ",   // 247 - HCIR Up Off color
  "IRU Off Brght=      ",	// 248 - HCIR Up Off brightness
  "IRD Off Color=      ",   // 249 - HCIR Dn Off color
  "IRD Off Brght=      ",	// 250 - HCIR Dn Off brightness
  "HCU On Bright=      ",	// 251 - HCUp On brightness
  "HCU Off Brght=      ",	// 252 - HCUp On brightness
  "CB Button Loc=      ",	// 253 - CB Button Loc
  "Vip Buttn Loc=      ",	// 254 - Vip Location
  "IR Color Ctrl=      ",	// 255 - IR light color control
  " CB Off Color=      ",   // 256 - HC CB Off color
  "CB Off Bright=      ",	// 257 - HC CB Off brightness
  "Vip Off Color=      ",   // 258 - HC Vip Off color
  "Vip Off Brght=      ",	// 259 - HC Vip Off brightness
  "Vip Lant Ctrl=      ",	// 260 - Vip lantern control
  "GrpCC Ovrride=      ",	// 261 - Group CC Override Ctrl
  "ExclusionFLT1=      ",	// 262 - Exclusion fault 1
  "ExclusionFLT2=      ",	// 263 - Exclusion fault 2
  "ExclusionFLT3=      ",	// 264 - Exclusion fault 3
  "ExclusionFLT4=      ",	// 265 - Exclusion fault 4
  "ExclusionFLT5=      ",	// 266 - Exclusion fault 5
  "ExclusionFLT6=      ",	// 267 - Exclusion fault 6
  "CAN Baud Rate=      ",	// 268 - Can Baud Rate
  " Arrival Lant=      ",   // 269 - Arrival Lantern
  "CB SRiser Car=      ",  	// 270 - Code Blue SR Car
  "CB Sel IR Car=      ",	// 271 - Code blue over IR car
  "CB IR Penalty=      ",   // 272 - IR Car CB penalty
  "INSEC Out Ctl=      ",   // 273 - In security Output invert
  "Manual Dir En=      ",   // 274 - Attendent manual dir enable
  "Encr Interval=      ",   // 275 - Encoder Debounce Interval
  "  Encr Sample=      ",	// 276 - Encoder number of samples
  "Chime on CC T=      ",	// 277 - Handicap buzzer on CC beep time
  "COM1 Port Sel=      ",	// 278 - Com 1 Port sel
  "    COM2 Baud=      ",	// 279 - User 2 Baud Rate
  "Cpu Timg Outp=      ",	// 280 - Cpu timing output control
  "PI Serv Msg 3=      ", 	// 281 - Service msg 3 display
  "HCasg SecType=      ",	// 282 - HC Asgn Secure Type
  "    COM3 Baud=      ",	// 283 - Com3 baud rate
  "   HC Ack Buz=      ",	// 284 - HC Acknowledge ATT Buzzer
  "     CB Car 2=      ",  	// 285 - Second Code Blue Car
  " HEOF Cntrl 2=      ",   // 286 - Hall Elevator Off options 2timer 
  " CB Buzz ctrl=      ",	// 287 - Code blue Buzzer
  "  CB Over Ind=      ",	// 288 - Code Blue Override Independent
  "CB Rcl anycar=      ",	// 289 - Code Blue Recall any
  "HEOF Override=      ",	// 290 - HEOF override
  "FS2 Do Reopen=      ",	// 291 - NYC FS2 Door Reopen on STP
  "EP ATTcar 1st=      ",	// 292 - Select/Prioritize ATT
  "  Encoder Dir=      ",	// 293 - Encoder Direction
  "EP Rcl Out En=      ",	// 294 - EMP recalled output en
  "OSERL OutCtl1=      ",	// 295 - OSER control 1
  "Handcap T Flr=      ",	// 296 - Extra door time Location
  "OSERL OutCtl2=      ",	// 297 - OSER control 2
  "OSER NoCall T=      ",	// 298 - Timer for OSERL no asnwering call
  "OSER BtwFlr T=      ",	// 299 - Timer for OSERL car between floors
  "OSER SSopen T=      ",	// 300 - Timer for OSERL Safety String Open
  "HWS2 Fire Loc=      ",	// 301 - Hoistway 2 fire loc
  "RCDrop Fail T=      ",	// 302 - Retiring cam drop fail safe delay
  "MedDoorReopen=      ",	// 303 - Med door reopen
  "MedInd Ovrrid=      ",	// 304 - Med Ind override
  "EMS/HSafterCB=      ",	// 305 - Code Blue Bypass Disable
  " DoorHold Msg=      ",	// 306 - Extended Door PI Message
  "1st Rcl EPSF2=      ",	// 307 - 1st Recall Car
  "1st Run EPSF2=      ",	// 308 - 1st EP Run Car
  "RCF Output En=      ",	// 309 - RCM Cam out for freight
  "Lant Pref Dly=      ", 	// 310 - Lantern preference change delay
  "F2DOB ovr DCB=      ",	// 311 - DOB overrides DCB on phase 2
  "ClDoor F1 Rcl=      ",	// 312 - Denver-Cl door after f1 recl
  "F1 Door Dwell=      ",	// 313 - Denver FS phase 1 dwell time
  "HC Secur ctrl=      ", 	// 314 - HC Security ctrl
  " Att Buz ctrl=      ",	// 315 - Attendant Buzzer control
  "IND Rcl 2 Lby=      ",	// 316 - Recall in ind service
  "IND Rcl2Lby T=      ",	// 317 - Recall in ind service tmr
  "VIP multicall=      ",	// 318 - VIP Multiple Calls enable
  "Svc Light Ctl=      ",	// 319 - Service Output Control
  " Encoder Baud=      ",	// 320 - Can Encoder Baud Rate
  "   Enc NodeID=      ",	// 321 - Can Encoder Node ID
  "CB SingleCall=      ",	// 322 - Code Blue allow single call
  " Sabbath Mode=      ",	// 323 - Sabbath collective mode
  " RTL Door Sel=      ",	// 324 - Return to lobby door open type
  "LbyLan NCU/IR=      ",	// 325 - Ring the lantern in IR/NCU
  "Priorty Floor=      ",	// 326 - High Priority Fl Number
  "Priorty Flr T=      ",	// 327 - High Priority Fl Time
  "EPS Sel NoGrp=      ",	// 328 - EPS Sel
  "Shutdn Alrm T=      ", 	// 329 - Shutdown Alarm Timer
  "AutoSVC T-out=      ",	// 330 - Auto service time-out
  "AutoSVC tot T=      ",	// 331 - Auto service time-out Time
  "  CCS on Sabb=      ",	// 332 - Car call lockouts on sabbath
  "Med CCS Ovrrd=      ",	// 333 - Med svc override car call sec
  "HEOF AutoRstT=      ",	// 334 - HEOF Auto reset time
  "CCPBS Grp Sec=      ",	// 335 - CCPBS on group car call sec
  "GOV Rst Pls T=      ",	// 336 - Governor Reset Pulse Time
  "  Acc UT Dist=      ",	// 337 - Access UT distance in inches (G4 Only)
  "  Acc DT Dist=      ",	// 338 - Access DT distance in inches (G4 Only)
  "COM2 Port Sel=      ",	// 339 - Com 2 Port sel
  "Hall Lan Baud=      ",	// 340 - Hall Lantern port baud rate
  " SR CCSec Dir=      ",	// 341 - Second riser CC Security by dir
  "Min Door T En=      ",	// 342 - Minimum short door time enable
  "Recall Reset2=      ",	// 343 - Recall Reset 2
  "Invert HC Sec=      ",	// 344 - Invert hall call security input (G4 Only)
  "APS Dead Zone=      ",	// 345 - Dead Zone for APS selector.
  " Sec Dis Time=      ",	// 346 - Security Disable time
  " EE Test Time=      ", 	// 347 - EE Test Time
  "Sec ReasignCC=      ", 	// 348 - Reassign CC's when on security
  "Disabl Opp HC=      ",	// 349 - Disable opposite hc
  " Dis Opp HC T=      ",	// 350 - Disable opposite hc tim
  " HEOF Cntrl 3=      ",   // 351 - Hall Elevator Off options 3
  " CEOF Control=      ",   // 352 - Car  Elevator Off options
  " CEOF Cntrl 2=      ",   // 353 - Car  Elevator Off options 2
  "   CB over FS=      ",   // 354 - Code Blue over Fire Service
  "   COP/RM Dis=      ",	// 355 - COP/Remote Disable Select
  "F2 STP Recovr=      ",	// 356 - Fire Service 2 with special dev
  " Sabb Dis Ct2=      ", 	// 357 - Sabbath disable variable 2
  "Hall SwgD Dwl=      ", 	// 358 - Hall Swing Door Dwell Time
  " IND Time-out=      ", 	// 359 - Independent service time-out timer
  "    Act Voice=      ", 	// 360 - Activate Voice
  " Dis COP Ctrl=      ", 	// 361 - Disable COP Control
  "IR Tm-Out Dly=      ", 	// 362 - Auto IR Time-out delay
  "Clkd Outp Tim=      ", 	// 363 - Clocked output staying ON time
  "GMON Pkt Ctrl=      ",	// 364 - Gal Monitor Serial output packet control 1 = all cars, 2 = all floors, 4 = rear doors
  "GMON Intrvl T=      ",	// 365 - GAL Monitor Serial interval timer 100 msec timer 
  "GMON Upd Ctrl=      ",	// 366 - GAL Monitor Serial Update control 1 = change of state, 2 = packet request
  "AutWifi Setup=      ",	// 367 - Automatic Wifi Setup
  " AP SSID Nmb =      ", 	// 368 - Automatic Wifi Setup
};

#pragma section all_types

#define Num_Fvars_Menus 9
uint16 grp_fvars_chksum[Num_Fvars_Menus];


/*
												  Car Motion
												   |  Car Timers
												   |   |   Car Options
												   |   |   |   Service Options
												   |   |   |   |   Fire & Medical Services
												   |   |   |   |   |   Group Dispatch
												   |   |   |   |   |   |   Group Options
												   |   |   |   |   |   |   |   Button Lighting
												   |   |   |   |   |   |   |   |   System Options
												   |   |   |   |   |   |   |   |   |   */
unsigned char const last_var [Num_Fvars_Menus] = {12, 47, 33, 45, 34, 35, 50, 49, 25};	// Hydro last index value  

#define Fvars_Per_Menu 60
uint16 const var_menu_tbl[Num_Fvars_Menus][Fvars_Per_Menu] = {
// Car Speed Profile Variables for Hydro - Car Motion
{
19,  // 019 - Soft Stop Time    					19 	C	0
9,	 // 009 - Preopen Delay 	 					9 	C	1
345, // 345 - Dead Zone for APS selector 			345 C   2
337, // 337 - Access UT distance in inches			337 C 	3
338, // 338 - Access DT distance in inches			338 C 	4
169, // 230 - Stop on position pulse				169 C   5
46,  // 046 - High Speed Inspection Output			046 C   6
156, // 208 - Short Fl Up SD     					156 C   7
154, // 206 - Short Fl Dn SD     					154 C   8
157, // 209 - Mid Shrt Fl Up SD  					157 C   9
155, // 207 - Mid Shrt Fl Dn SD  					155 C   10
161, // 161 - Short Floor Ctl    					161 C   11
178, // 178 - Shrt fl hsf/no hsout 					178 C   12
219, // Unused 13
219, // Unused 14
219, // Unused 15
219, // Unused 16
219, // Unused 17
219, // Unused 18
219, // Unused 19
219, // Unused 20
219, // Unused 21
219, // Unused 22
219, // Unused 23
219, // Unused 24
219, // Unused 25
219, // Unused 26
219, // Unused 27
219, // Unused 28
219, // Unused 29
219, // Unused 30
219, // Unused 31
219, // Unused 32
219, // Unused 33
219, // Unused 34
219, // Unused 35
219, // Unused 36
219, // Unused 37
219, // Unused 38
219, // Unused 39
219, // Unused 40
219, // Unused 41
219, // Unused 42
219, // Unused 43
219, // Unused 44
219, // Unused 45
219, // Unused 46
219, // Unused 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},

// Car Timers
{
0,	 // 000 - Y Delta Time  						0   C	 0
1,	 // 001 - Fault Time 	  						1   C	 1
2,	 // 002 - Reset Time 	  						2   C	 2
4,	 // 004 - Lant On Time 	  						4   C	 3
5,	 // 005 - Lant Off Time 	  					5   C	 4
6,	 // 006 - Pas Chime Time 	  					6   C	 5
186, // 186 - CL Pulse Time							186 C	 6
277, // 227 - Handicap buzzer on CC beep time     	277	C	 7
7,	 // 007 - Door Fail Time 	  					7   C	 8
8,	 // 008 - Nudging Time 	  						8   C	 9
10,	 // 010 - Car Call Dwell 	  					10  C	 10 
11,	 // 011 - Hall Call Dwell	  					11  C	 11
12,	 // 012 - Lobby Dwell 	  						12  C	 12
13,	 // 013 - Handicap Dwell 	  					13  C	 13
99,  // 099 - Short dwell door time 				99  C    14
130, // 130 - Return to Lobby Door Dwell Time		130 C    15
109, // 109 - Code blue door open time  			109 C    16
14,	 // 014 - Non Interfer T 	  					14  C	 17
18,  // 018 - Stall Time 							18  C	 18
20,  // 020 - Gen/Lt/Fan Time 						20  C	 19
89,  // 089 - Attendant Buzzer Delay 				89  C    20
152, // 152 - Attendant Buzzer Off     				152 C	 21
153, // 153 - Attendant Buzzer On          			153 C	 22
93,  // 093 - Door Open or close delay time 		93  C    23
96,  // 096 - Manual Door Buzzer Delay  			96  C    24
98,  // 098 - Retiring Cam pick delay timer 		98  C    25
302, // 302 - Retiring cam drop fail safe delay 	302 C    26
122, // 122 - Relevel Delay Time 					122 C    27
125, // 168 - Electric Eye Time-out Time 			125 C    28
347, // 347 - EE Test Time							347 C	 29
128, // 128 - Phase 1 door close time-out 			128 C    30
137, // 137 - Vip Door Time                     	137 C    31
147, // 147 - Freight door close time-out			147 C	 32
171, // 171 - Freight Power Door open time			171 C    33		
176, // 176 - Adv de time non-simult doors			176 C    34
187, // 187 - Cycle Run time in hours				187 C    35
209, // 209 - Sabbath Door Dwell Time				209 C	 36
210, // 210 - Sabbath Door Buzzer timer b4 DC		210 C	 37
216, // 216 - Hall Lantern Delay					216 C	 38
219, // 219 - Max Door Hold time from ED  0 = dis	219 C    39
298, // 298 - Timer for OSERL no asnwering call   	298 C	 40
299, // 299 - Timer for OSERL car between floors  	299 C	 41
300, // 300 - Timer for OSERL Safety String Open  	300 C	 42
334, // 334 - HEOF Auto reset time					334 C	 43
317, // 317 - Recall in ind service tmr				317 C	 44
346, // 346 - Security disable time					346 C	 45
185, // 185 - Auto Swing Door Open Delay Sec		185 C	 46
329, // 329 - Shutdown Alarm Timer					329 C	 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},

// Car Option Variables for hydro
{
103, // 103 - Invert TPL						103 C   0
104, // 104 - Invert LPS          				104 C   1
105, // 105 - Invert LOS						105 C   2
72,  // 072 - Invert ISER          				72  C   3
295, // 295 - OSER control 1					295 C	4
297, // 297 - OSER control 2					297 C	5
102, // 102 - Invert CLF						102	C   6
3,	 // 003 - Double Stroke 	  				3   C	7
131, // 131 - Next Up Direction Lant Ctl		131 C   8
132, // 132 - Next Up Preference Ctl			132 C   9
134, // 134 - SR Lantern Ctl, 1=SR Cab Lant   	134 C   10
218, // 218 - CLant Ctl 1=do,2=dpm				218 C   11
269, // 269 - Arrival Lantern					269 C   12
310, // 310 - Lantern preference change delay 	310 C 	13
136, // 136 - HBZ/PI Dis at non-valid fl		136	C   14
36,  // 036 - DOB Over Nudg    					36  C   15
106, // 106 - Nudge No Calls      				106 C	16
127, // 127 - Nudge Dis Cgrl     				127 C   17
115, // 115 - Door Open when no DOL 			115 C   18
118, // 118 - Disable DCB cancel dwell time 	118 C   19
212, // 212 - Electric Eye cancel door time		212 C 	20
120, // 120 - Non-Simultaneous Doors 			120 C   21
121, // 121 - Preopen doors 					121 C   22
124, // 124 - Close gate,swing door,no pref   	124 C   23
129, // 129 - No HC Door Reop    				129 C   24  No hall call button door reopen with onward call
175, // 175 - Behind car call cancel			175 C   25
150, // 150 - Retiring Cam Control				150 C   26
92,  // 092 - COP/Remote CC Select   			92  C   27
355, // 355 - COP/Remote Disable				355 C	28
188, // 188 - Door Open Light control			188 C   29
296, // 296 - Extra door time Location			296 C	30
309, // 309 - RCM Cam out for freight			309 C	31
325, // 325 - Ring the lantern in IR/NCU		325 C   32
342, // 342 - Minimum short door time enable	342 C	33
219, // Unused 34
219, // Unused 35
219, // Unused 36
219, // Unused 37
219, // Unused 38
219, // Unused 39
219, // Unused 40
219, // Unused 41
219, // Unused 42
219, // Unused 43
219, // Unused 44
219, // Unused 45
219, // Unused 46
219, // Unused 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},

// Service Option Variables for hydro
{
15,  // 015 - Lobby Floor 						15 C	0
119, // 119 - Return to lobby option			119 C   1	+1 = cycle door, +2 = cancel car calls
324, // 324 - Return to lobby door open type  	324 C	2
101, // 101 - Stop At lobby						101 C   3
37,  // 037 - Emerg Dispatch   					37 C	4
74,  // 074 - Door Close Outp. Ins.				74 C    5
56,  // 056 - Ind Over Sec     					56 C 	6
113, // 113 - Ind Door CL CC	   				113 C   7
316, // 316 - Recall in ind service				316 C	8
94,  // 94  - Security Recall     				94  C   9
162, // 162 - Security Recall 2					162 C   10
97,  // 97  - Security Floor 					97  C   11
273, // 273 - In security Output invert			273 C   12
95,  // 95  - DOB override security 			95  C   13
335, // 335 - CCPBS on group car call sec		335 C 	14
341, // 341 - Second riser CC Security by dir 	341 C 	15
348, // 348 - Reassign car calls on SECFM		348 C	16
108, // 108 - Attendant HC sets car call 		108 C   17
274, // 274 - Attendent manual dir enable		274 C	18
284, // 284 - HC Acknowledge ATT Buzzer			284 C   19
315, // 315 - Attendant Buzzer control			315 C   20
138, // 138 - Vip Operation Flags				138 C   21
260, // 260 - Vip lantern control				260 C 	22
318, // 318 - VIP Multiple Calls enable			318 C	23
158, // 158 - HS Elevator Off floor				158 C 	24
142, // 142 - Elevator Off options          	142 C   25
286, // 286 - Elevator Off options 2         	286 C	26
351, // 351 - Hall Elevator Off options 3		351 C	27
290, // 290 - HEOF override independent			290 C   28
352, // 352 - Car  Elevator Off options			352 C	29
353, // 353 - Car  Elevator Off options 2		353 C	30
167, // 167 - Access Top Floor					167 C   31
168, // 168 - Access Bottom Floor				168 C   32
220, // 220 - Access run door close				220 C   33
159, // 159 - Service msg 1 display				159 C 	34
160, // 160 - Service msg 2 display				160 C 	35
281, // 281 - Service msg 3 display				281 C 	36
306, // 306 - Extended Door PI Message			306 C	37
319, // 319 - Service Output Control			319 C	38
332, // 332 - Car call lockouts on sabbath		332 C   39
202, // 202 - Sabbath Enable variable		    202 C 	40
217, // 217 - Sabbath Enable control 2 	    	217 C   41
211, // 211 - Sabbath disable variable			211 C   42
323, // 323 - Sabbath collective mode			323 C   43
42,  // 042 - LW Anti-nuisan   					42 C	44
55,  // 055 - No Psg Run Cnt   					55 C	45
219, // Unused 46
219, // Unused 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},
 
// Car Fire & Medical Services Variables for hydro
{
16,  // 016 - Fire Main Floor					16  C  	0
17,  // 017 - ALT Fire Floor					17  C	1
43,  // 043 - Fire Sw Loc 						43  C	2
90,  // 90 - Aux. Hall Fire Sw   				90  C 	3
151, // 151 - Recall from FS1 Alt Floor			151 C	4
91,  // 091 - Hall fire light     				91  C	5
69,  // 069 - MachRm Fire Ret					69  C	6
70,  // 070 - Hoistw Fire Ret					70  C	7
194, // 194 - Hoistway 2 fire ret				194 C   8
301, // 301 - Hoistway 2 fire loc				301	C	9
71,  // 071 - Recall Reset  					71  C 	10
343, // 343 - Recall Reset 2  					343 C 	11
107, // 107 - Fire Option         				107 C 	12
123, // 123 - Fire Option  2      				123 C 	13
128, // 128 - Phase 1 door close time-out 		128 C   14
184, // 184 - Fire alt rcl after fs off			184 C	15
206, // 206 - Fire Light control during EP		206 C   16
208, // 208 - Fire Light control OTS			208 C	17
311, // 311 - DOB overrides DCB on phase 2		311 C 	18
312, // 312 - Denver-Cl door after f1 recl		312 C 	19
313, // 313 - Denver FS phase 1 dwell time		313 C   20
356, // 356 - Fire Service 2 with special dev	356 C 	21
31,  // 031 - Em Power Floor					31 G  	22	Emergency Power Return Floor
67,  // 067 - Med Em Floor  					67 C 	23
68,  // 068 - Med Em Sw Loc  					68 C 	24
303, // 303 - Med door reopen 					303 C   25
304, // 304 - Med Ind override					304 C   26
333, // 333 - Med svc override car call sec		333 C	27
111, // 111 - Code blue light	 				111 C   28
287, // 287 - Code blue Buzzer					287 C   29
288, // 288 - Code Blue Override Independent 	288 C	30
305, // 305 - Code Blue Bypass Disable 			305 C 	31
322, // 322 - Code Blue allow single call		322 C 	32
354, // 354 - Code Blue over Fire Service		354 C 	33
112, // 112 - HSV door close on Car call		112 C   34
219, // Unused 35
219, // Unused 36
219, // Unused 37
219, // Unused 38
219, // Unused 39
219, // Unused 40
219, // Unused 41
219, // Unused 42
219, // Unused 43
219, // Unused 44
219, // Unused 45
219, // Unused 46
219, // Unused 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},

// Group Dispatch Variables
{
30,  // 030 - Parking			 		 30 G	0
64,  // 064 - Park Delay Time			 64 G  	1 	Parking Delay time
75,  // 075 - Parking floor 1			 75 G	2 
76,  // 076 - Parking floor 2			 76 G	3 
77,  // 077 - Parking floor 3			 77 G	4 
78,  // 078 - Parking floor 4	 	 	 78 G	5 
79,  // 079 - Parking floor 5	 	 	 79 G	6 
82,  // 082 - Parking width 	 	  	 82 G	7 
83,  // 083 - Parking Type     	  		 83 G   8
144, // 144 - Alt Parking Fl    	 	144 G	9
177, // 177 - Grp Timer Parking  		177 G	10
215, // 215 - Asgn Park Fl DO    		215 G   11	Assign parking floor to car with door open
15,  // 015 - Lobby Floor 			 	15  G	12
143, // 143 - Alternate Lobby Fl 		143 G	13
38,  // 038 - Lobby Request			 	38  G	14	  
145, // 145 - Lobby Req Cntrl    		145 G	15
39,  // 039 - Next Car Up				39  G	16
57,  // 057 - Up Pk Trig Time			57  G  	17 Up peak trigger time
58,  // 058 - Up Pk Trig Cnt			58  G  	18	Up Peak trigger count
59,  // 059 - Up Pk CC Count			59  G  	19	Up Peak car call count
60,  // 060 - Up Peak Time			 	60  G  	20	Up Peak Duration time
179, // 179 - Up peak control	   		179 G	21
180, // 180 - Up peak pool       		180 G	22	Cars removed from up peak pool
61,  // 061 - Dn Pk Trig Time			 61 G  	23	Down Peak trigger time
62,  // 062 - Dn Pk Trig Cnt			 62 G  	24	Down Peak trigger count
63,  // 063 - Down Peak Time			 63 G  	25	Down Peak Duration time
181, // 181 - Down peak control  		181 G	26
182, // 182 - Down peak pool      		182 G	27	Cars removed from down peak pool
44,  // 044 - ETA Min Time			 	 44 G	28
45,  // 045 - ETA Co CC Time			 45 G	29
326, // 326 - High Priority Fl Number	326	G	30
327, // 327 - High Priority Fl Time		327 G	31
330, // 330 - Auto service time-out		330 G   32
331, // 331 - Auto SVC time-out Time	331 G	33
349, // 349 - Disable opposite HC		349 G	34
350, // 350 - Disable op HC time 		350 G	35
219, // Unused 36
219, // Unused 37
219, // Unused 38
219, // Unused 39
219, // Unused 40
219, // Unused 41
219, // Unused 42
219, // Unused 43
219, // Unused 44
219, // Unused 45
219, // Unused 46
219, // Unused 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},

// Group Option Variables
{
31,  // 031 - Em Power Floor			 31 G  	0	Emergency Power Return Floor
32,  // 032 - Em Power Cars			 	 32 G  	1 	Number of cars to run on Emergency Power
33,  // 033 - 1st Recall Car			 33 G  	2	First EP return Car
307, // 307 - 1st Recall Car			307 G 	3	First EP return Car
34,  // 034 - 1st EP Run Car			 34 G  	4	First EP Run Car 
308, // 308 - 1st EP Run Car			308 G 	5	First EP Run Car 
163, // 163 - EP Recall Delay 	   		163 G	6
35,  // 051 - Recall Timeout			 35 G  	7	Recall Car Time-out 
205, // 205 - EP Recover Timeout  		205 G   8
207, // 207 - EP Manual Sel En	   		207 G   9
213, // 213 - EP @ Rcl FL W/DO   		213 G   10	 
214, // 214 - EP NOT @Rcl FL DO  		214 G   11 
140, // 140 - EP Op LED function 		140 G   12
141, // 141 - EP Park LED funct  		141 G   13
292, // 292 - Select/Prioratize ATT		292 G	14
294, // 294 - EMP recalled output en  	294 G	15	
40,  // 040 - Code Blue Car			 	 40 G	16
285, // 285 - Second Code Blue Car		285 G	17
289, // 289 - Code Blue Recall any 		289 G	18	 
270, // 270 - Code Blue SR Car			270 G	19
110, // 110 - CB Req Ind Car     		110 G   20   Code blue request independent car 
253, // 253 - CB Button Loc 	   		253 G	21
271, // 271 - Code blue over IR car		271	G	22
272, // 272 - IR Car CB penalty 		272 G	23
41,  // 041 - IR Car 		 			 41 G	24	
100, // 100 - 2nd IR Car		   		100 G	25
88,  // 088 - IR Control		   		 88 G   26
47,  // 047 - Vid Pos Car 1 			 47 G	27
48,  // 048 - Vid Pos Car 2 			 48 G	28	
49,  // 049 - Vid Pos Car 3 			 49 G	29	
50,  // 050 - Vid Pos Car 4			  	 50 G	30
51,  // 051 - Vid Pos Car 5			 	 51 G	31
52,  // 052 - Vid Pos Car 6			 	 52 G	32
65,  // 065 - HC X-Assign En 			 65 G  	33	Hall call cross assignment enable flag
66,  // 066 - HC X-Assign ETA			 66 G  	34	Hall Call cross assignment ETA
183, // 183 - HC X-Assign Cars   		183 G	35  Number of cars in the old group to assign calls
37,  // 037 - Emerg Dispatch   		 	 37 C	36
114, // 114 - Single Auto PB     		114 G   37
126, // 126 - OTS No HC Canc     		126 G   38
133, // 133 - Second Riser Ctrl  		133 G   39
135, // 135 - Attendant ETA Pref 		135 G   40
138, // 138 - Vip Op Flags 	   		 	138 G   41
139, // 139 - Number of Vip Cars 		139 G   42
254, // 254 - Vip Location       		254 G	43
148, // 148 - Handicap Car Wait  		148 G	44
164, // 164 - Grp cc sec ovr tim 		164 G	45
261, // 261 - Group CC Override Ctrl	261 G 	46
170, // 170 - Sabbath restart    		170 G	47
282, // 282 - HC Asgn Secure Type		282 G	48
314, // 314 - HC security ctrl			314 G	49
344, // 344 - Invert HC Sec Input		344	G	50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59 
},

// Color Light Options
{
195, // 195 - CC Button On Color				195 C 	0
197, // 197 - CC output on brightness			197 C 	1
196, // 196 - CC Button Off Color				196 C 	2
198, // 198 - CC output off brightness			198 C 	3
200, // 200 - CC Button Security Color			200 C 	4
201, // 201 - CC Security brightness			201 C 	5
221, // 221 - Car Call Button Att Up Color		221 C 	6
222, // 222 - Car Call Att Up brightness	    222 C 	7
223, // 223 - Car Call Button Att Dn Color		223 C 	8
224, // 224 - Car Call Att Dn brightness	    224 C 	9
199, // 199 - CC Button Light Control 			199 C 	10
225, // 225 - Fire light Color					225 C 	11
226, // 226 - Fire light brightness				226 C 	12
227, // 227 - Medical light Color				227 C 	13
228, // 228 - Medical light brightness			228 C 	14
229, // 229 - Emergency light Color				229 C 	15
230, // 230 - Emergency light brightness		230 C 	16
231, // 231 - OTS light Color					231 C 	17
232, // 232 - OTS light brightness				232 C 	18
233, // 233 - Backlight Output lights  			233 C 	19
165, // 165 - HC on brightness   				165 G   20
166, // 166 - HC off brightness  				166 G   21
189, // 189 - HCUp On Color 	   				189 G 	22
251, // 251 - HCUp On brightness				251 G 	23
190, // 190 - HCUp Off Color 	   				190 G 	24
252, // 252 - HCUp On brightness				252 G 	25
235, // 235 - HCDn On color	  					235 G 	26
236, // 236 - HCDn On brightness    			236 G 	27
237, // 237 - HCDn Off color					237	G	28
238, // 238 - HCDn Off brightness				238	G	29
243, // 243 - HCIR Up On color					243 G 	30
244, // 244 - HCIR Up On brightness				244 G 	31
247, // 247 - HCIR Up Off color					247 G   32
248, // 248 - HCIR Up Off brightness			248 G   33
245, // 245 - HCIR Dn On color					245 G 	34
246, // 246 - HCIR Dn On brightness				246 G 	35
249, // 249 - HCIR Dn Off color					249 G 	36
250, // 250 - HCIR Dn Off brightness			250 G 	37
255, // 255 - IR light color control			255 G 	38
239, // 239 - HC CB On color					239 G 	39
240, // 240 - HC CB On brightness				240 G 	40
256, // 256 - HC CB Off color					256 G 	41
257, // 257 - HC CB Off brightness				257 G 	42
241, // 241 - HC Vip On color					241 G 	43
242, // 242 - HC Vip On brightness				242 G 	44
258, // 258 - HC Vip Off color					258 G 	45
259, // 259 - HC Vip Off brightness				259 G 	46
191, // 191 - HC Sec Color	   					191 G 	47
193, // 193 - HC Sec brightness  				193 G   48
192, // 192 - HC Sec Lt 		   				192 G  	49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},

// System Options
{
268, // 268 - Can Baud Rate					268 C 	0
29,  // 029 - User Baud Rate   				 29 C	1
279, // 279 - User 2 Baud Rate				279 C   2
278, // 278 - Com Diag Port					278 C   3
339, // 339 - Com Diag Port Sel 2			339 C   4
26,  // 026 - Safe Test Year   				 26 C	5
27,  // 027 - Safe Test Month  				 27 C	6
28,  // 028 - Safe Test Day      			 28 C	7 
172, // 172 - Automatically Display Fault	172 C   8
173, // 173 - Password						173 C	9
174, // 174 - Password time-out				174 C   10
73,  // 073 - Video time out				 73 C   11
234, // 234 - Can Sync Count 1/4sec 		234 C   12
262, // 262 - Exclusion fault 1				262 C   13
263, // 263 - Exclusion fault 2 			263 C   14
264, // 264 - Exclusion fault 3				264 C   15
265, // 265 - Exclusion fault 4 			265 C   16
266, // 266 - Exclusion fault 5				266 C   17
267, // 267 - Exclusion fault 6 			267 C   18
283, // 283 - COM3 baud rate				283 C   19
340, // 340 - HL port baud rate				340 C	20
280, // 280 - Cpu timing output control		280 C   21
203, // 203 - Low Line Voltage (RMS value)	203 C 	22
204, // 204 - Low Door Voltage (RMS value)	204 C 	23
367, // 367 - Automatic Wifi Setup			367 C	24
368, // 368 - AP SSID number				368 C	25
219, // Unused 26
219, // Unused 27
219, // Unused 28
219, // Unused 29
219, // Unused 30
219, // Unused 31
219, // Unused 32
219, // Unused 33
219, // Unused 34
219, // Unused 35
219, // Unused 36
219, // Unused 37
219, // Unused 38
219, // Unused 39
219, // Unused 40
219, // Unused 41
219, // Unused 42
219, // Unused 43
219, // Unused 44
219, // Unused 45
219, // Unused 46
219, // Unused 47
219, // Unused 48
219, // Unused 49
219, // Unused 50
219, // Unused 51
219, // Unused 52
219, // Unused 53
219, // Unused 54
219, // Unused 55
219, // Unused 56
219, // Unused 57
219, // Unused 58
219, // Unused 59
},
};

#pragma section const_type

#if (GALaxy_4 == 1)
static const char SPB_Encoder_Type[5][21] = {
  "0=Standard Tape     ",
  "1=Governor Encoder  ",
  "2=Encoded Tape      ",
  "3=Governor Pulses   ",
  "4=Incremental Encode",
};
#endif

static const char LCD_Var_Labels[16][21] = {
  "   0 = Cool White   ",
  "   1 = Red          ",
  "   2 = Orange       ",
  "   3 = Yellow       ",
  "   4 = Chartreuse   ", 
  "   5 = Green        ", 
  "   6 = Aquamarine   ",
  "   7 = Cyan         ", 
  "   8 = Azure        ",
  "   9 = Blue         ",
  "  10 = Violet       ", 
  "  11 = Magenta      ", 
  "  12 = Rose         ",  
  "  13 = Rose White   ", 
  "  14 = Warm White   ", 
  "  15 = Cool White   ",
};

static const char LCD_Button_Sec_Light[8][21] = {
  "0=Light On Steady   ",
  "1=Invert Security   ",
  "2=Flash Security    ",
  "3=Flash/Invert Sec  ",
  "4=Sec Master Enable ",
  "5=Master Sec En/Inv ",
  "6=Mastr Sec En/Flash",
  "7=Mastr En/Flash/Inv",
};

static const char LCD_Backlight_Output[64][21] = {
  " 0=Backlight Off    ",
  " 1=Backlight Fire Lt",
  " 2=Backlight Med Lt ",
  " 3=Backlight Med/Fi ",
  " 4=Backlight Em Lt  ",
  " 5=Backlight Em/Fire",
  " 6=Backlight Emer/Md",
  " 7=Backlt Em/Med/Fi ",
  " 8=Backlight OTS Lt ",
  " 9=Backlight OTS/Fi ",
  "10=Backlight OTS/Med",
  "11=Backlt OTS/Med/Fi",
  "12=Backlight OTS/Em ",
  "13=Backlt OTS/Em/Fi ",
  "14=Backlt OTS/Em/Med",
  "15=Bcklt OS/Em/Md/Fi",
  "16=Backlight Att    ",
  "17=Backlt Att/Fire  ",
  "18=Backlt Att/Med   ",
  "19=Backlt Att/Med/Fi", 
  "20=Backlt Att/Emerg ",
  "21=Backlt Att/Em/Fi ",
  "22=Backlt Att/Em/Med",
  "23=Bklt Att/Em/Md/Fi",
  "24=Backlight Att/OTS",
  "25=Bklt Att/OTS/Fire",
  "26=Backlt Att/OS/Med",
  "27=Bklt Att/OS/Md/Fi",
  "28=Bklt Att/OTS/Emer",
  "29=Bklt Att/OS/Em/Fi",
  "30=Bklt Att/OS/Em/Md",
  "31=Att/OTS/Em/Md/Fi ",
  "32=Backlight Non-CC ",
  "33=Backlt Non-CC/Fi ",
  "34=Backlt Non-CC/Med",
  "35=Backlt NCC/Med/Fi", 
  "36=Backlt Non-CC/Em ",
  "37=Backlt NCC/Em/Fi ",
  "38=Backlt NCC/Em/Med",
  "39=Bklt NCC/Em/Md/Fi",
  "40=Backlt Non-CC/OTS",
  "41=Bklt NCC/OTS/Fire",
  "42=Backlt NCC/OS/Med",
  "43=Bklt NCC/OS/Md/Fi",
  "44=Bklt NCC/OTS/Emer",
  "45=Bklt NCC/OS/Em/Fi",
  "46=Bklt NCC/OS/Em/Md",
  "47=NCC/OTS/Em/Md/Fi ",
  "48=Backlt Non-CC/Att",
  "49=Backlt NCC/Att/Fi",
  "50=Backlt NCC/Att/Md",
  "51=Blt NCC/Att/Md/Fi", 
  "52=Backlt NCC/Att/Em",
  "53=Bklt NCC/At/Em/Fi",
  "54=Bklt NCC/At/Em/Md",
  "55=NCC/Att/Em/Md/Fi ",
  "56=Bklt NCC/Att/OTS ",
  "57=Blt NCC/Att/OS/Fi",
  "58=NCC/Att/OTS/Med  ",
  "59=NCC/Att/OTS/Md/Fi",
  "60=Blt NCC/Att/OS/Em",
  "61=NCC/Att/OTS/Em/Fi",
  "62=NCC/Att/OTS/Em/Md",
  "63=NC/At/OS/Em/Md/Fi",
};

static const char CAN_Encoder_Type[5][21] = {
  "0=Cons File Setting ",
  "1=Turck Encoder     ",
  "2=Dynapar Encoder   ",
  "3=Wachendorff Encodr",
  "4=Tape Selector Fdbk",
};

static const char UL_Dead_Zone_Sensor[16][21] = {
  " 0 =    ,   ,   ,UL1",
  " 1 =    ,   ,   ,UL1",
  " 2 =    ,   ,UL2,   ",
  " 3 =    ,   ,UL2,UL1",
  " 4 =    ,UL3,   ,   ",
  " 5 =    ,UL3,   ,UL1",
  " 6 =    ,UL3,UL2,   ",
  " 7 =    ,UL3,UL2,UL1",
  " 8 = UL4,   ,   ,   ",
  " 9 = UL4,   ,   ,UL1",
  "10 = UL4,   ,UL2,   ",
  "11 = UL4,   ,UL2,UL1",
  "12 = UL4,UL3,   ,   ",
  "13 = UL4,UL3,   ,UL1",
  "14 = UL4,UL3,UL2,   ",
  "15 = UL4,UL3,UL2,UL1",
};

static const char DL_Dead_Zone_Sensor[16][21] = {
  " 0 =    ,   ,   ,DL1",
  " 1 =    ,   ,   ,DL1",
  " 2 =    ,   ,DL2,   ",
  " 3 =    ,   ,DL2,DL1",
  " 4 =    ,DL3,   ,   ",
  " 5 =    ,DL3,   ,DL1",
  " 6 =    ,DL3,DL2,   ",
  " 7 =    ,DL3,DL2,DL1",
  " 8 = DL4,   ,   ,   ",
  " 9 = DL4,   ,   ,DL1",
  "10 = DL4,   ,DL2,   ",
  "11 = DL4,   ,DL2,DL1",
  "12 = DL4,DL3,   ,   ",
  "13 = DL4,DL3,   ,DL1",
  "14 = DL4,DL3,DL2,   ",
  "15 = DL4,DL3,DL2,DL1",
};


//				     {2400, 4800, 9600, 19.2, 38.4, 57.6, 115.2, 234375 baud}		

static const char Baud_Display[8][21] = {
  " 0 = 2400 Baud      ",
  " 1 = 4800 Baud      ",
  " 2 = 9600 Baud      ",
  " 3 = 19200 Baud     ",
  " 4 = 38400 Baud     ",
  " 5 = 57600 Baud     ",
  " 6 = 115200 Baud    ",
  " 7 = 230400 Baud    ",
};

static const char Drv_Baud_Display[4][21] = {
  " 0 = 19200 Baud     ",
  " 1 = 38400 Baud     ",
  " 2 = 57600 Baud     ",
  " 3 = 115200 Baud    ",
};

static const char Com_Sel_Display[8][21] = {
  "0=Comm Diag         ",
  "1=Comm Debug        ",
  "2=Galcom            ",
  "3=DL20              ",
  "4=Galcom Wireless   ",
  "5=Galcom Ethernet   ",
  "6=Galcom WiFiFlowCtl",
  "7=Galcom EthnFlowCtl",
};
static const char Xassign_Display[6][21] = {
  "0=No Cross Assign   ",
  "1=Front Cross Assign",
  "2=Cross Cancellation",
  "3=Invalid Selection ",
  "4=Rear Cross Assign ",
  "5=F & R X-Assignment",
};


static const char Fire_SW_Display[4][21] = {
  "0=Alt=Frnt,Main=Frnt",
  "1=Alt=Frnt,Main=Rear",
  "2=Alt=Rear,Main=Frnt",
  "3=Alt=Rear,Main=Rear",
};

static const char Fire_RST_Display[3][21] = {
  "0=Reset Aft Recall  ",
  "1=Reset Immediately ",
  "2=HFOff Rset FS Only",
};

static const char ISER_Display[6][21] = {
  "0=In Service Light  ",
  "1=Invert ISER output",
  "2=In Use Light      ",
  "3=Invert In Use Lt  ",
  "4=Car Shutdown      ",
  "5=Inv Car Shutdown  ",
};

static const char IR_CTL_Display[8][21] = {
  "0=IR Active ICR/RICR",
  "1=IR Active IR Calls",
  "2=Finish CCs then IR",
  "3=Both Options 2 & 1",
  "4=Fin CC then IR Off",
  "5=Both Options 4 & 1",
  "6=Both Options 4 & 2",
  "7=Options 4, 2 & 1  ",
};

static const char FSO_Display[5][21] = {
  "0=FLH Phase 1 or 2  ",
  "1=FLH Phase 1 only  ",
  "2=Flash FLH Ph1 or 2",
  "3=Flash FLH Phase 1 ",
  "4=FLH Follows FL    ",
};

static const char RMCC_Display[8][21] = {
  "0=COP & Remote CC   ",
  "1=COP or Remote CC  ",
  "2=COP sent to Remote",
  "3=COP->RM, COP or RM",
  "4=Remote sent to COP",
  "5=RM->COP, COP or RM",
  "6=COP->RM & RM->COP ",
  "7=COP->RM or RM->COP",
};

static const char SEC_RCL_Display[4][21] = {
  "1=On SEC Activation ",
  "1=Cycle Front Door  ",
  "1=Cycle Rear Door   ",
  "1=After Each Run    ",
};

static const char DOB_SEC_Display[6][21] = {
  "0=No DOB Override   ",
  "1=Any Secured Floor ",
  "2=Group CC Lockouts ",
  "3=Rear CC Lockouts  ",
  "4=Front CC Lockouts ",
  "5=Grp Lockout Ind Sv",
};

static const char OP_LED_Display[4][21] = {
  "0=EP Operational Car",
  "1=Normal Power Cars ",
  "2=Emerg. Power Cars ",
  "3=EP Recall Cars    ",
};

static const char PK_LED_Display[3][21] = {
  "0=Parked @ Recall FL",
  "1=Pkd@RclFL or Selec",
  "2=Pkd@RclFL & Select",
};

static const char HEOF_Display[4][21] = {
  "1=Recall Car Key Sw ",
  "1=Keep Door Open @FL",
  "1=Light/Fan Time-out",
  "1=Door Close Tim-out",
};

static const char SEC_RCL_2_Display[3][21] = {
  "0=OuTofGrp 1stRecall",
  "1=OuTofGrp All Recls",
  "2=In Grp All Recalls",
};

static const char OPENL_Display[5][21] = {
  "1=F1 Return DoorOpen",
  "1=Lby Retrn DoorOpen",
  "1=EP Recall DoorOpen",
  "1=Door Close Tim-out",
  "1=Door Open All Flrs",
};

static const char OSER_CTL_Display[3][21] = {
  "1=Not Answering Call",
  "1=Stuck Between Flrs",
  "1=Safety String Open",
};

static const char SABB_EN_Display[3][21] = {
  "1=IR ovrride Sabbath",
  "1=Handicap Lby Dwell",
  "1=Turn Off Sabb @Lby",
};

static const char ELEV_OFF_Display[4][21] = {
  "1=Recall Car Key Sw ",
  "1=Keep Door Open @FL",
  "1=Light/Fan Time-out",
  "1=Door Close Tim-out",
};

static const char ELEV_OFF_2_Display[4][21] = {
  "1=DoorCl on Reversal",
  "1=No Flash ELO Light",
  "1=Auto Reset w/timer",
  "1=ELO Light Rcll Fin",
};

static const char RMCC_DIS_Display[4][21] = {
  "1=Up Dir Disable COP",
  "1=Dn Dir Disable COP",
  "1=Up Dir Dis RMCC   ",
  "1=Down Dir Dis RMCC ",
};

static  const char LCD_Statistics[18][21] = {
  "     Car Calls      ",
  "   Up Hall Calls    ",
  "  Down Hall Calls   ",
  " Up HCalls < 15 Sec ",
  " Up HCalls < 30 Sec ",
  " Up HCalls < 45 Sec ",
  " Up HCalls < 60 Sec ",
  " Up HCalls > 60 Sec ",
  " Dn HCalls < 15 Sec ",
  " Dn HCalls < 30 Sec ",
  " Dn HCalls < 45 Sec ",
  " Dn HCalls < 60 Sec ",
  " Dn HCalls > 60 Sec ",
  " Hall Calls < 15 Sec",
  " Hall Calls < 30 Sec",
  " Hall Calls < 45 Sec",
  " Hall Calls < 60 Sec",
  " Hall Calls > 60 Sec",
};

#define Num_Set_Calls_Menus 9
static  const char LCD_Setup_Calls[Num_Set_Calls_Menus][21] = {
  " Setup Car Calls    ",
  " Set Down Hall Calls",
  " Set Up Hall Calls  ",
  " Set Rear Car Calls ",
  " Set R Dn Hall Calls",
  " Set R Up Hall Calls",
  " Lockout F Car Calls",
  " Lockout R Car Calls",
  " Car Call Test      ",
};

static  const char LCD_Calls[8][21] = {
  "Hit Up/Dn to Change ",
  "or Enter to Set     ",
  "Car Call At Floor:  ",
  "Dn HC At Floor:     ",
  "Up HC At Floor:     ",
  "Rear CC At Floor:   ",
  "RDn HC At Floor:    ",
  "RUp HC At Floor:    ",
};

static  const char LCD_Secure_Calls[8][21] = {
  "Hit Up/Dn to Change ",
  "Floor.  * = Secured ",
  "Hit Enter to Modify.",
  "F CC Access At:     ",
  "R CC Access At:     ",
  "  Sure you want to  ",
  "secure car calls? No",
  "secure car calls?Yes",
};

static  const char LCD_Car_Call_Test[4][21] = {
  "Hit Up/Dn to change ",
  "floor.  * = Selected",
  "Hit Enter to Modify.",
  "Car Call At Flr:    ",
};

static  const char LCD_Enable_Car_Call_Test[6][21] = {
  "  Sure you want to  ",
  "enable CC test? No  ",
  "enable CC test? Yes ",
  "Do you want to cont.",
  "with prev CC test? Y",
  "with prev CC test? N",
};


const char LCD_Fire_status[9][21] = {
  "No Fire Service     ",   // firef == 0
  "Fire PH1 Main Return",   // firef == 1
  "Fire PH1 Alt Return ",   // firef == 2
  "FS1 Return Complete ",   // firef == 3
  "Fire PH2 Door Hold  ",   // firef == 4
  "F2 Constant Press DO",   // firef == 5
  "F2 Constant Press DC",   // firef == 6
  "Fire PH2 Door Hold  ",   // firef == 7
  "FS2 Momentary DClose",   // firef == 8
};

const char LCD_Fire_door[5][14] = {
  "Door Closed  ",	 // doorf == 0
  "Door Opening ",	 // doorf == 1
  "Door Open    ",	 // doorf == 2
  "Door Closing ",	 // doorf == 3
  "Door Nudging ",	 // doorf == 4
};

const char LCD_Fire_rdoor[5][14] = {
  "RDor Closed  ",	 // rdoorf == 0
  "RDor Opening ",	 // rdoorf == 1
  "RDor Open    ",	 // rdoorf == 2
  "RDor Closing ",	 // rdoorf == 3
  "RDor Nudging ",	 // rdoorf == 4
};

const char LCD_Procf[29][21] = {
  " No Procedure Flag  ",
  "     Reset Mode     ",	// procf == 1
  "  Inspection Mode   ",	// procf == 2
  "      Up Fast       ",   // procf == 3 hsf==1 && dirf==1
  "   Up Transition    ",   // procf == 4 hsf==0 && UL==0
  "    Leveling Up     ",   // procf == 5 hsf==0 && UL==1
  "     Down Fast      ",   // procf == 6 hsf==1 && dirf==2
  "  Down Transition   ",   // procf == 7 hsf==0 && DL==0
  "   Leveling Down    ",   // procf == 8 hsf==0 && DL==1
  "  Emergency Stop    ",   // procf == 9
  "     Not Used       ",   // procf == 10
  " Emergency Slowdown ",   // procf == 11
  " Safety String Open ",   // procf == 12
  " Elevator Off Line  ",   // procf == 13
  "  Elevator Parked   ",   // procf == 14
  "  Waiting At Floor  ",   // procf == 15
  "   Door Procedure   ",   // procf == 16
  "  Elevator Stalled  ",   // procf == 17
  "  Reset Hydro Jack  ",   // procf == 18
  " Low Pressure Mode  ",	// procf == 19
  " Auto Learn HW Mode ",	// procf == 20
  " Emp Recovery Mode  ",	// procf == 21
  "    Hot Oil Mode    ",	// procf == 22
  "  Brake Test Mode   ",	// procf == 23
};

const char LCD_Procf2[9][11] = {
  "Up Fast    ",   // procf == 3 hsf==1 && dirf==1
  "Up Slowdown",   // procf == 4 hsf==0 && UL==0
  "Leveling Up",   // procf == 5 hsf==0 && UL==1
  "Down Fast  ",   // procf == 6 hsf==1 && dirf==2
  "Dn Slowdown",   // procf == 7 hsf==0 && DL==0
  "Leveling Dn",   // procf == 8 hsf==0 && DL==1
  "Emerg. Stop",   // procf == 9
  "Not Used   ",   // procf == 10
  "Em Slowdown",   // procf == 11
};

const char LCD_Statusf[33][21] = {
  "     Status OK      ",
  "   S10 Input Off    ",	// statusf = 0x1
  "    HC Input Off    ",	// statusf = 0x2
  "    SS Input Off    ",	// statusf = 0x4
  "  READY Input Off   ",   // statusf = 0x8                   
  " Gripper/EBK Fault  ",   // statusf = 0x10  		** MODIFIED FOR EBK
  "     I/O Error      ",	// statusf = 0x20  
  " Insp or Byp Error  ",	// statusf = 0x40
  "  Bin. Pos. Error   ",   // statusf = 0x80                 
  "   Position Error   ",   // statusf = 0x100                
  "    AD Input Off    ",   // statusf = 0x200                
  "    CS Input Off    ",   // statusf = 0x400
  "  Door Zone Fault   ",	// statusf = 0x800
  "  Gate/Lock Fault   ",	// statusf = 0x1000
  "     P Input On     ",   // statusf = 0x2000
  "  Looking for DCL   ",   // statusf = 0x4000
  " Door Close Contact ",   // statusf = 0x8000
  " Brake Switch Fault ",	// statusf = 0x10000
  " TOC CAN Com Error  ",	// statusf = 0x20000
  "  DRIVE Com Error   ",	// statusf = 0x40000
  " Saf Proc Com Error ",   // statusf = 0x80000                   
  " DB Res. Temp. Trip ",   // statusf = 0x100000  
  " Run Fault:Shutdown ",	// statusf = 0x200000  
  " Annual Safety Test ",	// statusf = 0x400000
  "  Waiting for SAFE  ",   // statusf = 0x800000                 
  " Terminal Limit Flt ",   // statusf = 0x1000000                
  "   GTS Input Off    ",   // statusf = 0x2000000                
  " UL,DL,DZ Off at FL ",   // statusf = 0x4000000
  "  Brake CAN Error   ",	// statusf = 0x8000000
  " Fire Stop Sw. Off  ",	// statusf = 0x10000000
  " SEL CAN Com Error  ",   // statusf = 0x20000000
  "   UL or DL Fault   ",   // statusf = 0x40000000
  "   Leveling Fault   ",   // statusf = 0x80000000
};


const char LCD_Statusf2[33][21] = {
  "     Status OK      ",
  " Hardware Init Flt  ",	// statusf = 0x1
  " Front Door Cls Flt ",	// statusf = 0x2
  " Rear Door Clos Flt ",	// statusf = 0x4
  " Line Voltage Fault ",   // statusf = 0x8                   
  " Door Voltage Fault ",   // statusf = 0x10  		
  " BK Lift Sw Run Flt ",	// statusf = 0x20  
  "   Door Motor OVL   ",	// statusf = 0x40
  " Learn Hoistway Flt ",   // statusf = 0x80                 
  "     UPS Fault      ",   // statusf = 0x100                
  " Em Brake CAN Error ",   // statusf = 0x200                
  " KEB Drv Not In Run ",   // statusf = 0x400
  " At Floor Shutdown  ",	// statusf = 0x800
  " 1036 Auto Run Hold ",	// statusf = 0x1000
  " Reset Run Failure  ",   // statusf = 0x2000
  " Invalid SEL Count  ",   // statusf = 0x4000
  " COP CAN Com Error  ",   // statusf = 0x8000
  " Enc CAN Com Error  ",	// statusf = 0x10000
  " IO Redundancy Test ",	// statusf = 0x20000
  " Gripper Relay Test ",	// statusf = 0x40000
  " Drive Not Powered  ",   // statusf = 0x80000                   
  " Normal Stop Timer  ",   // statusf = 0x100000  
  " Door Open Request  ",	// statusf = 0x200000  
  "  Waiting For DPM   ",	// statusf = 0x400000
  "  Waiting For RPM   ",   // statusf = 0x800000                 
  " Viscosity Control  ",   // statusf = 0x1000000                
  "  Leveling Request  ",   // statusf = 0x2000000                
  "  Term Speed Clamp  ",   // statusf = 0x4000000
  "  Speed Rate Clamp  ",	// statusf = 0x8000000
  " Front EE Test Flt  ",	// statusf = 0x10000000
  "  Rear EE Test Flt  ",   // statusf = 0x20000000
  " Setup Mode No Auto ",   // statusf = 0x40000000
  "                    ",   // statusf = 0x80000000
};

// Status: NTS APS Selector CAN fault
// Status: MC/SPD I/O fault


const char LCD_Statusf3[33][25] = {
  "Status OK               ",
  "SPB Safety CAN Flt PI=  ",	// statusf = 0x1
  "APS Vel Verify Flt PI=  ",	// statusf = 0x2
  "APS Sel Board Flt  PI=  ",	// statusf = 0x4
  "APS Sel CAN Flt    PI=  ",   // statusf = 0x8                   
  "NTS APS CAN Flt    PI=  ",   // statusf = 0x10  		
  "MC or SPD I/O Flt  PI=  ",	// statusf = 0x20  
  "Stop Sw AntiCreep  PI=  ",	// statusf = 0x40
  "                   PI=  ",   // statusf = 0x80                 
  "                   PI=  ",   // statusf = 0x100                
  "                   PI=  ",   // statusf = 0x200                
  "                   PI=  ",   // statusf = 0x400
  "                   PI=  ",	// statusf = 0x800
  "                   PI=  ",	// statusf = 0x1000
  "                   PI=  ",   // statusf = 0x2000
  "                   PI=  ",   // statusf = 0x4000
  "                   PI=  ",   // statusf = 0x8000
  "                   PI=  ",	// statusf = 0x10000
  "                   PI=  ",	// statusf = 0x20000
  "                   PI=  ",	// statusf = 0x40000
  "                   PI=  ",   // statusf = 0x80000                   
  "                   PI=  ",   // statusf = 0x100000  
  "                   PI=  ",	// statusf = 0x200000  
  "                   PI=  ",	// statusf = 0x400000
  "                   PI=  ",   // statusf = 0x800000                 
  "                   PI=  ",   // statusf = 0x1000000                
  "                   PI=  ",   // statusf = 0x2000000                
  "                   PI=  ",   // statusf = 0x4000000
  "                   PI=  ",	// statusf = 0x8000000
  "                   PI=  ",	// statusf = 0x10000000
  "                   PI=  ",   // statusf = 0x20000000
  "                   PI=  ",   // statusf = 0x40000000
  "                   PI=  ",	// statusf = 0x80000000
};

const char LCD_Statusf4[33][25] = {
  "Status OK               ",
  "                   PI=  ",	// statusf = 0x1
  "                   PI=  ",	// statusf = 0x2
  "                   PI=  ",	// statusf = 0x4
  "                   PI=  ",   // statusf = 0x8                   
  "                   PI=  ",   // statusf = 0x10  		
  "                   PI=  ",	// statusf = 0x20  
  "                   PI=  ",	// statusf = 0x40
  "                   PI=  ",   // statusf = 0x80                 
  "                   PI=  ",   // statusf = 0x100                
  "                   PI=  ",   // statusf = 0x200                
  "                   PI=  ",   // statusf = 0x400
  "                   PI=  ",	// statusf = 0x800
  "                   PI=  ",	// statusf = 0x1000
  "                   PI=  ",   // statusf = 0x2000
  "                   PI=  ",   // statusf = 0x4000
  "                   PI=  ",   // statusf = 0x8000
  "                   PI=  ",	// statusf = 0x10000
  "                   PI=  ",	// statusf = 0x20000
  "                   PI=  ",	// statusf = 0x40000
  "                   PI=  ",   // statusf = 0x80000                   
  "                   PI=  ",   // statusf = 0x100000  
  "                   PI=  ",	// statusf = 0x200000  
  "                   PI=  ",	// statusf = 0x400000
  "                   PI=  ",   // statusf = 0x800000                 
  "                   PI=  ",   // statusf = 0x1000000                
  "                   PI=  ",   // statusf = 0x2000000                
  "                   PI=  ",   // statusf = 0x4000000
  "                   PI=  ",	// statusf = 0x8000000
  "                   PI=  ",	// statusf = 0x10000000
  "                   PI=  ",   // statusf = 0x20000000
  "                   PI=  ",   // statusf = 0x40000000
  "                   PI=  ",	// statusf = 0x80000000
};


const char LCD_SS_Status[17][21] = {
  "  Safety Status OK  ",
  "  Governor Switch   ",	// safety_string_status = 0x1
  "  Top Final Limit   ",	// safety_string_status = 0x2
  " Bottom Final Limit ",	// safety_string_status = 0x4
  "     Pit Switch     ",   // safety_string_status = 0x8                   
  "  Hoistway Safety   ",   // safety_string_status = 0x10  
  "  Car Top Stop Sw   ",	// safety_string_status = 0x20
  " Car Safety Switch  ",	// safety_string_status = 0x40
  "  Rail Lock Switch  ",   // safety_string_status = 0x80                 
  "   FF Stop Switch   ",   // safety_string_status = 0x100                
  "  Car Stop Switch   ",   // safety_string_status = 0x200  
  " Motor Room Stop Sw ",   // safety_string_status = 0x400
  "  Gripper Trip Sw   ",   // safety_string_status = 0x800
  "Car Top Exit Switch ",	// safety_string_status = 0x1000
  "                    ",   // safety_string_status = 0x2000
  "                    ",   // safety_string_status = 0x4000
  "                    ",   // safety_string_status = 0x8000
};

const char LCD_Doorf[6][21] = {
  "Door Closed    PI=  ",	// doorf == 0
  "Door Opening   PI=  ",   // doorf == 1
  "Door Open      PI=  ",   // doorf == 2
  "Door Closing   PI=  ",   // doorf == 3
  "Door Nudging   PI=  ",   // doorf == 4
  "Door Ajar      PI=  ",   // doorf == 5
};

const char LCD_Rdoorf[6][21] = {
  "R Door Closed  PI=  ",	// rdoorf == 0
  "R Door Opening PI=  ",   // rdoorf == 1
  "R Door Open    PI=  ",   // rdoorf == 2
  "R Door Closing PI=  ",   // rdoorf == 3
  "R Door Nudging PI=  ",   // rdoorf == 4
  "R Door Ajar    PI=  ",   // rdoorf == 5
};

const char LCD_Door_dwell[2][21] = {
  "Door Dwelling  PI=  ",   // doorf == 2
  "RDoor Dwelling PI=  ",   // rdoorf == 2
};

const char LCD_Servf[47][21]={            // service flag
  "    Safety String   ",	//  servf = 0 Safety String
  " Inspection Service ",	//  servf = 1 Inspection
  "   Reset Service    ",	//  servf = 2 Reset Mode
  " Test Mode Service  ",	//  servf = 3 Test Mode
  "Hoistway Setup Fault",	//  servf = 4 Hoistway Setup 
  "Fire Fighters Stop S",	//  servf = 5 Fire Fighters Stop Switch
  "Machine Room Stop SW",	//  servf = 6 Machine Room Stop Switch
  "  Motion Stop Mode  ",	//  servf = 7 Motion Stop Mode
  "  At Floor Shutdown ",	//  servf = 8 AT Floor Shutdown
  " Communications Fail",	//  servf = 9 Comm Fail
  " Door Close Failure ",	//  servf = 10 Door Close Fail
  " Door Protection Svc",	//  servf = 11 Door Protection Service 
  "Stalled Out of Serv ",	//  servf = 12 Stalled
  "   Low Oil Service  ",	//  servf = 13 Low Oil
  " Earth Quake Service",	//  servf = 14 Earthquake
  "Emergency Power Serv",	//  servf = 15 Emergency Power
  "Fire Service Phase 2",	//  servf = 16 Fire Phase 2
  "Fire Ph 1 Main Retrn",	//  servf = 17 Fire Phase 1 Main
  "Fire Ph 1 Alt Return",	//  servf = 18 Fire Phase 1 Alt
  "Emergency Pwr Recall", 	//  servf = 19 Emergency Power Recall
  "  Hospital Service  ",	//  servf = 20 Hospital Service
  " Medical Emergency  ",	//  servf = 21 Medical emergency Service
  " Code Blue Service  ",	//  servf = 22 Code Blue
  "    Low Pressure    ",	//  servf = 23 Low Pressure
  "  Hot Oil Operation ",	//  servf = 24 Hot Oil.
  "    Auto Door Off   ",	//  servf = 25 Auto Door Off
  "    Riot Control    ",	//  servf = 26 RIOT
  "Car Sw Elevator Off ",   //  servf = 27 Elevator Off Car Switch
  "Hall Sw Elevator Off",	//  servf = 28 Elevator Off Hall Switch
  "Car Sw Elevator Off2",	//  servf = 29 Car Off
  "  Return to Lobby   ",	//  servf = 30 Lobby Recall
  "Independent Service ",	//  servf = 31 Independent
  "  Priority Service  ", 	//  servf = 32 VIP Service
  "Calibrate Load Weigh", 	//  servf = 33 Load Weigher Calibration
  " Reset Jack Service ", 	//  servf = 34 Reset Jack
  "Load Weigh Overload ", 	//  servf = 35 Load Weigh Overload
  "Load Weighing Bypass", 	//  servf = 36 Load Bypass
  " Extended Door Time ", 	//  servf = 37 Extended Door Time
  "   Reset Going Up   ", 	//  servf = 38 Reset Up
  "  Reset Going Down  ", 	//  servf = 39 Reset Down
  "  Security Recall   ", 	//  servf = 40 Security Recall
  "    TUG Service     ", 	//  servf = 41 TUGS
  "  Sabbath Service   ", 	//  servf = 42 Sabbath Service
  " Attendant Service  ", 	//  servf = 43 Attendant
  "       Homing       ", 	//  servf = 44 Homing
  " Automatic Service  ", 	//  servf = 45 Auto 
  "                    ", 	//  servf = 46 Unused
};


const char LCD_Ins_Servf[9][21]={            // service flag
  "Invalid Insp Input  ",	// ins_servf = 0 invalid inspection input
  "      Car Top       ",	// ins_servf = 1 Car Top inspection
  "    Machine Room    ",	// ins_servf = 2 Machine Room Inspection
  "      Access        ",	// ins_servf = 3 Access Inspection
  "      In-Car        ",	// ins_servf = 4 In-Car inspection
  "Car Top Lock Bypass ",	// ins_servf = 5 Car Top Lock Bypass inspection
  "Car Top Gate Bypass ",	// ins_servf = 6 Car Top Gate Bypass inspection
  "Car Top G & L Bypass",	// ins_servf = 7 Car Top Gate and Lock Bypass inspection
  "COP HW Setup Jumper ",	// ins_servf = 8 Selector setup swtich is on
};

const char Service[47][20] = {            // service flag (Left Justified)
  "Safety String       ",	// servf = 0 Safety String
  "Inspection Service  ",	// servf = 1 Inspection
  "Reset Mode          ",	// servf = 2 Reset Mode
  "Test Mode Service   ",	// servf = 3 Test Mode
  "Hoistway Setup Fault",	// servf = 4 Hoistway Setup 
  "Fire Fighters Stop S",	// servf = 5 Fire Fighters Stop Switch
  "Machine Room Stop SW",	// servf = 6 Machine Room Stop Switch
  "Motion Stop Mode    ",	// servf = 7 Motion Stop Mode
  "At Floor Shutdown   ",	// servf = 8 AT Floor Shutdown
  "Communications Fail ",	// servf = 9 Comm Fail
  "Door Close Failure  ",	// servf = 10 Door Close Fail
  "Door Protection Svc ",	// servf = 11 Door Protection Service 
  "Stalled Out of Serv ",	// servf = 12 Stalled
  "Low Oil Service     ",	// servf = 13 Low Oil
  "Earth Quake Service ",	// servf = 14 Earthquake
  "Emergency Power Serv",	// servf = 15 Emergency Power
  "Fire Service Phase 2",	// servf = 16 Fire Phase 2
  "Fire Ph 1 Main Retrn",	// servf = 17 Fire Phase 1 Main
  "Fire Ph 1 Alt Return",	// servf = 18 Fire Phase 1 Alt
  "Emergency Pwr Recall",	// servf = 19 Emergency Power Recall
  "Hospital Service    ",	// servf = 20 Hospital Service
  "Medical Emergency   ",	// servf = 21 Medical emergency Service
  "Code Blue Service   ",	// servf = 22 Code Blue
  "Low Pressure        ",	// servf = 23 Low Pressure
  "Hot Oil Operation   ",	// servf = 24 Hot Oil.
  "Auto Door Off       ",	// servf = 25 Auto Door Off
  "Riot Control        ",	// servf = 26 RIOT
  "Car Sw Elevator Off ",   // servf = 27 Elevator Off Car Switch
  "Hall Sw Elevator Off",	// servf = 28 Elevator Off Hall Switch
  "Car Sw Elevator Off2",	// servf = 29 Car Off
  "Return to Lobby     ",	// servf = 30 Lobby Recall
  "Independent Service ",	// servf = 31 Independent
  "Priority Service    ", 	// servf = 32 VIP Service
  "Calibrate Load Weigh", 	// servf = 33 Load Weigher Calibration
  "Reset Jack Service  ", 	// servf = 34 Reset Jack
  "Load Weigh Overload ", 	// servf = 35 Load Weigh Overload
  "Load Weighing Bypass", 	// servf = 36 Load Bypass
  "Extended Door Time  ", 	// servf = 37 Extended Door Time
  "Reset Going Up      ", 	// servf = 38 Reset Up
  "Reset Going Down    ", 	// servf = 39 Reset Down
  "Security Recall     ", 	// servf = 40 Security Recall
  "TUG Service         ", 	// servf = 41 TUGS
  "Sabbath Service     ", 	// servf = 42 Sabbath Service
  "Attendant Service   ", 	// servf = 43 Attendant
  "Homing              ", 	// servf = 44 Homing
  "Automatic Service   ", 	// servf = 45 Auto 
  "                    ", 	// servf = 46 Unused
};

const char servf_tbl[47][4] = {
		"SAF",            // servf = 0 Safty String
		"INS",            // servf = 1 Inspection
		"RST",            // servf = 2 Reset Mode
		"TST",            // servf = 3 Test Mode
		"HSU",            // servf = 4 Hoistway Setup 
		"FFS",            // servf = 5 Fire Fighters Stop Switch
		"MRS",            // servf = 6 Machine Room Stop Switch
		"MOS",			  // servf = 7 Motion Stop
		"AFS",            // servf = 8 AT Floor Shutdown
		"CMF",            // servf = 9 Comm Fail
		"DCF",            // servf = 10 Door Close Fail
		"DPS",            // servf = 11 Door Protection Service 
		"STA",            // servf = 12 Stalled
		"LOL",            // servf = 13 Low Oil
		"EAQ",            // servf = 14 Earthquake
		"EMP",            // servf = 15 Emergency Power
		"FS2",            // servf = 16 Fire Phase 2
		"FSM",            // servf = 17 Fire Phase 1 Main
		"FSA",            // servf = 18 Fire Phase 1 Alt
		"EPR",			  // servf = 19 Emergency Power Recall
		"HSV",            // servf = 20 Hospital Service
		"MED",            // servf = 21 Medical emergency Service
		"CBL",            // servf = 22 Code Blue
		"LPR",            // servf = 23 Low Pressure
		"HOT",            // servf = 24 Hot Oil.
		"ADO",            // servf = 25 Auto Door Off
		"SEC",            // servf = 26 RIOT
        "EOF",            // servf = 27 Elevator Off Car Switch
		"HEO",            // servf = 28 Elevator Off Hall Switch
		"EO2",            // servf = 29 Car Off
		"RTL",            // servf = 30 Lobby Recall
		"IND",            // servf = 31 Independent
		"VIP",            // servf = 32 VIP Service
		"LWC",            // servf = 33 Load Weigher Calibration
		"JAK",            // servf = 34 Reset Jack
		"OVL",            // servf = 35 Load Weigh Overload
		"LBP",            // servf = 36 Load Bypass
		"EDT",            // servf = 37 Extended Door Time
		"RSU",            // servf = 38 Reset Up
		"RSD",            // servf = 39 Reset Down
		"SEC",            // servf = 40 Security Recall
		"TUG",            // servf = 41 TUGS
		"SAB",            // servf = 42 Sabbath Service
		"ATT",            // servf = 43 Attendant
		"HOM",            // servf = 44 Homing
		"AUT",            // servf = 45 Auto 
		"   ",            // servf = 46 Unused
		};


static  const char Set_Calls_Window[3][12] = {
  " --------- ",
  " Set CC  1 ",
  " --------- ",
};

static  const char Trace_Window[5][13] = {
  " ---Trace---",	// 0 - Border
  " Enter=Stop ",	// 1 - Stop Trace
  " Enter=Start",	// 2 - Start Trace
  " Mode=Exit  ",	// 3 - Exit
  " -----------",	// 4 - Border
};

static  const char LCD_Run_Status[3][21]={
  "Dmd=      Vel=      ",
  "Dif=      Dir=      ",
  "DP=            PI=  ",
};
#if ((Traction == 1) || (Tract_OL == 1))
static  const char LCD_Temp_Status[2][21]={
  "EXT Temp. = ----  F ",
  "SPB Temp. = ----  F ",
};
#endif
static  const char LCD_Run_Time[3][21]={
  "PTT=00.0  Run=000.0 ", 
  "SFl=0      PDO=00.0 ",
  "Lev=00.0   Roll=0   ",
};

static  const char LCD_Voltage[2][21]={
  "L1V=000.0  L2V=000.0",
  "L3V=000.0  DoV=000.0",
};

static const char LCD_Dpy_IO_Row[21] = {
  "      |      |      ",	// Seperate I/O
};

static  const char LCD_NTS_Status[4][21]={
  "NTS Count = 00000000",   // 4  - 12
  "Vel = 100 ^fpm      ",   // 5  - 6, 10, 11
  "UN*|UT*| DZ*| HWLrn*",   // 6  - 2,  6, 11, 19
  "DN*|DT*|OnL*| ClipF*",   // 7  - 2,  6, 11, 19
};
		

const char LCD_Fault[max_nmbflts+1][21]={
  "  No Current Fault  ",   // 000F - No Faults
  "    Reset Fault     ",   // 001F - Reset failure
  "   Position Fault   ",   // 002F - Elevator lost failure (position error)
  "Safety String Fault ",   // 003F - Safety string failure or no P
  " Door Zone On Fault ",   // 004F - Door zone on failure
  "   Stalled Fault    ",   // 005F - Stall failure
  "  Door Open Fault   ",   // 006F - Door open failure
  "  Door Close Fault  ",   // 007F - Door close failure
  "Rear Door Open Fault",   // 008F - Door open failure
  "Rear Door Close Flt ",   // 009F - Door close failure
  "Up Directional Fault",   // 010F - Up directional open
  "Dn Directional Fault",   // 011F - Down directional open
  "Hoistway Learn Fault",   // 012F - Hoistway not Learned
  " Stop Switch Fault  ",   // 013F - Stop switch open
  "S10 Fuse Blown Fault",   // 014F - LC fuse Blown
  "HC Fuse Blown Fault ",   // 015F - HC fuse Blown
  "  Group Comm Loss   ",   // 016F - Group Comm loss 
  "  Car 1 Comm Loss   ",   // 017F - Car 1 Comm Loss (Cannot have a Car 1 comm loss)
  "  Car 2 Comm Loss   ",   // 018F - Car 2 Comm Loss
  "  Car 3 Comm Loss   ",   // 019F - Car 3 Comm Loss
  "  Car 4 Comm Loss   ",   // 020F - Car 4 Comm Loss
  "  Car 5 Comm Loss   ",   // 021F - Car 5 Comm Loss
  "  Car 6 Comm Loss   ",   // 022F - Car 6 Comm Loss
  "  Car 7 Comm Loss   ",	// 023F - Car 7 Comm Loss
  "  Car 8 Comm Loss   ",   // 024F - Car 8 Comm Loss
  " RUN I/O Failed On  ",   // 025F - RUN input or output failed on
  " RUN I/O Failed Off ",   // 026F - RUN input or output failed off 
  "  SU I/O Failed On  ",   // 027F - UP input or output failed on
  " SU I/O Failed Off  ",   // 028F - UP input or output failed off
  "  SD I/O Failed On  ",   // 029F - DNR input or output failed on
  "  SD I/O Failed Off ",   // 030F - DNR input or output failed off
  " SUF I/O Failed On  ",   // 031F - UP Fast input or output failed on
  " SUF I/O Failed Off ",   // 032F - UP Fast input or output failed off
  " SDF I/O Failed On  ",   // 033F - DN Fast input or output failed on
  " SDF I/O Failed Off ",   // 034F - DN Fast input or output failed off
  "  MC I/O Failed On  ",   // 035F - MCC input or output failed on
  "  MC I/O Failed Off ",   // 036F - MCC input or output failed off 
  "Top Door Lock Fault ",   // 037F - Door Lock Top failed on
  "Mid Door Lock Fault ",   // 038F - Door Lock Middle failed on
  "Bot Door Lock Fault ",   // 039F - Door Lock Bottom failed on
  "  DPM Input Fault   ",   // 040F - Door lock Protection (DPM) on fault
  " Gate Switch Fault  ",   // 041F - Gate Switch failed on 
  "Rear Top Lock Fault ",   // 042F - Rear Door Lock Top failed on
  "Rear Mid Lock Fault ",   // 043F - Rear Door Lock Middle failed on
  "Rear Bot Lock Fault ",   // 044F - Rear Door Lock Bottom failed on
  " Rear Gate Sw Fault ",   // 045F - Rear Gate Switch failed on
  "DLT & DLT-1 Opposite",   // 046F - Door Lock Top DLT and DLT_1 failed opposite
  "DLM & DLM-1 Opposite",   // 047F - Door Lock Middle DLM and DLM_1 failed opposite
  "DLB & DLB-1 Opposite",   // 048F - Door Lock Bottom DLB and DLB_1 failed opposite
  " GS & GS_1 Opposite ",   // 049F - Gate Switch GS and GS_1 failed opposite 
  "RLM & RLM-1 Opposite",   // 050F - Rear Door Lock Middle RLM and RLM_1 failed opposite
  "RGS & RGS-1 Opposite",   // 051F - Rear Gate Switch RGS and RGS_1 failed opposite
  "  RPM Input Fault   ",	// 052F - Rear Door lock Protection (RPM) on fault
  "DPM Off/GS or DL On ",	// 053F - DPM off with gate or lock on
  "RPM Off/RGS or DL On",	// 054F - RPM off with rear gate or lock on 
  "   Car Safe Fault   ",   // 055F - Car Safe Fault
  "Car Safe Fault Preop",   // 056F - Car Safe Fault during preopening
  "Car Safe Fault Start",   // 057F - Car Safe Fault during start (door possibly not closed)
  "Inspection Input Flt",   // 058F - Inspection input error
  "Gate/Lock Byp Sw Flt",   // 059F - Gate or lock bypass error
  "Inspection Up/Dn Sw ",   // 060F - Up or down inspections switch error
  "HC Com Device Reset ",   // 061F - Hall call device reset
  "Car Com Device Reset",   // 062F - Car comm device reset
  "   Power Up Reset   ",   // 063F - Power Up Reset
  "LW Calibration Error",	// 064F - Load weigher calibration error
  "Run Fault: Shutdown ",   // 065F - Too many consecutive runs with faults
  "    Estop Fault     ",   // 066F - Three estops in a row
  " Speed Control Exit ", 	// 067F - Emergency exit
  " Low Pressure Fault ",	// 068F - low pressure switch error
  "Lowoil Switch Fault ",	// 069F - Low oil switch input fault
  " CTCan Bus Off Error",	// 070F - Can Bus Off error
  " MRCan Bus Off Error",	// 071F - Can Bus Off error
  " GRCan Bus Off Error",	// 072F - Can Bus Off error
  "Pulse Error > 75 fpm",	// 073F - Pulse count error, car > 75 fpm travel < 2in
  "Wrong Dir Pls Run Up",	// 074F - Pulse count wrong direction running up
  "Wrong Dir Pls Run Dn",	// 075F - Pulse count wrong direction running down
  "Governor Switch Flt ",	// 076F - Governor switch
  "Car Safety Sw. Fault",	// 077F - Car safety switch
  "Car Call Power Fuse ",	// 078F - Car call common fuse
  "Car Call Light Fuse ",	// 079F - Car call light common fuse
  "Hall Call Light Fuse",	// 080F - Hall call light common fuse
  "Fire Fighter Stop Sw",	// 081F - Fire Fighters Stop Switch
  " FST I/O Failed On  ", 	// 082F - FST output failed on or FSTI input failed on
  " FST I/O Failed Off ", 	// 083F - FST output failed off or FSTI input failed off
  " FSTP I/O Failed On ", 	// 084F - FSTP output failed on
  "FSTP I/O Failed Off ", 	// 085F - FSTP output failed off
  "APS SEL CAN Com Err ",  	// 086F - APS Selector board can error
  "Door Zone Aux On Flt",	// 087F - Door zone A on fault
  "Door Zone Off Fault ",	// 088F - Door zone off fault
  "DoorZone Aux Off Flt",	// 089F - Door zone A off fault
  " UL Failed On Fault ", 	// 090F - UL failed on
  " DL Failed On Fault ", 	// 091F - DL failed on
  "UL and DL Off Fault ",   // 092F - UL and DL off when expected on
  "UL,DL & DZ Off at FL", 	// 093F - UL DL and DZ off at floor
  "Field Vars Deflt Ini",	// 094F - Field variables initialized
  "Hoistway Default Ini",	// 095F - Hoistway initialized
  "Hoistway Update Init",	// 096F - Hoistway update table initialized
  "Invalid Floor Count ",	// 097F - Invalid floor count
  "Invlid Top Floor Cnt",	// 098F - Invalid top floor count
  "Invalid DN or DT Cnt",	// 099F - Invalid DN or DT count
  "Invalid UT or UN Cnt",	// 100F - Invalid UT or UN count
  "UL DL Dist Too Large",	// 101F - Invalid FL offset Count
  "HC DvrBd Rx from Top",	// 102F - Rx from top HC board fault  (nest 8 errors must be consecutive)
  " HC DvrBd Tx to Top ",	// 103F - Tx to top HC board fault
  "HC DvrBd Too Few Dev",   // 104F - Too few stations on bus
  "HC DvrBd TooMany Dev",	// 105F - Too many stations on bus
  "HC DrvBd Rx from Bot",	// 106F - Rx from bottom HC board fault
  " HC DrvBd Tx to Bot ",	// 107F - Tx to bottom HC board fault
  "Level Stop Cnt Fault",   // 108F - Leveling stop fault occured from incorrect count
  "EPRecall Car1 Tim-ot",	// 109F - Emergency Power Recall Time-out Car 1
  "EPRecall Car2 Tim-ot",	// 110F - Emergency Power Recall Time-out Car 2
  "EPRecall Car3 Tim-ot",	// 111F - Emergency Power Recall Time-out Car 3
  "EPRecall Car4 Tim-ot",	// 112F - Emergency Power Recall Time-out Car 4
  "EPRecall Car5 Tim-ot",	// 113F - Emergency Power Recall Time-out Car 5
  "EPRecall Car6 Tim-ot",	// 114F - Emergency Power Recall Time-out Car 6
  "EPRecall Car7 Tim-ot",	// 115F - Emergency Power Recall Time-out Car 7
  "EPRecall Car8 Tim-ot",	// 116F - Emergency Power Recall Time-out Car 8
  "EP Recall Car 1 OTS ",	// 117F - Emergency Power Recall Car Out of Service Car 1
  "EP Recall Car 2 OTS ",	// 118F - Emergency Power Recall Car Out of Service Car 2
  "EP Recall Car 3 OTS ",	// 119F - Emergency Power Recall Car Out of Service Car 3
  "EP Recall Car 4 OTS ",	// 120F - Emergency Power Recall Car Out of Service Car 4
  "EP Recall Car 5 OTS ",	// 121F - Emergency Power Recall Car Out of Service Car 5
  "EP Recall Car 6 OTS ",	// 122F - Emergency Power Recall Car Out of Service Car 6
  "EP Recall Car 7 OTS ",	// 123F - Emergency Power Recall Car Out of Service Car 7
  "EP Recall Car 8 OTS ",	// 124F - Emergency Power Recall Car Out of Service Car 8
  "Front Det Edge Fault",	// 125F - Front Detector Edge Time-out
  "Rear Det Edge Fault ",	// 126F - Rear Detector Edge Time-out
  "L1 Low Line Voltage ",	// 127F - L1 Line Voltage Low
  "L2 Low Line Voltage ",	// 128F - L2 Line Voltage Low
  "L3 Low Line Voltage ",	// 129F - L3 Line Voltage Low
  "Door Low Voltage Flt",	// 130F - Door Line Voltage Low
  "Lobby Hall Call Fuse",	// 131F - Lobby Call common fuse
  "Door Motor Overload ",	// 132F - Door Motor Overload
  "Hoist Motor Overload",	// 133F - Hoist Motor Overload
  "Car Top Stop Switch ",	// 134F - Car top stop switch 
  "Door Lock Safe Fault",	// 135F - Door lock safe fault
  "Car Gate Safe Fault ",	// 136F - Car Gate safe fault
  "FDoor Close Cont Flt",   // 137F - Door Close Contact safe fault
  "RDoor Close Cont Flt",	// 138F - Rear Door Close Contact safe fault
  "NTS Vars Setup Fault",	// 139F - NTS CPU parameter setup fault 
  "Motion Exit Ins Flt ",   // 140F - emergency motion exit from inspection 
  "Run Inhibit Rset Cnt",   // 141F - Run inhibit from reset count
  " At Floor Shutdown  ",   // 142F - At floor shutdown
  "   Hot Oil Fault    ",	// 143F - Hot Oil Fault
  "DZ Off Redundancy Ck",	// 144F - DZ lost durning Redundancy Test
  "CCB No Comm Board 1 ",	// 145F - Car Call Board local board 1 comm loss
  "CCB No Comm Board 2 ",	// 146F - Car Call Board local board 2 comm loss
  "CCB No Comm Aux Bd 1",	// 147F - Car Call Board local aux board 1 comm loss
  "CCB No Comm Aux Bd 2",	// 148F - Car Call Board local aux board 2 comm loss
  "   RCM / Lock Flt   ",	// 149F - Retiring Cam/Lock fault
  " User Variable Init ",	// 150F - User variable init
  "Load Weigh Var Init ",	// 151F - Load weigher init
  "MRAM Hardware Fault ",	// 152F - Mram Fault
  " CPU APS DZ Off Flt ",	// 153F - Selector Door zone off fault
  "Machine Room Stop Sw",	// 154F - Machine Room Stop Switch
  " HCDB Device Fault  ",	// 155F - Hall Call Driver board device fault
  " CCDB Device Fault  ",	// 156F - Car Call Driver board device fault
  " MRCAN Device Fault ",	// 157F - Device fault (must look up device code
  " CTCAN Device Fault ",	// 158F - Device fault (must look up device code
  " GRCAN Device Fault ",	// 159F - Device fault (must look up device code
  " MRCAN Device Reset ",	// 160F - Car comm device reset
  " CTCAN Device Reset ",	// 161F - Car comm device reset
  " GRCAN Device Reset ",	// 162F - Car comm device reset
  " Hatch Safety Fault ",	// 163F - Hatch safety fault
  " COP CAN Com Error  ",	// 164F - Top car device can comm error
  "FEP Fuse Blown Fault",	// 165F - Fire/Emergency Fuse Blown
  "DL20Phone test fail ",	// 166F - phone test failed
  "   Trace Trigger    ",	// 167F - trace trigger occured
  "EE Tst EE1 Failed ON", 	// 168F - EE1 front input failed ON fault 
  "EE Tst EE1 Faild OFF", 	// 169F - EE1 front input failed OFF fault 
  "EE Tst EE2 Failed ON", 	// 160F - EE2 front input failed ON fault
  "EE Tst EE2 Faild OFF", 	// 171F - EE2 front input failed OFF fault
  "EE Tst EER1 Faild ON", 	// 172F - EER1 rear input failed ON fault 
  "EE Tst EER1 Fail OFF", 	// 173F - EER1 rear input failed OFF fault
  "EE Tst EER2 Faild ON", 	// 174F - EER2 rear input failed ON fault
  "EE Tst EER2 Fail OFF", 	// 175F - EER2 rear input failed OFF fault
  "   FETST ON Fault   ", 	// 176F - front edge test output ON fault
  "  FETST OFF Fault   ", 	// 177F - front edge test output OFF fault
  "   RETST ON Fault   ", 	// 178F - rear edge test output ON fault
  "  RETST OFF Fault   ", 	// 179F - rear edge test output OFF fault
  "  MRAM Write Error  ",	// 180F - Mram Write error
  "FVARS Backup Tbl Err",	// 181F - Field Variable backup table error
  "FVARS Both Tbl Cksum",	// 182F - Field Variable and backup table checksum error
  "FVARS Tbl Chksum Err",	// 183F - Field Variable checksum error
  "FVARS Bckup Tbl Cksm",	// 184F - Field Variable backup checksum error
  " FVARS Backup Init  ",	// 185F - Field variable backup init
  "Aut Swg Fr Door Open",	// 186F - Swing front hall door open flt
  "Aut Swg Rr Door Open",	// 187F - Swing rear hall door open flt
  "LW Load Table Fault ",	// 188F - Load Weigher load table fault
  "   Shutdown Alarm   ",	// 189F - Car out of service and need mechanic
  "GOVRi Input On Fault",	// 190F - Governor Reset input GOVRi on fault
  "APS Sel Can Bus Off ",	// 191F - APS Selector can bus off
  "APS Selector CAN Err",	// 192F - Cedes/Elgo Selector APS Can comm error
  "APS Selector Fault  ",	// 193F - Cedes/Elgo Selector APS Fault
  "Emrgncy Dispatch Flt",	// 194F - Emergency Dispactch Fault to determine car went into this mode
  "PALF Input Failed On",	// 195F - PALF input failed on 
  "PALF Input Faild Off",	// 196F - PALF input failed off	
  "SUF I/O On Fault    ",	// 197F - SUF I/O on fault  
  "SDF I/O On Fault    ",	// 198F - SDF I/O on fault
  "SPD I/O On Fault    ",	// 199F - SPD I/O on fault
  "SPD I/O Off Fault   ",	// 200F - SPD I/O off fault
  "HW Count Read Fault ",	// 201F - Hoistway Count Read fault
  "HW Slowdown Cnt Flt ",	// 202F - Hoistway Slowdown Count fault
  "UT Failed On Fault  ",	// 203F - UT failed on
  "DT Failed On Fault  ",	// 204F - DT failed on
  " ASV Time-out Car 1 ", 	// 205F - Auto Service Time-out Car 1
  " ASV Time-out Car 2 ", 	// 206F - Auto Service Time-out Car 2
  " ASV Time-out Car 3 ", 	// 207F - Auto Service Time-out Car 3
  " ASV Time-out Car 4 ", 	// 208F - Auto Service Time-out Car 4
  " ASV Time-out Car 5 ", 	// 209F - Auto Service Time-out Car 5
  " ASV Time-out Car 6 ", 	// 210F - Auto Service Time-out Car 6
  " ASV Time-out Car 7 ", 	// 211F - Auto Service Time-out Car 7
  " ASV Time-out Car 8 ", 	// 212F - Auto Service Time-out Car 8
  "SPD Off Fault Moving",	// 213F - SPD I/O off fault
  "  NTS UN Failed On  ",	// 214F - NTS UN Output failed on
  "  NTS DN Failed On  ",	// 215F - NTS DN Output failed on
  "  NTS UT Failed On  ",	// 216F - NTS UT Output failed on
  "  NTS DT Failed On  ",	// 217F - NTS DT Output failed on
  "  NTS UN Failed Off ",	// 218F - NTS UN Output failed off
  "  NTS DN Failed Off ",	// 219F - NTS DN Output failed off
  "  NTS UT Failed Off ",	// 220F - NTS UT Output failed off
  "  NTS DT Failed Off ",	// 221F - NTS DT Output failed off
  "  CPU UT Off Fault  ",	// 222F - CPU UT Output off fault
  "  CPU DT Off Fault  ",	// 223F - CPU DT Output off fault
  "  CPU UN Off Fault  ",	// 224F - CPU UN Output off fault
  "  CPU DN Off Fault  ",	// 225F - CPU DN Output off fault
  "CFLT Failed On Fault",	// 226F - CFLT input failed on during STE - CFLT test
  "CFLT Fail Off Fault ",	// 227F - CFLT input failed off during STE - CFLT test
  "CCF Input Failed On ",	// 228F - CCF input failed on during start
  "CCF Input Failed Off",	// 229F - CCF input failed off before start
  " IHS I/O Failed On  ",	// 230F - IHS I/O failed on
  " IHS I/O Failed Off ",	// 231F - IHS I/O failed off
  " Car Top Exit Switch",	// 232F - Car Top Exit Switch off
};

static  const char LCD_Fault_Xtra[2][21]={
  "ix=00,P= 1,F= G,#001",   // Line 1
  " AUT,  0:53:29  5/20",   // Line 2
};

static  const char LCD_Clear_Fault[5][21]={
  "   Press Enter to   ",
  " Clear the Fault Log",
  "      Fault Log     ",
  "       Cleared      ",
  "   No Occurrences   ",
};
static  const char LCD_Clear_Stats[4][21]={
  "   Press Enter to   ",
  "Clear Job Statistics",
  "   Job Statistics   ",
  "       Cleared      ",
};

static  const char LCD_Floor_SD[4][21]={
  "Floor  1 Count   ft ",
  " DS=                ",
  "P 1=                ",
  " US=                ",
};
static  const char LCD_Short_Floor_SD[4][21]={
  "Floor  1 Count   ft ",
  "SDS=                ",
  "P 1=                ",
  "SUS=                ",
};
static  const char LCD_Term_Limits[7][21]={
  "CPU Limit Count   ft",
  "UN =                ",
  "P 8=                ",
  "UT =                ",
  "DT =                ",
  "P 1=                ",
  "DN =                ",
};
static  const char LCD_lev_dist[4][21]={
  "  Leveling Distance ",
  "Dn Level =          ",
  "Up Level =          ",
  "PPI =               ",
};
static  const char LCD_final_stop[4][21]={
  "UL/DL Cnt=          ",
  "Offset Cnt=         ",
  "Vel=     EncVel=    ",
  "Pulses/Inch=        ",
};

static  const char LCD_aps_valid_fl_tbl[5][25]={
  "FL16....... 8......1",
  "   00000000 00000000",
  "CP16....... 8......1",
  "   00000000 00000000",
};


static  const char LCD_Timer_Menu[8][21] = {
  " Service Timer # 1  ",
  "Set Month/Day Timers",
  "Set Day of Week Tmrs",
  " Set Timer Service  ",
  "  Set Timer Logic   ",
  "View/Modify Tmr Stat",
  "Copy Day Of Week Tmr",
  "    Clear Timer     ",
};

static  const char LCD_Month_Day_Timer_Menu[4][21] = {
  "Mon/Day Tmr Date # 1",
  " Month/Day: 10/25   ",
  "   On Time: 06:53   ",
  "  Off Time: 07:53   ",
};

static  const char LCD_DOW_Timer_Menu[9][21] = {
  "DOW Timer: Saturday ",
  "DOW Timer: Sunday   ",
  "DOW Timer: Monday   ",
  "DOW Timer: Tuesday  ",
  "DOW Timer: Wednesday",
  "DOW Timer: Thursday ",
  "DOW Timer: Friday   ",
  "  On Time: 06:53    ",
  " Off Time: 07:53    ",
};

static  const char LCD_Timer_Status_Menu[4][21] = {
  "Timer Off / Disabled",
  "Timer On  / Disabled",
  "Timer Off / Enabled ",
  "Timer On  / Enabled ",
};

static  const char LCD_Timer_Service_Menu[17][21] = {
  "No Service Selected ",
  "      Parking       ",
  " Alternate Parking  ",
  "      Next Up       ",
  "      Up Peak       ",
  "     Down Peak      ",
  "  Alternate Lobby   ",
  " Alt Floor Security ",
  " Car Call Lockouts  ",
  " Group CC Lockouts  ",
  " Car Call Override  ",
  " Group CC Override  ",
  "      Sabbath       ",
  "   CC PB Security   ",
  " Floor Sec Table 2  ",
  " Floor Sec Table 3  ",
  " Floor Sec Table 4  ",
};

static  const char LCD_Timer_Copy_Menu[4][21] = {
  "Monday->Tues-Friday ",
  " Saturday -> Sunday ",
  " Mon->Tue-Fri Copied",
  "Sat -> Sunday Copied",
};

static  const char LCD_Timer_Clear_Menu[2][21] = {
  "Hit Ent to Clr Timer",
  "   Timer Cleared    ",
};

static  const char LCD_Timer_Logic[4][21] = {
  "     Input only     ",
  " Input=1 OR  Timer=1",
  " Input=1 AND Timer=0",
  " Input=1 AND Timer=1",
};

static  const char LCD_Dpy_Adjust_Menu[4][21] = {
  " Set LCD Contrast   ",
  " Set LCD Brightness ",
  " -.............+ 40 ",
  " -........+  8      ",
};

static  const char Password_dpy[3][21] = {
  "Please Enter Correct",
  "      Password      ",
  "   Enter Password   ",
 };

	
#pragma section all_types


// *******************************************
// This is the read an input procedure
// If voltage return 1 if no voltage return 0
// *******************************************
int16 rdLCDio(int16 bitloc)
{
	
  	if(SIU.GPDI[bitloc].B.PDI == 1)
 		return(1);
   	else
  		return(0);
}

#define short_delay 100
#define short_delay_2 80
#define long_delay 120

// ******************************************************
// This is initialize the lcd procedure 2/9/2001
// ******************************************************
void init_LCD()
{
  //lint -esym(438,k)
  //lint -esym(550,k)
  int16 i,j,k;
  
	delay(10000);			// delay to allow LCD to reset

  	for(i=0; i<=19; i++)	// Clearing LCD Display Buffer
  	{
      	LCD_Display[0][i] = ' ';
      	LCD_Display[1][i] = ' ';
      	LCD_Display[2][i] = ' ';
      	LCD_Display[3][i] = ' ';
  	}
  	FaultInterrupt = false;
  	Password = 0;		    //  input password = 0;
  	PasswordFlag = false;
  	LCD_State_ix = 0;
  	LCD_Menu = 0;
  	
  	
	for (j=0;j<=20000;j++)
	{
		if ((j & 0x01) != 0)
			k = j+5;		// delay
	}
  	write_display("       GALaxy       ", 0,0);
	delay(10000);			// delay to allow LCD to reset
	delay(10000);			// delay to allow LCD to reset
 	write_display("   Initialization   ", 1,0);
	delay(10000);			// delay to allow LCD to reset

  	LCD_Pointer = 1;
    LCD_Upd_Dpy = 1;


    LCD_Init = 1;		
	LCD_Menu = 6;		// Select initial screen to Elevator Status
}

// *****************************************************************
// This is re - initialize the lcd 10/30/2009 if sequence is pressed
// *****************************************************************

void reinit_LCD()
{

// This section checks for special sequence to restart the LCD interface
// Sequence: Mode + Up + Down + Up + Down
// Hitting enter resets the sequence






	static int16 LCD_sequence;
	int16 init = 0;


	if(LCD_Enter_PB == 0)
		LCD_sequence = 0;
		
	switch(LCD_sequence)
	{
		case 0:	//check Mode
			if (LCD_Mode_PB == 0)
				LCD_sequence = 1;
			break;
		case 1:	//check Up
			if ((LCD_Mode_PB == 0) || (LCD_DN_PB == 0) || (LCD_Enter_PB == 0))
				LCD_sequence = 0;
			else if (LCD_UP_PB == 0)
				LCD_sequence = 2;
			break;
		case 2:	//check Down
			if ((LCD_Mode_PB == 0) || (LCD_UP_PB == 0) || (LCD_Enter_PB == 0))
				LCD_sequence = 0;
			else if (LCD_DN_PB == 0)
				LCD_sequence = 3;
			break;
		case 3:	//check Up
			if ((LCD_Mode_PB == 0) || (LCD_DN_PB == 0) || (LCD_Enter_PB == 0))
				LCD_sequence = 0;
			else if (LCD_UP_PB == 0)
				LCD_sequence = 4;
			break;
		case 4:	//check Down
			if ((LCD_Mode_PB == 0) || (LCD_UP_PB == 0) || (LCD_Enter_PB == 0))
				LCD_sequence = 0;
			else if (LCD_DN_PB == 0)
				LCD_sequence = 5;
			break;
		case 5: // reinit LCD
			init_LCD();
			set_contrast(40);
			set_brightness(8);
			init = 1;
			LCD_sequence = 0;
			break;
		default:
			break;

	}
	
	if (init == 1)
	{
  		init = 0;
	  	LCD_Display[1][0] = ' ';
	  	LCD_Display[1][1] = ' ';
	  	LCD_Display[1][2] = ' ';
	  	LCD_Display[1][3] = ' ';
	  	LCD_Display[1][4] = ' ';
	  	LCD_Display[1][5] = 'C';
	  	LCD_Display[1][6] = 'O';
	  	LCD_Display[1][7] = 'N';
	  	LCD_Display[1][8] = 'T';
	  	LCD_Display[1][9] = 'R';
	  	LCD_Display[1][10] = 'O';
	  	LCD_Display[1][11] = 'L';
	  	LCD_Display[1][12] = 'L';
	  	LCD_Display[1][13] = 'E';
	  	LCD_Display[1][14] = 'R';
	  	LCD_Display[1][15] = ' ';
	  	LCD_Display[1][16] = ' ';
	  	LCD_Display[1][17] = ' ';
	  	LCD_Display[1][18] = ' ';
	  	LCD_Display[1][19] = ' ';
	}
}


//*************************************************
// This is refresh LCD Display
// it puts One character on the Display every cycle
//*************************************************
void Refresh_LCD()
{
  int16 i;
  int16 j = 0;
//  int16 fl_ix;
  int16 line_ptr;
  int16 start_ptr;
  static int16 grp_page_select;
  static int16 car_page_select;
  static int16 update_flt_status;
  static int16 up_dbn,dn_dbn,enter_dbn,mode_dbn;
  


  	petdog();
   	if(timers[tFlash] > 5)
	{
		LCD_Flash = 0;           
		if(timers[tFlash] > 10)
			timers[tFlash] = 0;
	}
  	else
		LCD_Flash = 1;

//  	if(timers[tsec] != 0)
//		  LCD_Flash = 0;           
//  	else
//		  LCD_Flash = 1;

  	if(rdLCDio(Lcd_MODE) == 1)
  	{
		if (mode_dbn > c_lcd_dbn_cnt)
  	    	LCD_Mode_PB = 2;
		else
			mode_dbn++;
  	}
  	else
  	{
		if (mode_dbn <= 0)
		{
			if (LCD_Mode_PB == 2)
				LCD_Mode_PB = 0;
			mode_dbn = 0;
		}
		else
			mode_dbn--;
  	}
  	if(rdLCDio(Lcd_ENTER) == 1)
  	{
		if (enter_dbn > c_lcd_dbn_cnt)
  	    	LCD_Enter_PB = 2;
		else
			enter_dbn++;
  	}
  	else
  	{
		if (enter_dbn <= 0)
		{
			if (LCD_Enter_PB == 2)
				LCD_Enter_PB = 0;
			enter_dbn = 0;
		}
		else
			enter_dbn--;
  	}
  	if(rdLCDio(Lcd_UP) == 1)
  	{
		if (up_dbn > c_lcd_dbn_cnt)
  	    	LCD_UP_PB = 2;
		else
			up_dbn++;
  	}
  	else
	{
		if (up_dbn <= 0)
		{
			if (LCD_UP_PB == 2)
				LCD_UP_PB = 0;
			up_dbn = 0;
		}
		else
			up_dbn--;
	}
  	if(rdLCDio(Lcd_DN) == 1)
  	{
		if (dn_dbn > c_lcd_dbn_cnt)
  	    	LCD_DN_PB = 2;
		else
			dn_dbn++;
  	}
  	else
	{
		if (dn_dbn <= 0)
		{
			if (LCD_DN_PB == 2)
				LCD_DN_PB = 0;
			dn_dbn = 0;
		}
		else
			dn_dbn--;
	}

	if (fvars[fvpassword] == 0)
		PasswordFlag = true;
	else if ((timers[tpassword] > (fvars[fvpwtime] + 100)) && (fvars[fvpwtime] > 0))
		PasswordFlag = false;			// shortest time-out is 10 seconds

 	if (statusf != prev_statusf)
	{
		prev_statusf = statusf;
	}
	if (Current_Fault != prev_fault)
	{
		if (Current_Fault !=0)
		{
	    	if ((fvars[fvfltdpy] == 1) && (LCD_Menu != 6))
	    	{				  // flag must be set and not in elevator status mode
				if (FaultInterrupt == false)
				{
					StoreLCDInfo();
	    			LCD_Menu = 24;
					LCD_Pointer = 24;
				}
				else
					LCD_Upd_Dpy = 1;
			}
		}
		prev_fault = Current_Fault;
	}
	if (procf != prev_procf)
	{
		prev_procf = procf;
	}
	if (servf != prev_servf)
	{
		prev_servf = servf;
	}


	reinit_LCD();


//*********************************************************
//*********************************************************
//********************* MAIN MENU *************************
//*********************************************************
//*********************************************************


	switch(LCD_Menu)
  	{
    	case 0:	// main menu
		  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		  	{
		  	    LCD_Mode_PB = 1;  			// Jump to Elevator Status
		  	    LCD_Init = 1;		
				LCD_Menu = 6;
				return;
		  	}
		  	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		  	{
		  	    LCD_Enter_PB = 1;  //
		  	    LCD_Menu = Main_Menu_list[LCD_Pointer];
		  	    LCD_Init = 1;		
		  	}
		  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		  	{
		  	    LCD_UP_PB = 1;  // increment to the next menu item
		  	    LCD_Pointer--;
		  	    if(LCD_Pointer < 1)
					  LCD_Pointer = Last_Menu;

//				if (cons[cc_pb_sec] == 0)
//				{
//					  if (LCD_Pointer == 11)
//					      LCD_Pointer = 10;
//				}


		  	    LCD_Upd_Dpy = 1;
		  	}
		  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		  	{
		  	    LCD_DN_PB = 1;  //
		  	    LCD_Pointer++;
		  	    if(LCD_Pointer > Last_Menu)
					  LCD_Pointer = 1;

//				if (cons[cc_pb_sec] == 0)
//				{
//				      if (LCD_Pointer == 11)
//						  LCD_Pointer = 12;
//				}
				
		  	    LCD_Upd_Dpy = 1;
		  	}
		  	if(LCD_Upd_Dpy == 1)
		  	{
			  	LCD_Upd_Dpy = 0;
		  		line_ptr = (LCD_Pointer - 1) % 3;
		  		start_ptr = LCD_Pointer - line_ptr;
		  	    for(i=0; i<=19; i++)
		  	    {
					LCD_Display[0][i] = LCD_Main_Menu[0][i];
					LCD_Display[1][i] = LCD_Main_Menu[Main_Menu_list[start_ptr]][i];
					if ((start_ptr + 1) > Last_Menu)
				  	{
				  		LCD_Display[2][i] = ' ';
				  		LCD_Display[3][i] = ' ';
				  	}
				  	else
				  	{
						LCD_Display[2][i] = LCD_Main_Menu[Main_Menu_list[start_ptr+1]][i];
						if ((start_ptr + 2) > Last_Menu)
					  		LCD_Display[3][i] = ' ';
						else
							LCD_Display[3][i] = LCD_Main_Menu[Main_Menu_list[start_ptr+2]][i];
				  	}
		  	    }
				LCD_Display[line_ptr+1][0] = '>';		// show cursor
		  	}
		  	if(timers[tsec] != 0)
		  	{
		  	    LCD_Display[0][10] = 'a';
		  	    LCD_Display[0][11] = 'x';
		  	    LCD_Display[0][12] = 'y';
		  	}
		  	else
		  	{
		  	    LCD_Display[0][10] = ' ';
		  	    LCD_Display[0][11] = ' ';
		  	    LCD_Display[0][12] = ' ';
		  	}
	      	break;

		case 1:	// Date and Time
			LCD_Menu = set_date_and_time(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 1;
			}
	      	break;

      	case 2:	// Adjustable Field Variables
      		LCD_Menu = adjust_field_variables(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 2;
			}
	      	break;
      	case 3:	// Job Statistics
      		LCD_Menu = job_statistics(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 3;
			}
	      	break;
      	case 4:	// Inputs and Outputs
			LCD_Menu = inputs_and_outputs(LCD_Menu);		  
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 4;
			}
	      	break;
		case 5:		// Setup Car and Hall Calls
			LCD_Menu = setup_car_and_hall_calls(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
				LCD_Pointer = 5;
			}
	      	break;
      	case 6:	// Elevator Status
      		LCD_Menu = run_elevator_status(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 6;
			}
	      	break;

      	case 7:	// View Fault Log
      		LCD_Menu = view_fault_log(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 7;
			}
	      	break;

		case 8:		// Elevator Setup
			LCD_Menu = Elevator_Setup(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 8;
			}
			break;

		case 9:	// Display Hoistway and Floor Tables
			LCD_Menu = display_hoistway_floor_table(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 9;
			}
			break;

		case 10:		  // Set Service Timers
			LCD_Menu = set_service_timers(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 10;
			}
			break;

		case 11:	   //Security Option
			LCD_Menu = cc_pb_security(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 11;
			}
			break;

		case 12:	// Set Video Display
			LCD_Menu = adjust_lcd_display(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 12;
			}
			break;

		case 13:		// Software version and jump to bios for upload
			LCD_Menu = software_utilities(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 13;
			}
	      	break;

 		case 14:	// Diagnostics 
 			LCD_Menu = diagnostics(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 14;
			}
			break;

		case 24:		// Display Immediate fault
			LCD_Menu = display_immediate_fault(LCD_Menu);
			if (LCD_Menu == 0)
			{
				LCD_Upd_Dpy = 1;
//				LCD_Pointer = 15;
			}
			break;
				
		case 25:	  // Password
			password(LCD_Menu);	
			break;
		   
		default:
			break;

  	}
//	write_LCD();
}

void write_LCD (void)
{
	int16 i;
	
	if ((upd_row_0 == 0) && (upd_row_1 == 0)) //switch pages
	{
		for(i=0; i<=19; i++)
		{
			if (LCD_Display[0][i] != LCD_Display_old[0][i])
			{
				LCD_Display_old[0][i] = LCD_Display[0][i];
				upd_row_0 = 1;
			}
			if (LCD_Display[1][i] != LCD_Display_old[1][i])
			{
				LCD_Display_old[1][i] = LCD_Display[1][i];
				upd_row_1 = 1;
			}
			
		}
		if ((upd_row_0 == 1) || (upd_row_1 == 1))
		{
			LCD_Cur_Pos = 0;
			for (i=0;i<=500;i++)
				;		// delay
			if (upd_row_0 == 1)
			{
				LCD_Line = 0;
			}
			else
			{
				LCD_Line = 1;
			}
		}
	}

	if ((upd_row_0 == 1) || (upd_row_1 == 1))
	{
		
		if(LCD_Line == 0)
	  	{
//			if (LCD_Display[0][LCD_Cur_Pos] == 0)		// Don't print a null character
//				LCD_Display[0][LCD_Cur_Pos] = ' ';			
			LCD_Cur_Pos++;
	  	}
	  	else
	  	{
//			if (LCD_Display[1][LCD_Cur_Pos] == 0)		// Don't print a null character
//				LCD_Display[1][LCD_Cur_Pos] = ' ';			
			LCD_Cur_Pos++;
	  	}
	  	

		if(LCD_Cur_Pos >= 20) //switch pages
		{

			for (i=0;i<=500;i++)
				;		// delay

		   	if(LCD_Line == 0)
		   	{
				
				upd_row_0 = 0;
				
			    LCD_Line = 1;
			    LCD_Cur_Pos = 0;
		   	}
		   	else
		   	{

				upd_row_1 = 0;

			    LCD_Line = 0;
			    LCD_Cur_Pos = 0;
		   	}

		}
	}
}


// ************************************************************
// Write Display Routine 
// Note: This routine should only be called when the car is on
// inspection or not alble to run 
//*************************************************************

void write_display(char *s, int16 row, int16 col)
{
	int16 i;
	int16 j = 0;
	
	if ((row == 0) && (col < 20))
	{
		
		for (i=col;i<=19;i++)
		{
			if (s[j] == 0)
				break;
			else
				LCD_Display[0][i] = s[j++];
		}
	}
	
	if ((row == 1) && (col < 20))
	{
		for (i=col;i<=19;i++)
		{
			if (s[j] == 0)
				break;
			else
				LCD_Display[1][i] = s[j++];
		}
	}
	
	if ((row == 2) && (col < 20))
	{
		for (i=col;i<=19;i++)
		{
			if (s[j] == 0)
				break;
			else
				LCD_Display[2][i] = s[j++];
		}
	}

	if ((row == 3) && (col < 20))
	{
		for (i=col;i<=19;i++)
		{
			if (s[j] == 0)
				break;
			else
				LCD_Display[3][i] = s[j++];
		}
	}

//	if (row <= 1)
//	{
		
//		upd_row_0 = 0;
//		upd_row_1 = 0;
	
//		for (i=0;i<=19;i++)
//			write_LCD();
//		
//	}

	if (row <= 3)
		write_dpyspi(row);
}


void StoreLCDInfo(void)
{
	int16 i;
	
	if (LCD_State_ix < 2)
	{
		LCD_State[LCD_State_ix].LCD_Menu = LCD_Menu;
	    LCD_State[LCD_State_ix].LCD_Pointer = LCD_Pointer;
		LCD_State[LCD_State_ix].LCD_Dig_Point = LCD_Dig_Point;
	    
	    for(i=0; i<=19; i++)
	    {
		  LCD_State[LCD_State_ix].LCD_Display[0][i] = LCD_Display[0][i];
		  LCD_State[LCD_State_ix].LCD_Display[1][i] = LCD_Display[1][i];
		  LCD_State[LCD_State_ix].LCD_Display[2][i] = LCD_Display[2][i];
		  LCD_State[LCD_State_ix].LCD_Display[3][i] = LCD_Display[3][i];
		}
		LCD_State_ix++;
	}	 
}

void ReturnLCDMenu(void)
{
	int16 i;
	int16 start_ptr;
	int16 line_ptr;
	
	if (LCD_State_ix > 0)
	{
		LCD_State_ix--;
		LCD_Menu = LCD_State[LCD_State_ix].LCD_Menu;
    	LCD_Pointer = LCD_State[LCD_State_ix].LCD_Pointer;		
		LCD_Upd_Dpy = 1;
		LCD_Dig_Point = LCD_State[LCD_State_ix].LCD_Dig_Point;	
    
		for(i=0; i<=19; i++)
    	{
	  	 	LCD_Display[0][i] = LCD_State[LCD_State_ix].LCD_Display[0][i];
	     	LCD_Display[1][i] = LCD_State[LCD_State_ix].LCD_Display[1][i];
	  	 	LCD_Display[2][i] = LCD_State[LCD_State_ix].LCD_Display[2][i];
	     	LCD_Display[3][i] = LCD_State[LCD_State_ix].LCD_Display[3][i];
	    }
	}
	else 
	{
  		line_ptr = (LCD_Pointer - 1) % 3;
  		start_ptr = LCD_Pointer - line_ptr;
  	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[0][i] = LCD_Main_Menu[0][i];
			LCD_Display[1][i] = LCD_Main_Menu[Main_Menu_list[start_ptr]][i];
			if ((start_ptr + 1) > Last_Menu)
		  	{
		  		LCD_Display[2][i] = ' ';
		  		LCD_Display[3][i] = ' ';
		  	}
		  	else
		  	{
				LCD_Display[2][i] = LCD_Main_Menu[Main_Menu_list[start_ptr+1]][i];
				if ((start_ptr + 2) > Last_Menu)
			  		LCD_Display[3][i] = ' ';
				else
					LCD_Display[3][i] = LCD_Main_Menu[Main_Menu_list[start_ptr+2]][i];
		  	}
  	    }
		LCD_Display[line_ptr+1][0] = '>';		// show cursor
		LCD_Upd_Dpy = 1;
	}
}

void clrLCDdpy(void)
{
	int16 j;
	
   for(j=0;j<20;j++)
   {
   	 LCD_Display[0][j] = ' ';
	 LCD_Display[1][j] = ' ';
   }
	 
}
//*********************************************************
//*********************************************************
//********************* MENU Subroutines ******************
//*********************************************************
//*********************************************************



//************************************
// Set Date and Time Routine - Menu 1
//************************************

int16 set_date_and_time (int16 lcd_menu)
{
	int16 i;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	static int16 mode_sel;

	if (LCD_Init == 1)
	{
		LCD_Init  = 0;
		menu_ptr = 0;
		menu_level = 0;
		mode_sel = 0;
  	    upd_dpy = 1;
	}

	if (menu_level == 0)
	{			// Select time menu

		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
				menu_ptr = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
	    	if(menu_ptr > 1)
				menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = menu_ptr + 1;
		  	LCD_Sub_Init = 1;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
				LCD_Display[0][i] = LCD_Main_Menu[1][i];
			  	LCD_Display[1][i] = LCD_Date_Time_Menu[0][i];
			  	LCD_Display[2][i] = LCD_Date_Time_Menu[1][i];
			  	LCD_Display[3][i] = ' ';
		    }
			LCD_Display[menu_ptr+1][0] = '>';		// show cursor
		}
	}
	else if (menu_level == 1)
	{
	  	if(LCD_Sub_Init == 1)	// first time through set time and date
	  	{
	  	    LCD_Sub_Init = 0;
	  	    upd_dpy = 1;
	  	    local_gettime();
	  	    local_getdate();
	  	    LCD_Year = d.year;
	  	    LCD_Month = d.month;
	  	    LCD_Day = d.day;
	  	    LCD_Hour = t.hour;
	  	    LCD_Minute = t.minute;
	  	    LCD_Time_Date[0] = ' ';
	  	    LCD_Time_Date[6] = ' ';
	  	    LCD_Time_Date[7] = ' ';
	  	    LCD_Time_Date[8] = ' ';
	  	    LCD_Time_Date[19] = ' ';
	  	    LCD_Time_Date[3] = ':';
	  	    LCD_Time_Date[11] = '/';
	  	    LCD_Time_Date[14] = '/';
	  	    mode_sel = 0;
	  	}
	  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	  	{
	  	    LCD_Mode_PB = 1;  //
	  	    upd_dpy = 1;
	  	    mode_sel++;
	  	    if(mode_sel > 7)
			  	mode_sel = 0;
	  	}
	  	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  	{
	  	    LCD_Enter_PB = 1;
	  	    d.year = LCD_Year;
	  	    d.month = LCD_Month;
	  	    d.day = LCD_Day;
	  	    t.hour = LCD_Hour;
	  	    t.minute = LCD_Minute;
			local_setdate();
			local_settime();
			if (cons[carnmb] == Dispatcher)
				put_pkt_req_all_cars(109);		// Update time on all other cars
      		menu_level = 0;
			menu_ptr = 0;
	  	    upd_dpy = 1;
			return(lcd_menu);
	  	}
	  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  	{
	  	    LCD_UP_PB = 1;  // incriment
	  	    upd_dpy = 1;
	  	    if(mode_sel == 0)	// incriment hours
	  	    {
				  LCD_Hour++;
				  if(LCD_Hour > 23)
				      LCD_Hour = 0;
	  	    }
	  	    if(mode_sel == 1)	// incriment Minutes
	  	    {
				  LCD_Minute++;
				  if(LCD_Minute > 59)
				      LCD_Minute = 0;
	  	    }
	  	    if(mode_sel == 2)	// incriment Months
	  	    {
				  LCD_Month++;
				  if(LCD_Month > 12)
				      LCD_Month = 1;
	  	    }
	  	    if(mode_sel == 3)	// incriment Days
	  	    {
				  LCD_Day++;
				  if(LCD_Day > 31)
				      LCD_Day = 1;
	  	    }
	  	    if(mode_sel == 4)	// incriment Year [1]
				  LCD_Year+=1;
	  	    if(mode_sel == 5)	// incriment Year [10]
				  LCD_Year+=10;
	  	    if(mode_sel == 6)	// incriment Year [100]
				  LCD_Year+=100;
	  	    if(mode_sel == 7)	// incriment Year [1000]
				  LCD_Year+=1000;
			if(LCD_Year > 9999) //corrects years above 10000
				  LCD_Year = 9999;
	  	}
	  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  	{
	  	    LCD_DN_PB = 1;  // decriment
	  	    upd_dpy = 1;
	  	    if(mode_sel == 0)	// decriment hours
	  	    {
				  LCD_Hour--;
				  if(LCD_Hour < 0)
				      LCD_Hour = 23;
	  	    }
	  	    if(mode_sel == 1)	// decriment Minutes
	  	    {
				  LCD_Minute--;
				  if(LCD_Minute < 0)
				      LCD_Minute = 59;
	  	    }
	  	    if(mode_sel == 2)	// decriment Months
	  	    {
				  LCD_Month--;
				  if(LCD_Month < 1)
				      LCD_Month = 12;
	  	    }
	  	    if(mode_sel == 3)	// decriment Days
	  	    {
				  LCD_Day--;
				  if(LCD_Day < 1)
				      LCD_Day = 31;
	  	    }
	  	    if(mode_sel == 4)	// decriment Year [1]
				  LCD_Year-=1;
	  	    if(mode_sel == 5)	// decriment Year [10]
				  LCD_Year-=10;
	  	    if(mode_sel == 6)	// decriment Year [100]
				  LCD_Year-=100;
	  	    if(mode_sel == 7)	// decriment Year [1000]
				  LCD_Year-=1000;
			if(LCD_Year < 0) //corrects years below 0
			      LCD_Year = 0;
	  	}
	  	if(upd_dpy == 1)
	  	{
			upd_dpy = 0;
	  	    if(LCD_Hour < 10)
	  	    {
				  LCD_Time_Date[1] = ' ';
				  LCD_Time_Date[2] = (char)('0' + LCD_Hour);
	  	    }
	  	    else
	  	    {
				  itoa(LCD_Hour, LCD_String);
				  LCD_Time_Date[1] = LCD_String[0];
				  LCD_Time_Date[2] = LCD_String[1];
	  	    }
	  	    if(mode_sel == 0)	// flash hours
	  	    {
				  LCD_Flash_TMP[0] = LCD_Time_Date[1];
				  LCD_Flash_TMP[1] = LCD_Time_Date[2];
	  	    }
	  	    if(LCD_Minute < 10)
	  	    {
				  LCD_Time_Date[4] = '0';
				  LCD_Time_Date[5] = (char)('0' + LCD_Minute);
	  	    }
	  	    else
	  	    {
				  itoa(LCD_Minute, LCD_String);
				  LCD_Time_Date[4] = LCD_String[0];
				  LCD_Time_Date[5] = LCD_String[1];
	  	    }
	  	    if(mode_sel == 1)	// flash minutes
	  	    {
				  LCD_Flash_TMP[0] = LCD_Time_Date[4];
				  LCD_Flash_TMP[1] = LCD_Time_Date[5];
	  	    }
	  	    if(LCD_Month < 10)
	  	    {
				  LCD_Time_Date[9] = ' ';
				  LCD_Time_Date[10] = (char)('0' + LCD_Month);
	  	    }
	  	    else
	  	    {
				  itoa(LCD_Month, LCD_String);
				  LCD_Time_Date[9] = LCD_String[0];
				  LCD_Time_Date[10] = LCD_String[1];
	  	    }
	  	    if(mode_sel == 2)	// flash Months
	  	    {
				  LCD_Flash_TMP[0] = LCD_Time_Date[9];
				  LCD_Flash_TMP[1] = LCD_Time_Date[10];
	  	    }
	  	    if(LCD_Day < 10)
	  	    {
				  LCD_Time_Date[12] = '0';
				  LCD_Time_Date[13] = (char)('0' + LCD_Day);
	  	    }
	  	    else
	  	    {
				  itoa(LCD_Day, LCD_String);
				  LCD_Time_Date[12] = LCD_String[0];
				  LCD_Time_Date[13] = LCD_String[1];
	  	    }
	  	    if(mode_sel == 3)	// flash days
	  	    {
				  LCD_Flash_TMP[0] = LCD_Time_Date[12];
				  LCD_Flash_TMP[1] = LCD_Time_Date[13];
	  	    }
	  	    //itoa(LCD_Year, LCD_String);
	  	    sprintf(LCD_String,"%4d",LCD_Year);
			  for (i=0;i<=3;i++)
				if (LCD_String[i] == ' ')
					LCD_String[i] = '0';
									 
	  	    LCD_Time_Date[15] = LCD_String[0];
	  	    LCD_Time_Date[16] = LCD_String[1];
	  	    LCD_Time_Date[17] = LCD_String[2];
	  	    LCD_Time_Date[18] = LCD_String[3];

	  	    if(mode_sel == 4)	// flash year[1]
				  LCD_Flash_TMP[3] = LCD_Time_Date[18];

	  	    if(mode_sel == 5)	// flash year[10]
				  LCD_Flash_TMP[2] = LCD_Time_Date[17];

	  	    if(mode_sel == 6)	// flash year[100]
				  LCD_Flash_TMP[1] = LCD_Time_Date[16];

	  	    if(mode_sel == 7)	// flash year[1000]
				  LCD_Flash_TMP[0] = LCD_Time_Date[15];

	  	    for(i=0; i<=19; i++)
	  	    {
				  LCD_Display[1][i] = LCD_Set_Time_Date[0][i];
				  LCD_Display[2][i] = LCD_Set_Time_Date[1][i];
				  LCD_Display[3][i] = LCD_Time_Date[i];
	  	    }
	  	}
	  	else
	  	{
	  	    if(mode_sel == 0)	// flash hours
	  	    {
				  if(LCD_Flash == 0)
				  {
				      LCD_Display[3][1] = ' ';
				      LCD_Display[3][2] = ' ';
				  }
				  else
				  {
				      LCD_Display[3][1] = LCD_Flash_TMP[0];
				      LCD_Display[3][2] = LCD_Flash_TMP[1];
				  }
	  	    }
	  	    if(mode_sel == 1)	// flash minutes
	  	    {
				  if(LCD_Flash == 0)
				  {
				      LCD_Display[3][4] = ' ';
				      LCD_Display[3][5] = ' ';
				  }
				  else
				  {
				      LCD_Display[3][4] = LCD_Flash_TMP[0];
				      LCD_Display[3][5] = LCD_Flash_TMP[1];
				  }
	  	    }
	  	    if(mode_sel == 2)	// flash month
	  	    {
				  if(LCD_Flash == 0)
				  {
				      LCD_Display[3][9] = ' ';
				      LCD_Display[3][10] = ' ';
				  }
				  else
				  {
				      LCD_Display[3][9] = LCD_Flash_TMP[0];
				      LCD_Display[3][10] = LCD_Flash_TMP[1];
				  }
	  	    }
	  	    if(mode_sel == 3)	// flash day
	  	    {
				  if(LCD_Flash == 0)
				  {
				      LCD_Display[3][12] = ' ';
				      LCD_Display[3][13] = ' ';
				  }
				  else
				  {
				      LCD_Display[3][12] = LCD_Flash_TMP[0];
				      LCD_Display[3][13] = LCD_Flash_TMP[1];
				  }
	  	    }
			// flash years, units to ten thousands

			if(mode_sel == 4)	// flash years [1]
			{
				if(LCD_Flash == 0)
					LCD_Display[3][18] = ' ';
				else
					LCD_Display[3][18] = LCD_Flash_TMP[3];
			}
			if(mode_sel == 5)	// flash years [10]
			{
				if(LCD_Flash == 0)
					LCD_Display[3][17] = ' ';
				else
					LCD_Display[3][17] = LCD_Flash_TMP[2];
			}
					
			if(mode_sel == 6)	// flash years [100]
			{
				if(LCD_Flash == 0)
					LCD_Display[3][16] = ' ';
				else
					LCD_Display[3][16] = LCD_Flash_TMP[1];
			}
					
			if(mode_sel == 7)	// flash years [1000]
			{
				if(LCD_Flash == 0)
					LCD_Display[3][15] = ' ';
				else
				    LCD_Display[3][15] = LCD_Flash_TMP[0];
			}
	  	}
	}
	else if (menu_level == 2)
	{		// Display the day of week
  		if(LCD_Sub_Init == 1)	
  		{
	    	LCD_Sub_Init = 0;
			local_getdate();
	    	for(i=0; i<=19; i++)
	    	{
				LCD_Display[1][i] = LCD_DOW__Menu[7][i];
				LCD_Display[2][i] = LCD_DOW__Menu[d.dayofweek][i];
				LCD_Display[3][i] = ' ';
	    	}
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
      		LCD_Mode_PB = 1;  //
      		menu_level = 0;
			menu_ptr = 1;
	  	    upd_dpy = 1;
			return(lcd_menu);
  		}
	}
	return(lcd_menu);
}


//****************************************
// Adjust Field Variables Routine - Menu 1
//****************************************

int16 adjust_field_variables (int16 lcd_menu)
{
	int16 i;
	int16 fv_line = 0;
	int16 start_ptr;
	int16 line_ptr;
	int16 deci;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	static int16 var_menu_ptr;
	static int16 var_ptr;
	static int16 mode_sel;
	
  	if(LCD_Init == 1)		// first time through procedure
 	{
 	    LCD_Init = 0;
 	    menu_ptr = 0;
 	    menu_level = 0;
 	    mode_sel = 0;
 	    upd_dpy = 1;
		var_menu_ptr = 0;
		var_ptr = 0;
 	}
	if (menu_level == 0)
	{			// Rotate through Field Variable menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
 		    upd_dpy = 1;
			var_ptr = 0;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  	menu_ptr = FV_Last_Menu;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
 		    upd_dpy = 1;
			var_ptr = 0;
		    menu_ptr++;
						 
			if (menu_ptr > FV_Last_Menu)
				menu_ptr = 0;
		}

		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
 		    upd_dpy = 1;
		  	menu_level = (int16)(FV_Menu_list[menu_ptr] + 1);
		  	var_menu_ptr = FV_Menu_list[menu_ptr];
		  	upd_dpy = 1;
		  	LCD_Sub_Init = 1;
			return(lcd_menu);
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			line_ptr = (menu_ptr % 3);
			start_ptr = menu_ptr - line_ptr;
		    for(i=0; i<=19; i++)
		    {
	  			LCD_Display[0][i] = LCD_Main_Menu[2][i];
			  	LCD_Display[1][i] = LCD_Field_Variables[FV_Menu_list[start_ptr]][i];
			  	if ((start_ptr + 1) > FV_Last_Menu)
			  	{
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
			  	}
			  	else 
			  	{
				  	LCD_Display[2][i] = LCD_Field_Variables[FV_Menu_list[start_ptr+1]][i];
			  		if ((start_ptr + 2) > FV_Last_Menu)
				  		LCD_Display[3][i] = ' ';
		    		else
					  	LCD_Display[3][i] = LCD_Field_Variables[FV_Menu_list[start_ptr+2]][i];
			  	}
		    }
			LCD_Display[line_ptr+1][0] = '>';		// show cursor
		}
	}
	if ((menu_level >= 1) && (menu_level <= 9))
	{			// Change adjustable variables
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
  		    mode_sel++;
  		    upd_dpy = 1;
  		    if(mode_sel > 1)	// save field new value entered
  		    {
//				wr_one_fvar(var_menu_tbl[var_menu_ptr][var_ptr]);
				wrfvar();
  		    	send_galcom_fvar(MAIN_CPU,var_menu_tbl[var_menu_ptr][var_ptr]);
				mode_sel = 0;
				LCD_Dig_Point = 0;
  		    }
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
  		    if(mode_sel == 0)	// Leave the field var procedure
  		    {
				menu_level = 0;
				upd_dpy = 1;
				return(lcd_menu);
  		    }
  		    if(mode_sel > 0)
  		    {
				upd_dpy = 1;
				LCD_Dig_Point = set_adj_digit(fvars_max[var_menu_tbl[var_menu_ptr][var_ptr]],LCD_Dig_Point,
											  fvars_deci[var_menu_tbl[var_menu_ptr][var_ptr]]);			
  		    }
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
  		    LCD_UP_PB = 1;  // incriment
  		    upd_dpy = 1;
  		    if(mode_sel == 0)
  		    {
				var_ptr--;
				if(var_ptr < 0)
				    var_ptr = last_var[var_menu_ptr];	 // Last fvars # 
  		    }
  		    else	// increment fieldvar
				adjust_variable(&fvars[var_menu_tbl[var_menu_ptr][var_ptr]],
						fvars_max[var_menu_tbl[var_menu_ptr][var_ptr]],
					fvars_min[var_menu_tbl[var_menu_ptr][var_ptr]],1,LCD_Dig_Point,
					fvars_deci[var_menu_tbl[var_menu_ptr][var_ptr]]);
  		}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
  		    LCD_DN_PB = 1;  // decriment
  		    upd_dpy = 1;
  		    if(mode_sel == 0)
  		    {
				var_ptr++;
				if(var_ptr > last_var[var_menu_ptr])	  // Last fvars # 
				    var_ptr = 0;
  		    }
  		    else	// decrement fieldvar
				adjust_variable(&fvars[var_menu_tbl[var_menu_ptr][var_ptr]],
						fvars_max[var_menu_tbl[var_menu_ptr][var_ptr]],
						fvars_min[var_menu_tbl[var_menu_ptr][var_ptr]],0,LCD_Dig_Point,
						fvars_deci[var_menu_tbl[var_menu_ptr][var_ptr]]);
  		}

	   	if ((PasswordFlag == false) && (mode_sel > 0))
	   	{
	  		StoreLCDInfo();
			clrLCDdpy();
	  		LCD_Menu = 25;
	  		LCD_Init = 1;
			return(lcd_menu);
   	   	}

	    line_ptr = (var_ptr % 3);
		if(mode_sel > 0)
			fv_line = 2;
		else
			fv_line = line_ptr+1;
  	
  		if(upd_dpy == 1)
  		{
		    upd_dpy = 0;
		    
		    start_ptr = var_ptr - line_ptr;
		    
			
 		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = getcaps(LCD_Field_Variables[var_menu_ptr][i]);
				if(mode_sel > 0)
				{
					if ((fvars_deci[var_menu_tbl[var_menu_ptr][var_ptr]] & 0x80) != 0)
					{
						LCD_Display[1][i] = ' ';
						LCD_Display[2][i] = ' ';
						LCD_Display[3][i] = LCD_Field_Vars[var_menu_tbl[var_menu_ptr][var_ptr]][i];
					}
					else
					{
						LCD_Display[1][i] = LCD_Par[var_menu_tbl[var_menu_ptr][var_ptr]][i];
						LCD_Display[2][i] = LCD_Field_Vars[var_menu_tbl[var_menu_ptr][var_ptr]][i];
						LCD_Display[3][i] = ' ';
					}
				}
				else
				{
					LCD_Display[1][i] = LCD_Field_Vars[var_menu_tbl[var_menu_ptr][start_ptr]][i];
					if ((start_ptr+1) > last_var[var_menu_ptr])
					{
						LCD_Display[2][i] = ' ';
						LCD_Display[3][i] = ' ';
					}
					else
					{
						LCD_Display[2][i] = LCD_Field_Vars[var_menu_tbl[var_menu_ptr][start_ptr+1]][i];
					
						if ((start_ptr+2) > last_var[var_menu_ptr])
							LCD_Display[3][i] = ' ';
						else
							LCD_Display[3][i] = LCD_Field_Vars[var_menu_tbl[var_menu_ptr][start_ptr+2]][i];
					}
				}
  		    }

			if(mode_sel > 0)
				Display_Var_Label(var_menu_ptr,var_menu_tbl[var_menu_ptr][var_ptr],fvars[var_menu_tbl[var_menu_ptr][var_ptr]]);
			for (i=0;i<=2;i++)
			{
				if (mode_sel > 0)
				{
					if ((var_menu_tbl[var_menu_ptr][var_ptr] == fvpassword) && (PasswordFlag == false))
					{
			  		    for(i=14; i<=19; i++)
							LCD_Display[fv_line][i] = '*';
					}
					else
					{
						display_variable(fv_line, 14, fvars_deci[var_menu_tbl[var_menu_ptr][var_ptr]], fvars[var_menu_tbl[var_menu_ptr][var_ptr]], 1);
					}
					break;		// only show one character when changing value
				}
				else if ((start_ptr+i) <= last_var[var_menu_ptr])
				{
					if ((var_menu_tbl[var_menu_ptr][start_ptr+i] == fvpassword) && (PasswordFlag == false))
					{
			  		    for(i=14; i<=19; i++)
							LCD_Display[i+1][i] = '*';
					}
					else
					{
						deci = fvars_deci[var_menu_tbl[var_menu_ptr][start_ptr+i]];
						if ((deci & 0x80) != 0)
							deci = 0; // if using bit display set the number of decimal point location to zero
						display_variable(i+1, 14, deci, fvars[var_menu_tbl[var_menu_ptr][start_ptr+i]], 1);
					}
				}
			}
			LCD_Flash_TMP[1] = LCD_Display[fv_line][LCD_Dig_Loc];
			if (mode_sel == 0)		// show cursor
			{
				LCD_Display[fv_line][13] = '>';
			}
  		}
  		flash_digit(LCD_Flash_TMP[1], fv_line,LCD_Dig_Loc,(mode_sel > 0));
	}
	if (menu_level == 10)
	{
		menu_level = Adjust_NTS_Parameters(menu_level);
		if (menu_level == 0)
			upd_dpy = 1;
	}
	return(lcd_menu);
}


//************************************
// Job Statistics - Menu 3
//************************************

int16 job_statistics (int16 lcd_menu)
{
	int16 i;
	int32 tmp_long = 0;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	static int16 var_ptr;
	static int16 mode_sel;
	
    if(LCD_Init == 1) // First time through
    {
		LCD_Init = 0;
		upd_dpy = 1;
		menu_ptr = 0;
		menu_level = 0;
		var_ptr = 0;
  	}

	if (menu_level == 0)
	{			// Rotate through job statistics menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  menu_ptr = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
		    if(menu_ptr > 1)
			  menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = menu_ptr + 1;
			LCD_Sub_Init = 1;
	  		var_ptr = 0;
			return(lcd_menu);
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
		  		LCD_Display[0][i] = LCD_Main_Menu[3][i];
				LCD_Display[1][i] = LCD_Job_Statistics[0][i];
				LCD_Display[2][i] = LCD_Job_Statistics[1][i];
				LCD_Display[3][i] = ' ';
		    }
			LCD_Display[menu_ptr+1][0] = '>';		// show cursor
		}
	}
	if (menu_level == 1)
	{			// View Job Statistics
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to menu level 1
			LCD_Mode_PB = 1;  //
			menu_ptr = 0;
			menu_level = 0;
		  	var_ptr = 0;
		  	upd_dpy = 1;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    var_ptr--;
		    if(var_ptr < 0)
			  var_ptr = 17;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    var_ptr++;
		    if(var_ptr > 17)
			  var_ptr = 0;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
			  LCD_Display[1][i] = LCD_Statistics[(var_ptr)][i];
			  if(i < 8)
			      LCD_Display[2][i] = ' ';
			  LCD_Display[3][i] = ' ';
		    }
		    if( (var_ptr) < 9)
			  	itoa(lvars[var_ptr], LCD_String);
		    else
		    {
			  	if((lvars[nmbuc] + lvars[nmbdc]) > 0)
			  	{
			      // Percent Answered In Less than 15 Second
			      	if(var_ptr == 13)
					   	tmp_long = ( ((lvars[3] + lvars[8]) * (int32)1000) /
							 (lvars[nmbuc]+lvars[nmbdc]) );
				      // Percent Answered In Less than 30 Second
				    if(var_ptr == 14)
					  	tmp_long = ( ((lvars[4] + lvars[9]) * (int32)1000) /
							(lvars[nmbuc]+lvars[nmbdc]) );
				      // Percent Answered In Less than 45 Second
				    if(var_ptr == 15)
					  	tmp_long = ( ((lvars[5] + lvars[10]) * (int32)1000) /
							(lvars[nmbuc]+lvars[nmbdc]) );
				    // Percent Answered In Less than 60 Second
				    if(var_ptr == 16)
						tmp_long = ( ((lvars[6] + lvars[11]) * (int32)1000) /
							(lvars[nmbuc]+lvars[nmbdc]) );
				      // Percent Answered In More than 60 Second
				    if(var_ptr == 17)
					  	tmp_long = ( ((lvars[7] + lvars[12]) * (int32)1000) /
							(lvars[nmbuc]+lvars[nmbdc]) );
				}
				itoa(tmp_long, LCD_String);
		    }
		    i=0;
		    while((LCD_String[i] >= '0') && (LCD_String[i] <= '9'))
		    {
				LCD_Display[2][(i+8)] = LCD_String[i];
				i++;
		    }
		    if( var_ptr > 8)
		    {
				if(tmp_long != 0)
				{
				    LCD_Display[2][(i+8)] = LCD_String[(i-1)];
				    LCD_Display[2][(i+7)] = '.';
				    i++;
				}
				LCD_Display[2][(i+8)] = ' ';
				i++;
				LCD_Display[2][(i+8)] = '%';
				i++;
		    }
		    while(i < 16)
		    {
				LCD_Display[2][(i+8)] = ' ';
				i++;
		    }
		}
	}
	if (menu_level == 2)
	{			// Clear Job Statistics
	  	if(LCD_Sub_Init == 1)	// first time through Clear Job Statistics
	  	{
	  	    LCD_Sub_Init = 0;
	  	    for(i=0; i<=19; i++)
	  	    {
				  LCD_Display[1][i] = LCD_Clear_Stats[0][i];
				  LCD_Display[2][i] = LCD_Clear_Stats[1][i];
				  LCD_Display[3][i] = ' ';
	  	    }
	  	}

		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to menu level 1
			LCD_Mode_PB = 1;  //
			menu_level = 0;
			menu_ptr = 1;
		  	upd_dpy = 1;
			return(lcd_menu);
		}
	  	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  	{
	    	LCD_Enter_PB = 1;
	    	for(i=0; i<=19; i++)
	    	{
				  LCD_Display[1][i] = LCD_Clear_Stats[2][i];
				  LCD_Display[2][i] = LCD_Clear_Stats[3][i];
				  LCD_Display[3][i] = ' ';
	    	}
			clear_job_statistics();
	  	}
	}
	return(lcd_menu);
}


//***************************************
// Inputs and Outputs Subroutine - Menu 4
//***************************************

int16 inputs_and_outputs (int16 lcd_menu)
{

	int16 i;
	int16 start_ptr;
	int16 line_ptr;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	
    if(LCD_Init == 1) // First time through
    {
		upd_dpy = 1;
		LCD_Init = 0;
  	}

	if (menu_level == 0)
	{			// Rotate through input and output menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  menu_ptr = Last_IO_Menu;
			if ((Dispatcher != cons[carnmb]) || ((gc_hall_io_dev == 0) && (nmb_grcan_dev == 0)))
			{
				if (menu_ptr == 1)
					menu_ptr = 0;
			}
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
			if ((Dispatcher != cons[carnmb]) || ((gc_hall_io_dev == 0) && (nmb_grcan_dev == 0)))
			{
				if (menu_ptr == 1)
					menu_ptr = 2;
			}
		    if(menu_ptr > Last_IO_Menu)
			  menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = (int16)(IO_Menu_list[menu_ptr] + 1);
		  	LCD_Sub_Init = 1;		// for menus that do not need menu[2]
			return(lcd_menu);
		}
		if(upd_dpy == 1)
		{
		  	upd_dpy = 0;
	  		line_ptr = menu_ptr % 3;
	  		start_ptr = menu_ptr - line_ptr;
	  	    for(i=0; i<=19; i++)
	  	    {
	  			LCD_Display[0][i] = LCD_Main_Menu[4][i];
				LCD_Display[1][i] = LCD_Input_Output[IO_Menu_list[start_ptr]][i];
				if ((start_ptr + 1) > Last_IO_Menu)
			  	{
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
			  	}
			  	else
			  	{
					LCD_Display[2][i] = LCD_Input_Output[IO_Menu_list[start_ptr+1]][i];
					if ((start_ptr + 2) > Last_IO_Menu)
				  		LCD_Display[3][i] = ' ';
					else
						LCD_Display[3][i] = LCD_Input_Output[IO_Menu_list[start_ptr+2]][i];
			  	}
	  	    }
			LCD_Display[line_ptr+1][0] = '>';		// show cursor
		}
	}
	if (menu_level == 1)
	{
		menu_level = Display_Car_IO(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
  	}
	if (menu_level == 2)
	{
		menu_level = Display_Group_IO(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	if (menu_level == 3)
	{
		menu_level = Display_NTS_IO(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	if (menu_level == 4)
	{
		menu_level = Display_FPGA1_IO(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	if (menu_level == 5)
	{
		menu_level = Relocate_IO(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	return(lcd_menu);
}

//*********************************************
// Setup Car and Hall Calls Subroutine - Menu 5
//*********************************************

int16 setup_car_and_hall_calls (int16 lcd_menu)
{
	int16 i,j;
	int16 start_ptr;
	int16 line_ptr;
	int16 fl_ix;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	static int16 last_menu;
	static int16 mode_sel;
	static int16 floor_ix;
  	static int16 secure_yes;
	
	if (LCD_Init == 1)
	{
		LCD_Init = 0; 
		upd_dpy = 1;
		menu_level = 0;
		menu_ptr = 0;
		floor_ix = cons[bottomf];
 	    // Build the menu list
		j = 0;
 	    for (i=0;i<Num_Set_Calls_Menus;i++)
 	    {
			if (Dispatcher != cons[carnmb]) 
			{
				if ((i == 1) || (i == 2))
				{
					if (cons[rear] == 0)
						i = 6;
					else
						i = 3;
				}

				if ((i == 4) || (i == 5))
					i = 6;
			}
			else
			{
				if ((cons[rear] == 0) && (i == 3))
					i = 4; 
				if ((grtop_rfl == 0) && ((i == 4) || (i == 5)))
					i = 6; 
			}

			if ((cons[rear] == 0) && (i == 7))
				i = 8;
				
			if (i >= Num_Set_Calls_Menus)
				break;  // Have to break here if the last menu is not used
			else
			{
	 	    	Menu_list[j] = (int8)i;	
	 	    	j++;
			}
 	    }
 	    
 	    last_menu = j - 1;
 	    for (i=j;i<Num_Set_Calls_Menus;i++)
 	    	Menu_list[i] = Num_Set_Calls_Menus;
 	    	
   	}

	if (menu_level == 0)
	{			// Rotate through Call menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  	menu_ptr = last_menu;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
						 
			if (menu_ptr > last_menu)
				menu_ptr = 0;

		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			secure_yes = 0;
			mode_sel = 0;
		  	menu_level = (int16)(Menu_list[menu_ptr] + 1);
			return(lcd_menu);
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
	  		line_ptr = menu_ptr % 3;
	  		start_ptr = menu_ptr - line_ptr;
	  	    for(i=0; i<=19; i++)
	  	    {
	  			LCD_Display[0][i] = LCD_Main_Menu[5][i];
				LCD_Display[1][i] = LCD_Setup_Calls[Menu_list[start_ptr]][i];
				if ((start_ptr + 1) > last_menu)
			  	{
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
			  	}
			  	else
			  	{
					LCD_Display[2][i] = LCD_Setup_Calls[Menu_list[start_ptr+1]][i];
					if ((start_ptr + 2) > last_menu)
				  		LCD_Display[3][i] = ' ';
					else
						LCD_Display[3][i] = LCD_Setup_Calls[Menu_list[start_ptr+2]][i];
			  	}
	  	    }
			LCD_Display[line_ptr+1][0] = '>';		// show cursor
		}
	}
	if (menu_level == 1)
	{      	  // Setup a Car Call
  		if(mode_sel == 0)	// first time through Setup a Car Call
  		{
  			mode_sel = 1;
  		    upd_dpy = 1;
			floor_ix = cons[bottomf];
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_Calls[0][i];
				LCD_Display[1][i] = LCD_Calls[1][i];
				LCD_Display[2][i] = LCD_Calls[2][i];
				LCD_Display[3][i] = ' ';
  		    }
		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
			set_carcall(cons[carnmb],floor_ix);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
			upd_dpy = 1;
			return(lcd_menu);
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
  		    LCD_UP_PB = 1;  // incriment
  		    upd_dpy = 1;
  		    floor_ix++;
  		    if(floor_ix > cons[topf])
				  floor_ix = cons[bottomf];
  		}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
  		    LCD_DN_PB = 1;  // decriment
  		    upd_dpy = 1;
  		    floor_ix--;
  		    if(floor_ix < cons[bottomf])
				  floor_ix = cons[topf];
  		}
 		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[2][18] = flmrk[floor_ix][0];
  		   LCD_Display[2][19] = flmrk[floor_ix][1];
  		}
	}
	if (menu_level == 2)
	{			// Setup a Down Hall Call
  		if(mode_sel == 0)	// first time through Setup a Down Call
  		{
  			mode_sel = 1;
  		    upd_dpy = 1;
			floor_ix = cons[bottomf];
      		for(i=0; i<=19; i++)
      		{
				LCD_Display[0][i] = LCD_Calls[0][i];
				LCD_Display[1][i] = LCD_Calls[1][i];
				LCD_Display[2][i] = LCD_Calls[3][i];
				LCD_Display[3][i] = ' ';
      		}
  		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
      		LCD_Enter_PB = 1;
			set_dncall(floor_ix);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
      		LCD_Mode_PB = 1;  //
			menu_level = 0;
			upd_dpy = 1;
			return(lcd_menu);
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
      		LCD_UP_PB = 1;  // incriment
      		upd_dpy = 1;
	      	floor_ix++;
	      	if(floor_ix > cons[topf])
			  	floor_ix = (cons[bottomf]+1);
	  	}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
      		LCD_DN_PB = 1;  // decriment
      		upd_dpy = 1;
      		floor_ix--;
      		if(floor_ix < (cons[bottomf]+1))
				  floor_ix = cons[topf];
  		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[2][15] = flmrk[floor_ix][0];
  		   LCD_Display[2][16] = flmrk[floor_ix][1];
  		}
	}
	if (menu_level == 3)
	{			// Setup an Up Hall Call
  		if(mode_sel == 0)	// first time through Setup a Up Call
  		{
  			mode_sel = 1;
  		    upd_dpy = 1;
			floor_ix = cons[bottomf];
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_Calls[0][i];
				LCD_Display[1][i] = LCD_Calls[1][i];
				LCD_Display[2][i] = LCD_Calls[4][i];
				LCD_Display[3][i] = ' ';
  		    }
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
			set_upcall(floor_ix);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
			upd_dpy = 1;
			return(lcd_menu);
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
  		    LCD_UP_PB = 1;  // incriment
  		    upd_dpy = 1;
  		    floor_ix++;
  		    if(floor_ix > (cons[topf]-1))
				  floor_ix = cons[bottomf];
  		}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
  		    LCD_DN_PB = 1;  // decriment
  		    upd_dpy = 1;
  		    floor_ix--;
  		    if(floor_ix < cons[bottomf])
				  floor_ix = (cons[topf]-1);
  		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[2][15] = flmrk[floor_ix][0];
  		   LCD_Display[2][16] = flmrk[floor_ix][1];
  		}
	}
	if (menu_level == 4)
	{      	  // Setup a rear Car Call
  		if(mode_sel == 0)	// first time through Setup a Car Call
  		{
  			mode_sel = 1;
  		    upd_dpy = 1;
			floor_ix = cons[bottomf];
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_Calls[0][i];
				LCD_Display[1][i] = LCD_Calls[1][i];
				LCD_Display[2][i] = LCD_Calls[5][i];
				LCD_Display[3][i] = ' ';
  		    }
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
			set_rcarcall(cons[carnmb],floor_ix);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
			upd_dpy = 1;
			return(lcd_menu);
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
  		    LCD_UP_PB = 1;  // incriment
  		    upd_dpy = 1;
  		    floor_ix++;
  		    if(floor_ix > cons[topf])
				  floor_ix = cons[bottomf];
  		}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
  		    LCD_DN_PB = 1;  // decriment
  		    upd_dpy = 1;
  		    floor_ix--;
  		    if(floor_ix < cons[bottomf])
				  floor_ix = cons[topf];
  		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[2][17] = flmrk[floor_ix][0];
  		   LCD_Display[2][18] = flmrk[floor_ix][1];
  		}
	}
	if (menu_level == 5)
	{			// Setup a rear Down Hall Call
  		if(mode_sel == 0)	// first time through Setup a Down Call
  		{
  			mode_sel = 1;
  		    upd_dpy = 1;
			floor_ix = cons[bottomf];
      		for(i=0; i<=19; i++)
      		{
				LCD_Display[0][i] = LCD_Calls[0][i];
				LCD_Display[1][i] = LCD_Calls[1][i];
				LCD_Display[2][i] = LCD_Calls[6][i];
				LCD_Display[3][i] = ' ';
      		}
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
      		LCD_Enter_PB = 1;
			set_rdncall(floor_ix);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
      		LCD_Mode_PB = 1;  //
			menu_level = 0;
			upd_dpy = 1;
			return(lcd_menu);
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
      		LCD_UP_PB = 1;  // incriment
      		upd_dpy = 1;
	      	floor_ix++;
	      	if(floor_ix > cons[topf])
			  	floor_ix = (cons[bottomf]+1);
	  	}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
      		LCD_DN_PB = 1;  // decriment
      		upd_dpy = 1;
      		floor_ix--;
      		if(floor_ix < (cons[bottomf]+1))
				  floor_ix = cons[topf];
  		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[2][16] = flmrk[floor_ix][0];
  		   LCD_Display[2][17] = flmrk[floor_ix][1];
  		}
	}
	if (menu_level == 6)
	{			// Setup a rear Up Hall Call
  		if(mode_sel == 0)	// first time through Setup a Up Call
  		{
  			mode_sel = 1;
  		    upd_dpy = 1;
			floor_ix = cons[bottomf];
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_Calls[0][i];
				LCD_Display[1][i] = LCD_Calls[1][i];
				LCD_Display[2][i] = LCD_Calls[7][i];
				LCD_Display[3][i] = ' ';
  		    }
			LCD_Display[0][22] = 'n';		// an Up call instead of a Up call
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
			set_rupcall(floor_ix);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
			upd_dpy = 1;
			return(lcd_menu);
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
  		    LCD_UP_PB = 1;  // incriment
  		    upd_dpy = 1;
  		    floor_ix++;
  		    if(floor_ix > (cons[topf]-1))
				  floor_ix = cons[bottomf];
  		}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
  		    LCD_DN_PB = 1;  // decriment
  		    upd_dpy = 1;
  		    floor_ix--;
  		    if(floor_ix < cons[bottomf])
				  floor_ix = (cons[topf]-1);
  		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[2][16] = flmrk[floor_ix][0];
  		   LCD_Display[2][17] = flmrk[floor_ix][1];
  		}
	}
	if (menu_level == 7)
	{			// Secure front Car Call
  		if(mode_sel == 0)	// first time through Secure Car Call
  		{
  			
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	      		LCD_Enter_PB = 1;
				if (secure_yes == 0)
				{
					menu_level = 0;
					upd_dpy = 1;
				}
				else
				{
		      		mode_sel = 1;
		      		floor_ix = cons[bottomf];
		      		for(i=0; i<=19; i++)
		      		{
				  		LCD_Display[0][i] = LCD_Secure_Calls[0][i];
				  		LCD_Display[1][i] = LCD_Secure_Calls[1][i];
				  		LCD_Display[2][i] = LCD_Secure_Calls[2][i];
				  		LCD_Display[3][i] = LCD_Secure_Calls[3][i];
		      		}
		      		upd_dpy = 1;
				}
				return(lcd_menu);
		  	}
	  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  		{
	      		LCD_UP_PB = 1;  // incriment
				secure_yes = 1;
		      	upd_dpy = 1;
		  	}
	  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  		{
	      		LCD_DN_PB = 1;  // decriment
				secure_yes = 0;
		      	upd_dpy = 1;
		  	}
			if ((upd_dpy == 1) && (mode_sel == 0) && (menu_level == 7))
			{
				upd_dpy = 0;
	      		for(i=0; i<=19; i++)
	      		{
				  	LCD_Display[0][i] = getcaps(LCD_Setup_Calls[Menu_list[menu_ptr]][i]);
			  		LCD_Display[1][i] = LCD_Secure_Calls[5][i];
					if (secure_yes == 0)
			  			LCD_Display[2][i] = LCD_Secure_Calls[6][i];
					else
				  		LCD_Display[2][i] = LCD_Secure_Calls[7][i];
					LCD_Display[3][i] = ' ';
	      		}
			}
  		}
		else
		{
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	      		LCD_Enter_PB = 1;
	  		    upd_dpy = 1;
				fl_ix = (floor_ix-1)/32;
				if ((cc_sec_mask[fl_ix] & fl_mask[floor_ix]) == 0)
					cc_sec_mask[fl_ix] |= fl_mask[floor_ix];
				else
					cc_sec_mask[fl_ix] &= ~fl_mask[floor_ix];
				wrfvar();
	  		}
	  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	  		{
	      		LCD_Mode_PB = 1;  //
				menu_level = 0;
				upd_dpy = 1;
				return(lcd_menu);
	  		}
	  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  		{
	      		LCD_UP_PB = 1;  // incriment
	      		upd_dpy = 1;
		      	floor_ix++;
		      	if(floor_ix > cons[topf])
				  	floor_ix = cons[bottomf];
		  	}
	  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  		{
	      		LCD_DN_PB = 1;  // decriment
	      		upd_dpy = 1;
	      		floor_ix--;
	      		if(floor_ix < cons[bottomf])
					  floor_ix = cons[topf];
	  		}
		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[3][16] = flmrk[floor_ix][0];
  		   LCD_Display[3][17] = flmrk[floor_ix][1];
		   	if ((cc_sec_mask[(floor_ix-1)/32] & fl_mask[floor_ix]) != 0)
  		   		LCD_Display[3][18] = '*';
			else
  		   		LCD_Display[3][18] = ' ';
  		}
	}
	if (menu_level == 8)
	{      	  // Secure a Rear Car Call
  		if(mode_sel == 0)	// first time through Secure a Rear Car Call
  		{
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	      		LCD_Enter_PB = 1;
				if (secure_yes == 0)
				{
					menu_level = 0;
					upd_dpy = 1;
				}
				else
				{
		  		    mode_sel = 1;
		  		    floor_ix = cons[bottomf];
		  		    for(i=0; i<=19; i++)
		  		    {
				  		LCD_Display[0][i] = LCD_Secure_Calls[0][i];
				  		LCD_Display[1][i] = LCD_Secure_Calls[1][i];
				  		LCD_Display[2][i] = LCD_Secure_Calls[2][i];
				  		LCD_Display[3][i] = LCD_Secure_Calls[4][i];
		  		    }
		      		upd_dpy = 1;
				}
				return(lcd_menu);
		  	}
	  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  		{
	      		LCD_UP_PB = 1;  // incriment
				secure_yes = 1;
		      	upd_dpy = 1;
		  	}
	  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  		{
	      		LCD_DN_PB = 1;  // decriment
				secure_yes = 0;
		      	upd_dpy = 1;
		  	}
			if ((upd_dpy == 1) && (mode_sel == 0) && (menu_level == 8))
			{
	      		for(i=0; i<=19; i++)
	      		{
				  	LCD_Display[0][i] = getcaps(LCD_Setup_Calls[Menu_list[menu_ptr]][i]);
			  		LCD_Display[1][i] = LCD_Secure_Calls[5][i];
					if (secure_yes == 0)
			  			LCD_Display[2][i] = LCD_Secure_Calls[6][i];
					else
				  		LCD_Display[2][i] = LCD_Secure_Calls[7][i];
					LCD_Display[3][i] = ' ';
	      		}
			}
  		}
		else
		{
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	  		    upd_dpy = 1;
	  		    LCD_Enter_PB = 1;
				fl_ix = (floor_ix-1)/32;
				if ((rcc_sec_mask[fl_ix] & fl_mask[floor_ix]) == 0)
					rcc_sec_mask[fl_ix] |= fl_mask[floor_ix];
				else
					rcc_sec_mask[fl_ix] &= ~fl_mask[floor_ix];					
				wrfvar();
	  		}
	  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	  		{
	  		    LCD_Mode_PB = 1;  //
				menu_level = 0;
				upd_dpy = 1;
				return(lcd_menu);
	  		}
	  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  		{
	  		    LCD_UP_PB = 1;  // incriment
	  		    upd_dpy = 1;
	  		    floor_ix++;
	  		    if(floor_ix > cons[topf])
					  floor_ix = cons[bottomf];
	  		}
	  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  		{
	  		    LCD_DN_PB = 1;  // decriment
	  		    upd_dpy = 1;
	  		    floor_ix--;
	  		    if(floor_ix < cons[bottomf])
					  floor_ix = cons[topf];
	  		}
		}
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[3][16] = flmrk[floor_ix][0];
  		   LCD_Display[3][17] = flmrk[floor_ix][1];
		   	if ((rcc_sec_mask[(floor_ix-1)/32] & fl_mask[floor_ix]) != 0)
  		   		LCD_Display[3][18] = '*';
			else
  		   		LCD_Display[3][18] = ' ';
  		}
	}

	if (menu_level == 9)
	{      	  // Front Car Call	test
		if(mode_sel == 0)	// first time through Setup a Car Call
		{
			if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  		{
	    		LCD_Enter_PB = 1;
				if (((enable_cc_test == 0) && (cancel_cc_test == 0)) 
					|| (continue_cc_test == 1))
				{
					menu_level = 0;
					upd_dpy = 1;
				}
				else
				{
			   		mode_sel = 1;
			   		floor_ix = cons[bottomf];
			   		for(i=0; i<=19; i++)
		   			{
			  			LCD_Display[0][i] = LCD_Car_Call_Test[0][i];
			  			LCD_Display[1][i] = LCD_Car_Call_Test[1][i];
			  			LCD_Display[2][i] = LCD_Car_Call_Test[2][i];
			  			LCD_Display[3][i] = LCD_Car_Call_Test[3][i];
			   		}
			   		upd_dpy = 1;
				}
				return (lcd_menu);
			}

			if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  		{
	    	 	LCD_UP_PB = 1;  // incriment
		   		upd_dpy = 1;
				if ((cc_test_mask[0] != 0) || (cc_test_mask[1] != 0))
					continue_cc_test = 1; 
		 		else
		 			enable_cc_test = 1;
			}

	  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  		{
	    		LCD_DN_PB = 1;  // decriment
		   		upd_dpy = 1;
				if ((cc_test_mask[0] != 0) || (cc_test_mask[1] != 0))
					continue_cc_test = 0;
				else
				{
					cancel_cc_test = 0;
					enable_cc_test = 0;
					cc_test_mask[0] = 0;
					cc_test_mask[1] = 0;
				}
			}
			if ((upd_dpy == 1) && (mode_sel == 0) && (menu_level == 9))
			{
				upd_dpy = 0;
    			for(i=0; i<=19; i++)
	    		{
					if ((cc_test_mask[0] != 0) || (cc_test_mask[1] != 0))
					{
					  	LCD_Display[0][i] = getcaps(LCD_Setup_Calls[Menu_list[menu_ptr]][i]);
		  				LCD_Display[1][i] = LCD_Enable_Car_Call_Test[3][i];
						if (continue_cc_test == 0)
		  					LCD_Display[2][i] = LCD_Enable_Car_Call_Test[5][i];
						else
			  				LCD_Display[2][i] = LCD_Enable_Car_Call_Test[4][i];
  		   				LCD_Display[3][i] = ' ';
					}
					else
					{
				  		LCD_Display[0][i] = getcaps(LCD_Setup_Calls[Menu_list[menu_ptr]][i]);
		  				LCD_Display[1][i] = LCD_Enable_Car_Call_Test[0][i];
						if (enable_cc_test == 0)
		  					LCD_Display[2][i] = LCD_Enable_Car_Call_Test[1][i];
						else
			  				LCD_Display[2][i] = LCD_Enable_Car_Call_Test[2][i];
  		   				LCD_Display[3][i] = ' ';
					}
	    		}
			}
		}
		else
		{
	  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		  	{
		     	upd_dpy = 1;
		  		LCD_Enter_PB = 1;
				fl_ix = (floor_ix-1)/32;
		
				if ((cc_test_mask[fl_ix] & fl_mask[floor_ix]) == 0)
					cc_test_mask[fl_ix] |= fl_mask[floor_ix];
				else
					cc_test_mask[fl_ix] &= ~fl_mask[floor_ix];					
			    
				set_carcall(cons[carnmb],floor_ix);

				if (cons[rear] !=0)
					set_rcarcall(cons[carnmb],floor_ix);
		  	}
	  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
			{
			    LCD_Mode_PB = 1;  //
				menu_level = 0;
				upd_dpy = 1;
				return(lcd_menu);
	  		}
	  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  			{
  			    LCD_UP_PB = 1;  // incriment
	  		    upd_dpy = 1;
	  		    floor_ix++;
  			    if(floor_ix > cons[topf])
					  floor_ix = cons[bottomf];
	  		}
	  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  		{
			    LCD_DN_PB = 1;  // decriment
			    upd_dpy = 1;
  			    floor_ix--;
	  		    if(floor_ix < cons[bottomf])
					  floor_ix = cons[topf];
  			}
	
		}
	  		
  		if(upd_dpy == 1)
  		{
  		   upd_dpy = 0;
  		   LCD_Display[3][16] = flmrk[floor_ix][0];
  		   LCD_Display[3][17] = flmrk[floor_ix][1];

		   	if ((cc_test_mask[(floor_ix-1)/32] & fl_mask[floor_ix]) != 0)
	  	   		LCD_Display[3][18] = '*';
			else
		   		LCD_Display[3][18] = ' ';
  		}
	}
	return(lcd_menu);
}



//****************************************
// Run Elevator Status Subroutine - Menu 6
//****************************************

int16 run_elevator_status (int16 lcd_menu)
{
	int16 i,j;
	static int16 page_sel;
	static int16 mode_sel;
	static int16 cc_fl;
	static int16 upd_dpy;
	
  	if(LCD_Init == 1)	// first time through 
  	{
  	    LCD_Init = 0;
	  	page_sel = 0;
		mode_sel = 0;
  		Elevator_Status_Init(page_sel);
  	}
  	
  	if (mode_sel == 0)
  	{
	  	
	  	if (rdLCDio(Lcd_ENTER) == 1)
	  	{
		  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		  	{
				LCD_UP_PB = 1;  // incriment
				next_trace += 10;		// Jump up 10 trace steps
		  	}
		  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		  	{
		      	LCD_DN_PB = 1;  // decriment
				next_trace -= 10;		// Jump down 10 trace steps
		  	}
		  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		  	{
		      	LCD_Mode_PB = 1;  //
				trig_dpy_ix = 1;		// Home Jump to start of trace
//				end_dpy_ix = 1;			// END Junp to end of trace
		  	}
		  	Trace_ix_dpy = 1;
	  	}
	  	else
	  	{
	  		if (Trace_ix_dpy == 1)
		  	  	Elevator_Status_Init(page_sel);
	  		Trace_ix_dpy = 0;
	  		
		  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		  	{
				LCD_UP_PB = 1;  // incriment
		      	page_sel++;
				if (Trace_Stop == 1)
				{
					if (page_sel > 12)
						page_sel = 0;
				}
				else
				{
					if (page_sel > 14)
						page_sel = 0;
				}
		  	  	Elevator_Status_Init(page_sel);
		  	}
		  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		  	{
		      	LCD_DN_PB = 1;  // decriment
		      	page_sel--;
				if (Trace_Stop == 1)
				{
					if (page_sel < 0)
						page_sel = 12;
				}
				else
				{
					if (page_sel < 0)
						page_sel = 14;
				}

			  	Elevator_Status_Init(page_sel);
		  	}
		  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		  	{
		      	LCD_Mode_PB = 1;  //
				if (page_sel == 0)
				{
			 		mode_sel = 2;		// Go to trace command page
				  	upd_dpy = 1;
				}
				else
				{
				  	mode_sel = 0;
				  	page_sel = 0;
				  	Elevator_Status_Init(page_sel);
		 		}
		  	}
		  	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		  	{
		  	  	LCD_Enter_PB = 1;
	 			if (Trace_Stop == 1)
	 			{
	 				next_trace += 1;		// 1 trace step
				}
	 			else 
	 			{
				  	if (mode_sel == 0)
				  	{
					  	mode_sel = 1;
					  	cc_fl = 1;
					  	upd_dpy = 1;
				  	}
	 			}
		  	}
	  	}
	  	
	  	// Adjust trace index
	  	
		if (Trace_Stop == 1)
		{
			if (set_dpy_ix == 0)
			{
				set_dpy_ix = 1;
				trace_dpy_ix = trace_stop_ix;
			}
			if (trig_dpy_ix == 1)
			{
				trig_dpy_ix = 0;
				trace_dpy_ix = trace_stop_ix;
			}
			if (end_dpy_ix == 1)
			{
				end_dpy_ix = 0;
					
				if ((trace_stop_ix + 35) >= max_trace_ix)
					trace_dpy_ix = (int16)(35 - (max_trace_ix - trace_stop_ix));
				else
					trace_dpy_ix = (int16)(trace_stop_ix + 35);
				
			}
				
			if (next_trace != 0)
			{
				if (next_trace > 0)
				{
					
					if ((trace_dpy_ix + next_trace) >= max_trace_ix)
						trace_dpy_ix = next_trace - (max_trace_ix - trace_dpy_ix);
					else
						trace_dpy_ix += next_trace;
				}
				else
				{
					if ((trace_dpy_ix + next_trace) < 0)
						trace_dpy_ix = max_trace_ix + trace_dpy_ix + next_trace;	  // Restart the index
					else	
						trace_dpy_ix += next_trace;
				
				}
				next_trace = 0;
			}
		}	
		else
		{
			set_dpy_ix = 0;
			trace_dpy_ix = Trace_ix;
		}
		
	  	Elevator_Status(page_sel,&S_Trace[trace_dpy_ix]);
  	}
  	else if (mode_sel == 1)
  	{		// Set Car Call 
	  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  	{
			LCD_UP_PB = 1;  // incriment
	      	cc_fl++;
			if (cc_fl > cons[topf])
				cc_fl = cons[bottomf];
			
			upd_dpy = 1;
	  	}
	  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  	{
	      	LCD_DN_PB = 1;  // decriment
	      	cc_fl--;
			if (cc_fl < cons[bottomf])
				cc_fl = cons[topf];

			upd_dpy = 1;
	  	}
	  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	  	{
	      	LCD_Mode_PB = 1;  //
		  	mode_sel = 0;
		   	Elevator_Status_Init(page_sel);
			return(lcd_menu);
	  	}
	  	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  	{
	  	  	LCD_Enter_PB = 1;
	  	  	if (set_carcall(cons[carnmb],cc_fl) == 0)
	  	  	{
	  	  		if (cons[rear] !=0)
					set_rcarcall(cons[carnmb],cc_fl);
	  	  	}
		  	mode_sel = 0;
		  	Elevator_Status_Init(page_sel);
			return(lcd_menu);
	  	}
	  	
	  	if (upd_dpy == 1)
	  	{
	  		upd_dpy = 0;
	  		j = 0;
  		    for(i=5; i<=15; i++)
  		    {
				LCD_Display[1][i] = Set_Calls_Window[0][j];
			  	LCD_Display[2][i] = Set_Calls_Window[1][j];
			  	LCD_Display[3][i] = Set_Calls_Window[2][j];
			  	j++;
  		    }
  			LCD_Display[2][13] = flmrk[cc_fl][0];
  			LCD_Display[2][14] = flmrk[cc_fl][1];
	  	}
  	}
  	else if (mode_sel == 2)
  	{		// Trace Command
	  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	  	{
	      	LCD_Mode_PB = 1;  //
		  	mode_sel = 0;
			lcd_menu = 0;
			return(lcd_menu);
	  	}
	  	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	  	{
	  	  	LCD_Enter_PB = 1;
		  	mode_sel = 0;
		  	set_dpy_ix = 0;
	 		if (Trace_Stop == 0)
				Trace_Trigger = 1;		// Stop trace
			else
				Trace_Stop = 0;			// Start trace (allow to run)
			
		  	Elevator_Status_Init(page_sel);
			return(lcd_menu);
	  	}
	  	
	  	if (upd_dpy == 1)
	  	{
	  		upd_dpy = 0;
	  		j = 0;
  		    for(i=5; i<=16; i++)
  		    {
				LCD_Display[0][i] = Trace_Window[0][j];
	 			if (Trace_Stop == 0)
			  		LCD_Display[1][i] = Trace_Window[1][j];
	 			else
				  	LCD_Display[1][i] = Trace_Window[2][j];
			  	LCD_Display[2][i] = Trace_Window[3][j];
				LCD_Display[3][i] = Trace_Window[4][j];
			  	j++;
  		    }
	  	}
  	}

	return(lcd_menu);
}

int16 view_fault_log (int16 lcd_menu)
{
	int16 i;
	int16 j;
	int16 k;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	static int16 menu_ptr_ret;
	static int16 dpy_flt_ix;
	static int16 dpy_nmb_flt;
	static int16 dpy_flt_line;
	static int16 dpy_ix;

	
	if (LCD_Init == 1)
	{
		LCD_Init = 0; 
		upd_dpy = 1;
		menu_level = 0;
		menu_ptr = 0;
  	}

	if (menu_level == 0)
	{			// Rotate through Fault menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  menu_ptr = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
		    if(menu_ptr > 1)
			  menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = (int16)(menu_ptr + 1);
  			menu_ptr_ret = menu_ptr;
  		    menu_ptr = 0;
  		    LCD_Sub_Init = 1;
		  	return(lcd_menu);
		}
	
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
	  			LCD_Display[0][i] = LCD_Main_Menu[7][i];
			  	LCD_Display[1][i] = LCD_Fault_Log[0][i];
			  	LCD_Display[2][i] = LCD_Fault_Log[1][i];
			  	LCD_Display[3][i] = ' ';
		    }
			LCD_Display[menu_ptr+1][0] = '>';		// show cursor
		}
	}
	else if (menu_level == 1)
	{		// View Fault Log  or detailed fault log
	  	if (LCD_Sub_Init == 1)	// first time through View Fault Log
	  	{
	  		LCD_Sub_Init = 0;
	      	upd_dpy = 1;
		  	i = 0;
		  	j = 0;
			dpy_ix = 1;
			k = Flt_ix;
		  	k++;
		  	if (k >= max_flt_ix)
			  	k = 0;
		  	while ((i < max_flt_ix) && (j == 0))
		  	{
				if (f.Flts[k].code != 0)
					j = k;
				else
				{
					k++;
					if (k >= max_flt_ix)
						k = 0;
				}
				i++;
		
		  	}
			dpy_nmb_flt = (max_flt_ix - i) + 1;
	      	dpy_flt_ix = j;
			dpy_flt_line = 0;
	  	}
	  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	  	{
	      	LCD_Mode_PB = 1;  
			if (dpy_flt_line == 0)
			{
				menu_level = 0;
				menu_ptr = menu_ptr_ret;
	 			upd_dpy = 1;
	 			return(lcd_menu);
			}
			else   // not at zero so step back one level
			{
				dpy_flt_line = 0;
			  	upd_dpy = 1;
			}
	  	}
	  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	  	{
	      	LCD_UP_PB = 1;  // incriment
	      	upd_dpy = 1;
			if(dpy_flt_line == 0)
			{
			  	i = 0;
			  	j = 0;
			  	k = dpy_flt_ix;
				if (k == Flt_ix)
					dpy_ix = 0;	 //  will be changed to 1 below
			  	k++;
			  	if (k >= max_flt_ix)
				  	k = 0;
			  	while ((i < max_flt_ix) && (j == 0))
			  	{
					if (f.Flts[k].code != 0)
						j = k;
					else
					{
						k++;
						if (k >= max_flt_ix)
							k = 0;
					}
					i++;
			
			  	}
				if ((i > 1) && (((max_flt_ix - i) + 1) > dpy_nmb_flt))
					dpy_nmb_flt = (max_flt_ix - i) + 1;
				if (dpy_flt_ix != j)
				{
					if (dpy_ix < max_flt_ix)
						dpy_ix++;
					else
						dpy_ix = 1;
				}
				else if (dpy_ix == 0)
					dpy_ix = 1;
	      		dpy_flt_ix = j;
			}
			else
			{
				
				if (dpy_flt_line < 12)
					dpy_flt_line ++;
				else
					dpy_flt_line = 1;
			}
	  	}
	  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	  	{
	      	LCD_DN_PB = 1;  // decriment
	      	upd_dpy = 1;
			if(dpy_flt_line == 0)
			{
			  	i = 0;
			  	j = 0;
			  	k = dpy_flt_ix;
			  	k--;
			  	if (k < 0)
				  	k = max_flt_ix - 1;
			  	while ((i < max_flt_ix) && (j == 0))
			  	{
					if (f.Flts[k].code != 0)
						j = k;
					else
					{
						k--;
				    	if (k < 0)
					    	k = max_flt_ix - 1;
					}
					i++;
			
			  	}
				if ((i > 1) && (((max_flt_ix - i) + 1) > dpy_nmb_flt))
					dpy_nmb_flt = (max_flt_ix - i) + 1;
				if (dpy_flt_ix != j)
				{
					if (dpy_ix > 1)
						dpy_ix--;
					else
						dpy_ix = dpy_nmb_flt;
				}
	      		dpy_flt_ix = j;
			}
			else
			{
				if (dpy_flt_line > 1)
					dpy_flt_line--;
				else
					dpy_flt_line = 12;
				
			}
	  	}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
			upd_dpy = 1;
			if (dpy_flt_line == 0)
				dpy_flt_line = 1;
			else
				dpy_flt_line = 0;
		}

	  	if(upd_dpy != 0)
	  	{
			fault_display(dpy_flt_line, dpy_flt_ix, dpy_ix);
	     	upd_dpy = 0;
	  	}
	}
	else if (menu_level == 2)
	{				// Clear Fault Log
  		if(LCD_Sub_Init == 1)	// first time through View Fault Log
  		{
	  		LCD_Sub_Init = 0;
  		    for(i=0; i<=19; i++)
  		    {
				  LCD_Display[0][i] = LCD_Clear_Fault[0][i];
				  LCD_Display[1][i] = LCD_Clear_Fault[1][i];
				  LCD_Display[2][i] = ' ';
				  LCD_Display[3][i] = ' ';
  		    }
  		}
  		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
  		    for(i=0; i<=19; i++)
  		    {
				LCD_Display[0][i] = LCD_Clear_Fault[2][i];
				LCD_Display[1][i] = LCD_Clear_Fault[3][i];
				  LCD_Display[2][i] = ' ';
				  LCD_Display[3][i] = ' ';
  		    }
	      	for(i=0; i<max_flt_ix; i++)
	      	{
				f.Flts[i].code = 0;
				f.Flts[i].count = 0;
	      	}
			Flt_ix = 0;
  		    Update_All_Flt();
			clr_mrcan_dev_comm_loss();
			clr_ctcan_dev_comm_loss();
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  //
			menu_level = 0;
			menu_ptr = menu_ptr_ret;
			upd_dpy = 1;
			return(lcd_menu);
  		}
	}
	else
		menu_level = 0;
	return(lcd_menu);
}

int16 display_hoistway_floor_table (int16 lcd_menu)
{
	int16 i;
	int16 start_ptr;
	int16 line_ptr;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	
    if(LCD_Init == 1) // First time through
    {
		upd_dpy = 1;
		LCD_Init = 0;
  	}

	if (menu_level == 0)
	{			// Rotate through input and output menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
			  menu_ptr = Last_Hoistway_Menu;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
		    if(menu_ptr > Last_Hoistway_Menu)
			  menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = (int16)(Hoistway_Menu_list[menu_ptr] + 1);
		  	LCD_Sub_Init = 1;		// for menus that do not need menu[2]
			return(lcd_menu);
		}
		if(upd_dpy == 1)
		{
		  	upd_dpy = 0;
	  		line_ptr = menu_ptr % 3;
	  		start_ptr = menu_ptr - line_ptr;
	  	    for(i=0; i<=19; i++)
	  	    {
	  			LCD_Display[0][i] = LCD_Main_Menu[9][i];
				LCD_Display[1][i] = LCD_Dpy_Hoistway[Hoistway_Menu_list[start_ptr]][i];
				if ((start_ptr + 1) > Last_Hoistway_Menu)
			  	{
			  		LCD_Display[2][i] = ' ';
			  		LCD_Display[3][i] = ' ';
			  	}
			  	else
			  	{
					LCD_Display[2][i] = LCD_Dpy_Hoistway[Hoistway_Menu_list[start_ptr+1]][i];
					if ((start_ptr + 2) > Last_Hoistway_Menu)
				  		LCD_Display[3][i] = ' ';
					else
						LCD_Display[3][i] = LCD_Dpy_Hoistway[Hoistway_Menu_list[start_ptr+2]][i];
			  	}
	  	    }
			LCD_Display[line_ptr+1][0] = '>';		// show cursor
		}
	}
	else if (menu_level == 1)  
	{
		menu_level = display_hoistway(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	else if (menu_level == 2)
	{
		menu_level = display_short_floor_sd(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	else if (menu_level == 3)
	{
		menu_level = display_cpu_limits(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	else if (menu_level == 4)
	{
		menu_level = display_dz_off(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}
	else if (menu_level == 5)
	{
		menu_level = dpy_aps_valid_fl_table(menu_level);
		if (menu_level == 0)
		{
			upd_dpy = 1;
		}
	}

	return(lcd_menu);
}

int16 set_service_timers (int16 lcd_menu)
{
	lcd_menu = 0;
	return (lcd_menu);
/*
	int16 i;
		
	if (LCD_Pointer == 10)
	{
		upd_dpy = 1;
		LCD_Pointer++; 
		Menu_level = 0;
	    for(i=0; i<=19; i++)
	  		LCD_Display[0][i] = LCD_Main_Menu[10][i];
  	}

	if (Menu_level == 0)
	{			// Rotate through Call menu items
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    LCD_Pointer++;
		    if(LCD_Pointer > 20)
			  LCD_Pointer = 11;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    LCD_Pointer--;
		    if(LCD_Pointer < 11)
			  LCD_Pointer = 20;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	Timer_Number = (LCD_Pointer - 11);
			LCD_Pointer = 0;
			Menu_level = 1;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
			  	LCD_Display[1][i] = LCD_Timer_Menu[0][i];
			LCD_Display[1][19] = (char)((LCD_Pointer - 11) + '0'); 
		}
	}

	if (Menu_level > 0)
		Service_Timers();
	
	*/
	return(lcd_menu);
}

int16 cc_pb_security (int16 lcd_menu)
{
	lcd_menu = 0;
	return (lcd_menu);
/*
	int16 i;
	
	if(LCD_Pointer == 11)
	{
		LCD_Pointer++;
		Menu_level = 0;
		LCD_Sub_Point = 0;       //  used to navigate thru  the  Security_dpy Table
		LCD_Dig_Point = 0;	
	}
	if(Menu_level == 0)
	{
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = LCD_Main_Menu[LCD_Pointer-1][i];
		}

		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{			   
			LCD_Enter_PB = 1;

			if(LCD_Sub_Point == 0)
			{		   // Setup codes per floor
				Menu_level = 2;
				LCD_FloorNum = 1;
				Security_Dpy_Index = 0;
			}
			else if(LCD_Sub_Point == 1)
			{					 // Remove all codes for all floors
				Menu_level = 6;
				Security_Dpy_Index = 10;
			}			
			LCD_Dig_Point = 0;
			LCD_Sub_Point = 0; 
			clrLCDdpy(); 					
			return;	
		}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{
			LCD_Mode_PB = 1;
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
			LCD_UP_PB = 1;  // incriment
			if (Dispatcher == cons[carnmb])
			{
				LCD_Sub_Point++;
				if (LCD_Sub_Point > 1)
					LCD_Sub_Point = 0;
			}
			else
				LCD_Sub_Point = 0;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
			LCD_DN_PB = 1;  // decriment
			if (Dispatcher == cons[carnmb])
			{
				LCD_Sub_Point--;
				if (LCD_Sub_Point < 0)
					LCD_Sub_Point = 1;
			}
			else
				LCD_Sub_Point = 0;
		}
		for(i=0;i<=19;i++)
		{
			LCD_Display[1][i] = Security_dpy[LCD_Sub_Point][i];
		}			

	}
	if(Menu_level == 1)					   // Check to see if user still wants to enter command
	{									   // Verify Yes or no
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = Security_dpy[Security_Dpy_Index][i];
		}				
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{			   
			LCD_Enter_PB = 1;					
			if(Security_Dpy_Index == 3)
			{
				if(LCD_Sub_Point == 1)
				{
					if (code_floor_access == 1)
						Code_Num[0] |= 0x80;
					else
						Code_Num[0] &= 0x7F;
					gc_Add_Sec_Fl_Req = (uint8)LCD_FloorNum;
					gc_Add_Sec_Code[0] = Code_Num[0];
					gc_Add_Sec_Code[1] = Code_Num[1];
					gc_Add_Sec_Code[2] = Code_Num[2];
					gc_Add_Sec_Code[3]	= Code_Num[3];
					if (Add_Security_Code(LCD_FloorNum, &CodeTable, LookUpTable, Code_Num) == 1)
						put_pkt_req_all_cars(5);
				}
				Menu_level = 3;
				Security_Dpy_Index = Floor_Dpy_Offset;
				LCD_Sub_Point = 1;
				return;
			}
			else if(Security_Dpy_Index == 4)
			{
				if(LCD_Sub_Point == 1)
				{
					if (code_floor_access == 1)
						Code_Num[0] |= 0x80;
					else
						Code_Num[0] &= 0x7F;
					gc_Del_Sec_Fl_Req = (uint8)LCD_FloorNum;
					gc_Del_Sec_Code[0] = Code_Num[0];
					gc_Del_Sec_Code[1] = Code_Num[1];
					gc_Del_Sec_Code[2] = Code_Num[2];
					gc_Del_Sec_Code[3]	= Code_Num[3];
					if (Delete_Security_Code(LCD_FloorNum, &CodeTable, LookUpTable, Code_Num) == 1)
						put_pkt_req_all_cars(6);
				}
				Menu_level = 3;
				Security_Dpy_Index = Floor_Dpy_Offset;
				LCD_Sub_Point = 2;
				return;
			}
			else if(Security_Dpy_Index == 5)
			{
				if(LCD_Sub_Point == 1)
				{
					gc_Del_All_Codes_Fl_Req = (uint8)LCD_FloorNum;
					put_pkt_req_all_cars(33);
					Clear_All_Codes_One_Floor(LCD_FloorNum, &CodeTable, LookUpTable);
				}
				Menu_level = 3;
				Security_Dpy_Index = Floor_Dpy_Offset;
				LCD_Sub_Point = 3;
				return;
			}
			else if(Security_Dpy_Index == 10)
			{		  // Add one code all floors
				if(LCD_Sub_Point == 1)
				{
					if (code_floor_access == 1)
						Code_Num[0] |= 0x80;
					else
						Code_Num[0] &= 0x7F;
					gc_Add_Sec_Fl_Req = 0xFF;
					gc_Add_Sec_Code[0] = Code_Num[0];
					gc_Add_Sec_Code[1] = Code_Num[1];
					gc_Add_Sec_Code[2] = Code_Num[2];
					gc_Add_Sec_Code[3]	= Code_Num[3];
					Add_One_Code_All_Floors(1, 0, Code_Num);
					put_pkt_req_all_cars(5);
				}
				Menu_level = 6;
				LCD_Sub_Point = 1;
				return;
			}							
			else if(Security_Dpy_Index == 11)
			{			 // Delete one code all floors
				if(LCD_Sub_Point == 1)
				{
					if (code_floor_access == 1)
						Code_Num[0] |= 0x80;
					else
						Code_Num[0] &= 0x7F;
					gc_Del_Sec_Fl_Req = 0xFF;
					gc_Del_Sec_Code[0] = Code_Num[0];
					gc_Del_Sec_Code[1] = Code_Num[1];
					gc_Del_Sec_Code[2] = Code_Num[2];
					gc_Del_Sec_Code[3]	= Code_Num[3];
					Delete_One_Code_All_Floors(1, 0, Code_Num);
					put_pkt_req_all_cars(6);
				}
				Menu_level = 6;
				LCD_Sub_Point = 1;
				return;
			}							
			else if(Security_Dpy_Index == 12)
			{		   // Delete all codes alll floors
				if(LCD_Sub_Point == 1)
				{
					gc_Del_All_Codes_Fl_Req = 0xFF;
					put_pkt_req_all_cars(33);
					Clear_All_Codes_All_Floors(1,0);
				}
				Menu_level = 6;
				LCD_Sub_Point = 1;
				return;
			}							
			clrLCDdpy();
		}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{
			LCD_Mode_PB = 1; 				   	
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
			LCD_UP_PB = 1;  // incriment
			LCD_Sub_Point++;
			if (LCD_Sub_Point > 1)
				LCD_Sub_Point = 0;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
			LCD_DN_PB = 1;  // decriment
			LCD_Sub_Point--;
			if (LCD_Sub_Point < 0)
				LCD_Sub_Point = 1;
		}

		if (LCD_Flash != 0)
		{
			for(i=0;i<=19;i++)
			{
				LCD_Display[1][i] = Security_dpy[NO_YES_Dpy_Offset + LCD_Sub_Point][i];
			}
		}
		else
		{
			for(i=10;i<=15;i++)
			{
				LCD_Display[1][i] = ' ';
			}
		}
	}
	if(Menu_level == 2)
	{				// Select floor to work with
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = Security_dpy[MainMenu_Dpy_Offset][i];
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{			   
			LCD_Enter_PB = 1;
			Security_Dpy_Index = Function_Dpy_Offset;
			LCD_Sub_Point = 0;
			Menu_level = 3;
			clrLCDdpy();
			return;
		}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{
			LCD_Mode_PB = 1;
			Menu_level = 0;
			LCD_Sub_Point = MainMenu_Dpy_Offset;
			return;
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
			LCD_UP_PB = 1;  // incriment
			LCD_FloorNum++;
			if (LCD_FloorNum > cons[grtopf])
				LCD_FloorNum = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
			LCD_DN_PB = 1;  // decriment
			LCD_FloorNum--;
			if(LCD_FloorNum < 1)
				LCD_FloorNum = cons[grtopf];
		}

		for(i=0;i<=19;i++)
		{
			LCD_Display[1][i] = Security_dpy[Floor_Dpy_Offset][i];
		}
		LCD_Display[1][16] = flmrk[LCD_FloorNum][0];
		LCD_Display[1][17] = flmrk[LCD_FloorNum][1];
	}
	if(Menu_level == 3)
	{				  // Select code modification operation
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = Security_dpy[Floor_Dpy_Offset][i];
		}
		LCD_Display[0][16] = flmrk[LCD_FloorNum][0];
		LCD_Display[0][17] = flmrk[LCD_FloorNum][1];

		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{			   
			LCD_Enter_PB = 1;					
			Security_Dpy_Index = LCD_Sub_Point + Function_Dpy_Offset;

			if((Security_Dpy_Index == 3) || (Security_Dpy_Index == 4))	 // Add or Delete Code
			{
				//initialize the  code digits 
				Code_Num[0] = 1;
				Code_Num[1] = 1;
				Code_Num[2] = 1;
				Code_Num[3] = 1;
				Menu_level = 4;
			}
			else if(Security_Dpy_Index == 5)	 // Clear All Codes
			{
				Menu_level = 1;					  
			}
			else if(Security_Dpy_Index == 2)	 // View Codes
				Menu_level = 5;		 					
			
			Read_CodeTbl(LCD_FloorNum, &CodeTable, LookUpTable);
			LCD_Sub_Point = 0;
			LCD_Dig_Point = 1;
			clrLCDdpy();
			return;
		}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{
			LCD_Mode_PB = 1;
			Menu_level = 2;
			LCD_Sub_Point = 0;
			Security_Dpy_Index = MainMenu_Dpy_Offset; 				 // Back to Modify Floor Security Display
			return;
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
			LCD_UP_PB = 1;  // incriment
			if (Dispatcher == cons[carnmb])
			{
				LCD_Sub_Point++;
				if(LCD_Sub_Point > 3)
					LCD_Sub_Point = 0;
			}
			else
				LCD_Sub_Point = 0;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
			LCD_DN_PB = 1;  // decriment
			if (Dispatcher == cons[carnmb])
			{
				LCD_Sub_Point--;
				if(LCD_Sub_Point < 0)
					LCD_Sub_Point = 3;
			}
			else
				LCD_Sub_Point = 0;
		} 

		for(i=0;i<=19;i++)
		{
			LCD_Display[1][i] = Security_dpy[LCD_Sub_Point+Function_Dpy_Offset][i];
		}
	}
	if(Menu_level == 4)						            // Add && delete Code
	{
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = Security_dpy[Security_Dpy_Index][i];
		}

		if ((Security_Dpy_Index == 3) && (CodeTable.NumCode >= NumMaxCd)) 
		{		// Display code table full
			if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
			{			   
				LCD_Enter_PB = 1;
				Menu_level = 3;
				Security_Dpy_Index = Floor_Dpy_Offset;
				LCD_Sub_Point = 1;
				return;
			}
			if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
			{
				LCD_Mode_PB = 1;	     
				Menu_level = 3;
				Security_Dpy_Index = Floor_Dpy_Offset;
				LCD_Sub_Point = 1;
				return;	
			}
			for(i=0;i<=19;i++)
			{
				LCD_Display[1][i] = Security_dpy[13][i];
			}
		}
		else
		{			
			if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
			{			   
				LCD_Enter_PB = 1;
				Menu_level = 1;	
			}
			if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
			{
				LCD_Mode_PB = 1;	     
				LCD_Dig_Point++;
				if (LCD_Dig_Point > 5)
					LCD_Dig_Point = 1;
			}
			if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
			{
				LCD_UP_PB = 1;  // incriment
				if(LCD_Dig_Point == 1)
				{
					Code_Num[0]++;
					if (Code_Num[0] > (unsigned char)cons[grtopf])
						Code_Num[0] = 1;
				}
				else if(LCD_Dig_Point == 2)
				{
					Code_Num[1]++;
					if (Code_Num[1] > (unsigned char)cons[grtopf])
						Code_Num[1] = 1;

				}
				else if(LCD_Dig_Point == 3)
				{
					Code_Num[2]++;
					if (Code_Num[2] > (unsigned char)cons[grtopf])
						Code_Num[2] = 1;
				}
				else if(LCD_Dig_Point == 4)
				{
					Code_Num[3]++;
					if (Code_Num[3] > (unsigned char)cons[grtopf])
						Code_Num[3] = 1;					
				}
				else if (LCD_Dig_Point == 5)
				{
					if (code_floor_access == 1)
						code_floor_access = 0;
					else
						code_floor_access = 1;
				}
			}
			if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
			{
				LCD_DN_PB = 1;  // decriment
				if(LCD_Dig_Point == 1)
				{
					Code_Num[0]--;
					if(Code_Num[0] < 1)
						Code_Num[0] = (uint8)cons[grtopf];
				}
				else if(LCD_Dig_Point == 2)
				{
					Code_Num[1]--;
					if(Code_Num[1] < 1)
						Code_Num[1] = (uint8)cons[grtopf];

				}
				else if(LCD_Dig_Point == 3)
				{
					Code_Num[2]--;
					if(Code_Num[2] < 1)
						Code_Num[2] = (uint8)cons[grtopf];
				}
				else if(LCD_Dig_Point == 4)
				{
					Code_Num[3]--;
					if(Code_Num[3] < 1)
						Code_Num[3] = (uint8)cons[grtopf];				
				}
				else if (LCD_Dig_Point == 5)
				{
					if (code_floor_access == 1)
						code_floor_access = 0;
					else
						code_floor_access = 1;
				}
			}
			LCD_Display[1][4] = flmrk[Code_Num[0]][0];
			LCD_Display[1][5] = flmrk[Code_Num[0]][1];
			LCD_Display[1][8] = flmrk[Code_Num[1]][0];
			LCD_Display[1][9] = flmrk[Code_Num[1]][1];
			LCD_Display[1][12] = flmrk[Code_Num[2]][0];
			LCD_Display[1][13] = flmrk[Code_Num[2]][1];
			LCD_Display[1][16] = flmrk[Code_Num[3]][0];
			LCD_Display[1][17] = flmrk[Code_Num[3]][1];

			if (code_floor_access == 1)
				LCD_Display[1][21] = 'R';
			else
				LCD_Display[1][21] = 'F';

			if (LCD_Flash != 0)
			{
				if(LCD_Dig_Point == 1)
				{
					LCD_Display[1][4] = ' ';
					LCD_Display[1][5] = ' ';
				}
				else if(LCD_Dig_Point == 2)
				{
					LCD_Display[1][8] = ' ';
					LCD_Display[1][9] = ' ';
				}
				else if(LCD_Dig_Point == 3)
				{
					LCD_Display[1][12] = ' ';
					LCD_Display[1][13] = ' ';
				}
				else if(LCD_Dig_Point == 4)
				{
					LCD_Display[1][16] = ' ';
					LCD_Display[1][17] = ' ';
				}
				else if (LCD_Dig_Point == 5)
				{
					LCD_Display[1][21] = ' ';
				}
			} 
		}
	}
	if(Menu_level == 5)									// View code 
	{
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = Security_dpy[Security_Dpy_Index][i];
		}

		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{			   
			LCD_Enter_PB = 1;
			Menu_level = 3;
			LCD_Sub_Point = 0;
			Security_Dpy_Index = 2;
			return;
		}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{
			LCD_Mode_PB = 1;
			Menu_level = 3;
			LCD_Sub_Point = 0;
			Security_Dpy_Index = 2;
			return;
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
			LCD_UP_PB = 1;  // incriment
			LCD_Sub_Point++;
			if(LCD_Sub_Point > CodeTable.NumCode - 1)
				LCD_Sub_Point = 0;	 
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
			LCD_DN_PB = 1;  // decriment
			LCD_Sub_Point--;
			if(LCD_Sub_Point < 0)
			{
				if (CodeTable.NumCode > 0)
					LCD_Sub_Point = CodeTable.NumCode - 1;
				else
					LCD_Sub_Point = 0;
			}
				
		}

		if (CodeTable.Codes[LCD_Sub_Point][0] == 0)
		{
			for(i=0;i<=19;i++)
			{
				LCD_Display[1][i] = Security_dpy[Code_Tbl_Empty_Offset][i];
			}
		}
		else
		{
			LCD_Display[1][4] = flmrk[CodeTable.Codes[LCD_Sub_Point][0] & 0x7F][0];
			LCD_Display[1][5] = flmrk[CodeTable.Codes[LCD_Sub_Point][0] & 0x7F][1];
			LCD_Display[1][8] = flmrk[CodeTable.Codes[LCD_Sub_Point][1]][0];
			LCD_Display[1][9] = flmrk[CodeTable.Codes[LCD_Sub_Point][1]][1];
			LCD_Display[1][12] = flmrk[CodeTable.Codes[LCD_Sub_Point][2]][0];
			LCD_Display[1][13] = flmrk[CodeTable.Codes[LCD_Sub_Point][2]][1];
			LCD_Display[1][16] = flmrk[CodeTable.Codes[LCD_Sub_Point][3]][0];
			LCD_Display[1][17] = flmrk[CodeTable.Codes[LCD_Sub_Point][3]][1];
			if ((CodeTable.Codes[LCD_Sub_Point][0] & 0x80) != 0)
				LCD_Display[1][21] = 'R';
			else
				LCD_Display[1][21] = 'F';
		}
	}
	if (Menu_level == 6)
	{		// Add or delete single code or delete all codes for all floors
		for(i=0;i<=19;i++)
		{
			LCD_Display[0][i] = Security_dpy[1][i];
		}

		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{			   
			LCD_Enter_PB = 1;					

			if((Security_Dpy_Index == 10)||(Security_Dpy_Index == 11))	 // Add or Delete Code
			{
				//initialize the  code digits 
				Code_Num[0] = 1;
				Code_Num[1] = 1;
				Code_Num[2] = 1;
				Code_Num[3] = 1;
				Menu_level = 4;
			}
			else if(Security_Dpy_Index == 12)	 // Clear All Codes
			{
				Menu_level = 1;					  
			}
			LCD_Sub_Point = 0;
			LCD_Dig_Point = 1;
			clrLCDdpy();
			return;
		}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{
			LCD_Mode_PB = 1;
			Menu_level = 0;
			LCD_Sub_Point = 1;
			Security_Dpy_Index = 1; 				 // Back to Sec Codes all floors Display
			return;
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
			LCD_UP_PB = 1;  // incriment
			if (Dispatcher == cons[carnmb])
			{
				Security_Dpy_Index++;
				if(Security_Dpy_Index > 12)
					Security_Dpy_Index = 10;
			}
			else
				Security_Dpy_Index = 0;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
			LCD_DN_PB = 1;  // decriment
			if (Dispatcher == cons[carnmb])
			{
				Security_Dpy_Index--;
				if(Security_Dpy_Index < 10)
					Security_Dpy_Index = 12;
			}
			else
				Security_Dpy_Index = 0;
		} 

		for(i=0;i<=19;i++)
		{
			LCD_Display[1][i] = Security_dpy[Security_Dpy_Index][i];
		}
	}
	*/
	return(lcd_menu);
}

int16 adjust_lcd_display (int16 lcd_menu)
{
	int16 i;
	static int16 upd_dpy;
	static int16 menu_level;
	static int16 menu_ptr;
	int16 contrast_point;
	static int16 new_contrast;
	static int16 new_brightness;

	if (LCD_Init == 1)
	{
		LCD_Init  = 0;
		menu_ptr = 0;
		menu_level = 0;
		contrast_point = 0;
  	    upd_dpy = 1;
	}

	if (menu_level == 0)
	{			// Select time menu

		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			lcd_menu = 0;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    menu_ptr--;
		    if(menu_ptr < 0)
				menu_ptr = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    menu_ptr++;
	    	if(menu_ptr > 1)
				menu_ptr = 0;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	menu_level = menu_ptr + 1;
		  	LCD_Sub_Init = 1;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
				LCD_Display[0][i] = LCD_Main_Menu[12][i];
			  	LCD_Display[1][i] = LCD_Dpy_Adjust_Menu[0][i];
			  	LCD_Display[2][i] = LCD_Dpy_Adjust_Menu[1][i];
			  	LCD_Display[3][i] = ' ';
		    }
			LCD_Display[menu_ptr+1][0] = '>';		// show cursor
		}
	}
	else if (menu_level == 1)
	{
		if (LCD_Sub_Init == 1)
		{
			LCD_Sub_Init = 0;
			new_contrast = get_contrast();
			if (new_contrast < 25)
				new_contrast = 25;
		  	upd_dpy = 1;
		}
		
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			menu_level = 0;
		  	upd_dpy = 1;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    new_contrast++;
	    	if(new_contrast > 50)
				new_contrast = 50;
	    	set_contrast(new_contrast);
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    new_contrast--;
		    if(new_contrast < 25)
				new_contrast = 25;
	    	set_contrast(new_contrast);
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
			  	LCD_Display[0][i] = getcaps(LCD_Dpy_Adjust_Menu[0][i]);
			  	LCD_Display[1][i] = ' ';
			  	LCD_Display[2][i] = LCD_Dpy_Adjust_Menu[2][i];
			  	LCD_Display[3][i] = ' ';
		    }
		    contrast_point = (new_contrast - 25)/2;
			LCD_Display[2][contrast_point+2] = '|';		// show cursor
		  	itoa(new_contrast, LCD_String);  // position
			if(new_contrast < 10)                // of the
			  	LCD_Display[2][18] = LCD_String[0];         // fault
			else
			{
			  	LCD_Display[2][17] = LCD_String[0];
			  	LCD_Display[2][18] = LCD_String[1];
			}
		}
	}
	else if (menu_level == 2)
	{
		if (LCD_Sub_Init == 1)
		{
			LCD_Sub_Init = 0;
			new_brightness = get_brightness();
		  	upd_dpy = 1;
		}
		
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
		{	   // Exit to main menu
			LCD_Mode_PB = 1;  //
			menu_level = 0;
		  	upd_dpy = 1;
			return(lcd_menu);
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    new_brightness++;
	    	if(new_brightness > 8)
				new_brightness = 8;
	    	set_brightness(new_brightness);
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    new_brightness--;
		    if(new_brightness < 1)
				new_brightness = 1;
	    	set_brightness(new_brightness);
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
		    {
			  	LCD_Display[0][i] = getcaps(LCD_Dpy_Adjust_Menu[1][i]);
			  	LCD_Display[1][i] = ' ';
			  	LCD_Display[2][i] = LCD_Dpy_Adjust_Menu[3][i];
			  	LCD_Display[3][i] = ' ';
		    }
			LCD_Display[2][new_brightness+1] = '|';		// show cursor
		  	itoa(new_brightness, LCD_String);  // position
			if(new_brightness < 10)                // of the
			  	LCD_Display[2][13] = LCD_String[0];         // fault
			else
			{
			  	LCD_Display[2][12] = LCD_String[0];
			  	LCD_Display[2][13] = LCD_String[1];
			}
		}
	}
	return(lcd_menu);
}

int16 display_immediate_fault(int16 lcd_menu)
{
	static int16 upd_dpy;

	if (LCD_Pointer == 24)
	{
		upd_dpy = 1;
		LCD_Pointer++;
		FaultInterrupt = true;			
	}

   	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  	{
  	    LCD_Enter_PB = 1;
		FaultInterrupt = false;			
  	}
  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  	{
 		lcd_menu = 0;
 	    LCD_Mode_PB = 1;  
		FaultInterrupt = false;			
  	}
  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  	{
  	    LCD_UP_PB = 1;  // incriment
		FaultInterrupt = false;			
  	}
  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  	{
  	    LCD_DN_PB = 1;  // decriment
		FaultInterrupt = false;			
	}
  	
  	if(upd_dpy == 1)
  	{
     	upd_dpy = 0;
		fault_display(13,Flt_ix,0);		// 13 used for special to not show index #
  	}
	if (FaultInterrupt == false)
		ReturnLCDMenu();

	return(lcd_menu);
}


int16 password (int16 lcd_menu)
{
	int16 i;
	
	static int16 upd_dpy;
	static int16 mode_sel;

	if(LCD_Init == 1)
	{
		LCD_Init = 0;
		upd_dpy = 1;
  	    LCD_Dig_Point = 0;
		mode_sel = 0;
		Password = 0;
    	for(i=0; i<=19; i++)
  			LCD_Display[0][i] = Password_dpy[2][i];
        sprintf(&LCD_Display[1][9],"%04i",Password);
	}

	if(mode_sel == 0)
	{
   		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  		{
  		    LCD_Enter_PB = 1;
  		    upd_dpy = 1;
			 if ((Password == fvars[fvpassword]) || (Password == 1927))		  // Leave the password display screen
			 {
			     PasswordFlag = true;
				 timers[tpassword] = 0;
				 ReturnLCDMenu();
			 }
			 else
		        mode_sel = 1;
			
			return (lcd_menu);
  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  		{
  		    LCD_Mode_PB = 1;  
			upd_dpy = 1;
			LCD_Dig_Point = set_adj_digit(9999,LCD_Dig_Point,0);			
  		}
  		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  		{
  		    LCD_UP_PB = 1;  // incriment
  		    upd_dpy = 1;
  		   	// increment fieldvar
			adjust_variable(&Password,9999,0,1,LCD_Dig_Point,0);
  		}
  		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  		{
  		    LCD_DN_PB = 1;  // decriment
  		    upd_dpy = 1;
  		   	// decrement fieldvar
		    adjust_variable(&Password,9999,0,0,LCD_Dig_Point,0);
  		}
  		 
	}

	if(mode_sel == 1)					  //Wrong Password Display
	{
    	for(i=0; i<=19; i++)
		{
	  		LCD_Display[0][i] = Password_dpy[0][i];
			LCD_Display[1][i] =	Password_dpy[1][i];
        }
   		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0)) //Go back to password screen
  		{
  		    LCD_Enter_PB = 1;					
			mode_sel = 0;
			clrLCDdpy();
			return (lcd_menu);

  		}
  		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0)) // leave password screen
  		{
  		    LCD_Mode_PB = 1;
  		    ReturnLCDMenu();	
			return (lcd_menu);
  		}
	}
	if(upd_dpy == 1)
	{
		upd_dpy = 0;
   		LCD_Dig_Loc = 12-LCD_Dig_Point;
		sprintf(&LCD_Display[1][9],"%04i",Password);
		LCD_Flash_TMP[0] = LCD_Display[1][LCD_Dig_Loc];
	}

	flash_digit(LCD_Flash_TMP[0], 1,LCD_Dig_Loc,(mode_sel == 0));

	return(lcd_menu);
}



// ************************************************
//  Display hoistway tables
// ************************************************

int16 display_hoistway(int16 lcd_menu)
{
	int16 i;
	float fl_dist;
	static int16 var_access;
	static int16 var_sel;
	int16 digit_start = 0;
	static int16 upd_dpy;
	static int16 fl;
	
	if(LCD_Sub_Init == 1)	// first time through Display hoistway tables
	{
		LCD_Sub_Init = 0;
		fl = cons[bottomf];
		upd_dpy = 1;
		var_access = 0;
		var_sel = 0;
		LCD_Dig_Point = 0;
	}
	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	{
	    LCD_UP_PB = 1;  // incriment
	    upd_dpy = 1;
		if (var_access == 0)
		{
			fl++;
			if (fl > cons[topf])
				fl = cons[bottomf];
		}
		else if (var_access == 1)
		{
			var_sel--;
			if (var_sel < 0)
				var_sel = 2;
		}
		else if (var_access == 2)
		{
			
			if (var_sel == 0)
			  	adjust_variable(&DPP_Fl_Dn_SD[fl],0x7fff,0,1,LCD_Dig_Point,0);
			else if (var_sel == 1)
			  	adjust_variable_32(&DPP_Floor_Pos[fl],0x7fffffff,0,1,LCD_Dig_Point);
			else if (var_sel == 2)
			  	adjust_variable(&DPP_Fl_Up_SD[fl],0x7fff,0,1,LCD_Dig_Point,0);
		}
	}
	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	{
	    LCD_DN_PB = 1;  // decriment
	    upd_dpy = 1;
		if (var_access == 0)
		{
			fl--;
			if (fl < cons[bottomf])
				fl = cons[topf];
	    }
	    else if (var_access == 1)
	    {
			var_sel++;
			if (var_sel > 2)
				var_sel = 0;
	    }
		else if (var_access == 2)
		{
			if (var_sel == 0)
			  	adjust_variable(&DPP_Fl_Dn_SD[fl],0x7fff,0,0,LCD_Dig_Point,0);
			else if (var_sel == 1)
			  	adjust_variable_32(&DPP_Floor_Pos[fl],0x7fffffff,0,0,LCD_Dig_Point);
			else if (var_sel == 2)
			  	adjust_variable(&DPP_Fl_Up_SD[fl],0x7fff,0,0,LCD_Dig_Point,0);
		}
	}

	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	{
	    LCD_Enter_PB = 1;
	    upd_dpy = 1;
		if (var_access == 0) 
		{						// 0 = no access, 1 = modify var
			if(PasswordFlag == false)
		   	{
		  		StoreLCDInfo();
				clrLCDdpy();
		  		LCD_Menu = 25;
		  		LCD_Init = 1;
				return(lcd_menu);
	   	   	}
			var_access = 1;
		}
		else if (var_access == 1)
		{
			if (((fl != cons[topf]) || (var_sel != 0)) && ((fl != cons[bottomf]) || (var_sel != 2)))
				var_access = 2;
		}
		else if (var_access > 1)	// save field new value entered
	    {
		  	Wrt_Hoistway();
			var_access = 1;
		  	LCD_Dig_Point = 0;
	    }
	}
	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	{
	    LCD_Mode_PB = 1;  //
		if (var_access == 0)
		{
			lcd_menu = 0;
			return(lcd_menu);
		}
		else if (var_access == 1)
		{
			upd_dpy = 1;
			var_access = 0;
		}
		else if (var_access == 2)
		{
			upd_dpy = 1;
			if (var_sel == 1)
	  			LCD_Dig_Point = set_adj_digit(0x7fffffff,LCD_Dig_Point,0);
			else 
	  			LCD_Dig_Point = set_adj_digit(0x7fff,LCD_Dig_Point,0);
		}
	}

	if(upd_dpy == 1)
	{
		upd_dpy = 0;
		fl_dist = 0;
		for(i=0; i<=19; i++)
		{
			LCD_Display[0][i] = LCD_Floor_SD[0][i];
			LCD_Display[1][i] = LCD_Floor_SD[1][i];
			LCD_Display[2][i] = LCD_Floor_SD[2][i];
			LCD_Display[3][i] = LCD_Floor_SD[3][i];
		}
	  
	  	itoa(fl,LCD_String);
		if(fl < 10)               
		  	LCD_Display[0][7] = LCD_String[0];    
		else
		{
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];
		}
	    
	  	// Down Slowdown
	  	
	  	if (fl == cons[topf])
	  	{
			LCD_Display[1][5] = '-';
			LCD_Display[1][6] = '-';
			LCD_Display[1][7] = '-';
	  	}
	  	else
	  	{
			if ((var_access > 1) && (var_sel == 0))
				sprintf(&LCD_Display[1][4],"%05i",DPP_Fl_Dn_SD[fl]);
			else
				sprintf(&LCD_Display[1][4],"%-5i",DPP_Fl_Dn_SD[fl]);
			LCD_Display[1][9] = ' ';
			
		   	fl_dist = (float)( (((float)DPP_Fl_Dn_SD[fl])/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[1][15],"%5.1f",fl_dist);
	  	}
	  	
		// floor position
		if ((var_access > 1) && (var_sel == 1))
			sprintf(&LCD_Display[2][4],"%09i",DPP_Floor_Pos[fl]);
		else
			sprintf(&LCD_Display[2][4],"%-9i",DPP_Floor_Pos[fl]);
		
	    LCD_Display[2][1] = flmrk[fl][0];//Put Display
	    LCD_Display[2][2] = flmrk[fl][1];// floor marking
		LCD_Display[2][13] = ' ';
	    
	   	fl_dist = (float)( (((float)(DPP_Floor_Pos[fl]-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
		sprintf(&LCD_Display[2][15],"%5.1f",fl_dist);

		// Up slodown
		if (fl == cons[bottomf])
		{
			LCD_Display[3][5] = '-';
			LCD_Display[3][6] = '-';
			LCD_Display[3][7] = '-';
		}
		else
		{
			if ((var_access > 1) && (var_sel == 2))
				sprintf(&LCD_Display[3][4],"%05i",DPP_Fl_Up_SD[fl]);
			else
				sprintf(&LCD_Display[3][4],"%-5i",DPP_Fl_Up_SD[fl]);
			LCD_Display[3][9] = ' ';
			
		   	fl_dist = (float)( (((float)DPP_Fl_Up_SD[fl])/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[3][15],"%5.1f",fl_dist);
		}

		if (var_access > 0)
		{
			if (var_sel == 0)
			{
				LCD_Display[1][3] = '>';
				digit_start = 8;
			}
			else if (var_sel == 1)
			{
				LCD_Display[2][3] = '>';
				digit_start = 12;
			}
			else if (var_sel == 2)
			{
				LCD_Display[3][3] = '>';
				digit_start = 8;
			}
			LCD_Dig_Loc = digit_start-LCD_Dig_Point;
	  		LCD_Flash_TMP[0] = LCD_Display[var_sel+1][LCD_Dig_Loc];
		}
	}
	if (var_access == 1)
		flash_digit('>', var_sel+1, 3, 1);
	else if (var_access == 2)
		flash_digit(LCD_Flash_TMP[0], var_sel+1, LCD_Dig_Loc, 1);

	return (lcd_menu);
}

// ************************************************
//  Display hoistway short floor slowdowns
// ************************************************

int16 display_short_floor_sd(int16 lcd_menu)
{
	int16 i;
	float fl_dist;
	static int16 var_access;
	static int16 var_sel;
	int16 digit_start = 0;
	static int16 upd_dpy;
	static int16 fl;
	
	if(LCD_Sub_Init == 1)	// first time through Display hoistway tables
	{
		LCD_Sub_Init = 0;
		fl = cons[bottomf];
		upd_dpy = 1;
		var_access = 0;
		var_sel = 0;
		LCD_Dig_Point = 0;
	}
	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	{
	    LCD_UP_PB = 1;  // incriment
	    upd_dpy = 1;
		if (var_access == 0)
		{
			fl++;
			if (fl > cons[topf])
				fl = cons[bottomf];
		}
		else if (var_access == 1)
		{
			var_sel--;
			if (var_sel < 0)
				var_sel = 2;
		}
		else if (var_access == 2)
		{
			
			if (var_sel == 0)
			  	adjust_variable(&DPP_SFl_Dn_SD[fl],0x7fff,0,1,LCD_Dig_Point,0);
			else if (var_sel == 1)
			  	adjust_variable_32(&DPP_Floor_Pos[fl],0x7fffffff,0,1,LCD_Dig_Point);
			else if (var_sel == 2)
			  	adjust_variable(&DPP_SFl_Up_SD[fl],0x7fff,0,1,LCD_Dig_Point,0);
		}
	}
	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	{
	    LCD_DN_PB = 1;  // decriment
	    upd_dpy = 1;
		if (var_access == 0)
		{
			fl--;
			if (fl < cons[bottomf])
				fl = cons[topf];
	    }
	    else if (var_access == 1)
	    {
			var_sel++;
			if (var_sel > 2)
				var_sel = 0;
	    }
		else if (var_access == 2)
		{
			if (var_sel == 0)
			  	adjust_variable(&DPP_SFl_Dn_SD[fl],0x7fff,0,0,LCD_Dig_Point,0);
			else if (var_sel == 1)
			  	adjust_variable_32(&DPP_Floor_Pos[fl],0x7fffffff,0,0,LCD_Dig_Point);
			else if (var_sel == 2)
			  	adjust_variable(&DPP_SFl_Up_SD[fl],0x7fff,0,0,LCD_Dig_Point,0);
		}
	}

	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	{
	    LCD_Enter_PB = 1;
	    upd_dpy = 1;
		if (var_access == 0) 
		{						// 0 = no access, 1 = modify var
			if(PasswordFlag == false)
		   	{
		  		StoreLCDInfo();
				clrLCDdpy();
		  		LCD_Menu = 25;
		  		LCD_Init = 1;
				return(lcd_menu);
	   	   	}
			var_access = 1;
		}
		else if (var_access == 1)
		{
			if (((fl == cons[topf]) && (var_sel != 0)) || ((fl == cons[bottomf]) && (var_sel != 2)))
				var_access = 2;
		}
		else if (var_access > 1)	// save field new value entered
	    {
		  	Wrt_Hoistway();
			var_access = 1;
		  	LCD_Dig_Point = 0;
	    }
	}
	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	{
	    LCD_Mode_PB = 1;  //
		if (var_access == 0)
		{
			lcd_menu = 0;
			return(lcd_menu);
		}
		else if (var_access == 1)
		{
			upd_dpy = 1;
			var_access = 0;
		}
		else if (var_access == 2)
		{
			upd_dpy = 1;
			if (var_sel == 1)
	  			LCD_Dig_Point = set_adj_digit(0x7fffffff,LCD_Dig_Point,0);
			else 
	  			LCD_Dig_Point = set_adj_digit(0x7fff,LCD_Dig_Point,0);
		}
	}

	if(upd_dpy == 1)
	{
		upd_dpy = 0;
		fl_dist = 0;
		for(i=0; i<=19; i++)
		{
			LCD_Display[0][i] = LCD_Short_Floor_SD[0][i];
			LCD_Display[1][i] = LCD_Short_Floor_SD[1][i];
			LCD_Display[2][i] = LCD_Short_Floor_SD[2][i];
			LCD_Display[3][i] = LCD_Short_Floor_SD[3][i];
		}
	  
	  	itoa(fl,LCD_String);
		if(fl < 10)               
		  	LCD_Display[0][7] = LCD_String[0];    
		else
		{
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];
		}
	    
	  	// Down slowdown count
	  	
	  	if (fl == cons[topf])
	  	{
			LCD_Display[1][5] = '-';
			LCD_Display[1][6] = '-';
			LCD_Display[1][7] = '-';
	  	}
	  	else
	  	{
			if ((var_access > 1) && (var_sel == 0))
				sprintf(&LCD_Display[1][4],"%05i",DPP_SFl_Dn_SD[fl]);
			else
				sprintf(&LCD_Display[1][4],"%-5i",DPP_SFl_Dn_SD[fl]);
			LCD_Display[1][9] = ' ';
			
		   	fl_dist = (float)( (((float)DPP_SFl_Dn_SD[fl])/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[1][15],"%5.1f",fl_dist);
	  	}
	  	
	  	
	  	// Floor position
		if ((var_access > 1) && (var_sel == 1))
			sprintf(&LCD_Display[2][4],"%09i",DPP_Floor_Pos[fl]);
		else
			sprintf(&LCD_Display[2][4],"%-9i",DPP_Floor_Pos[fl]);
		
	    LCD_Display[2][1] = flmrk[fl][0];//Put Display
	    LCD_Display[2][2] = flmrk[fl][1];// floor marking
		LCD_Display[2][13] = ' ';
	    
	   	fl_dist = (float)( (((float)(DPP_Floor_Pos[fl]-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
		sprintf(&LCD_Display[2][15],"%5.1f",fl_dist);


		// Up slodown count
		if (fl == cons[bottomf])
		{
			LCD_Display[3][5] = '-';
			LCD_Display[3][6] = '-';
			LCD_Display[3][7] = '-';
		}
		else
		{
			if ((var_access > 1) && (var_sel == 2))
				sprintf(&LCD_Display[3][4],"%05i",DPP_SFl_Up_SD[fl]);
			else
				sprintf(&LCD_Display[3][4],"%-5i",DPP_SFl_Up_SD[fl]);
			LCD_Display[3][9] = ' ';
			
		   	fl_dist = (float)( (((float)DPP_SFl_Up_SD[fl])/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[3][15],"%5.1f",fl_dist);
		}

		if (var_access > 0)
		{
			if (var_sel == 0)
			{
				LCD_Display[1][3] = '>';
				digit_start = 8;
			}
			else if (var_sel == 1)
			{
				LCD_Display[2][3] = '>';
				digit_start = 12;
			}
			else if (var_sel == 2)
			{
				LCD_Display[3][3] = '>';
				digit_start = 8;
			}
			LCD_Dig_Loc = digit_start-LCD_Dig_Point;
	  		LCD_Flash_TMP[0] = LCD_Display[var_sel+1][LCD_Dig_Loc];
		}
	}
	if (var_access == 1)
		flash_digit('>', var_sel+1, 3, 1);
	else if (var_access == 2)
		flash_digit(LCD_Flash_TMP[0], var_sel+1, LCD_Dig_Loc, 1);

	return (lcd_menu);
}

int16 dpy_aps_valid_fl_table(int16 lcd_menu)
{
	
	int16 i,j;
	static int16 upd_dpy;
	
	if (LCD_Sub_Init == 1)
	{		// first time through
		LCD_Sub_Init = 0;
  	    upd_dpy = 1;
		timers[tnts_aps_ui] = 0;
		NTS_spi.valid_fl_req = 1;
	}
	
 	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
  	{
  	    LCD_Enter_PB = 1;
  	    upd_dpy = 1;
  	}
  	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
  	{
  	    LCD_Mode_PB = 1;  //
		lcd_menu = 0;
		return(lcd_menu);
  	}
  	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
  	{
  	    LCD_UP_PB = 1;  // incriment
  	    upd_dpy = 1;
  	}
  	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
  	{
  	    LCD_DN_PB = 1;  // decriment
  	    upd_dpy = 1;
  	}

	if (timers[tnts_aps_ui] >= 3)		// request io status every 300 msec
	{
		NTS_spi.valid_fl_req = 1;
		timers[tnts_aps_ui] = 0;
	}
	
	if ((upd_dpy == 1) || (NTS_spi.valid_fl_rcvd == 1))
	{
		upd_dpy = 0;
		if (NTS_spi.valid_fl_rcvd == 1)
			NTS_spi.valid_fl_rcvd = 0;
		
		for(i=0; i<=19; i++)
		{
		    LCD_Display[0][i] = LCD_aps_valid_fl_tbl[0][i];
			LCD_Display[1][i] = LCD_aps_valid_fl_tbl[1][i];
		    LCD_Display[2][i] = LCD_aps_valid_fl_tbl[2][i];
			LCD_Display[3][i] = LCD_aps_valid_fl_tbl[3][i];
		}
		j=16;
		for (i=4; i<=19; i++)
		{
			if ((NTS_spi.valid_fl_tbl  & fl_mask[j]) != 0)
				LCD_Display[1][i] = '1';  // tables
			if ((NTS_spi.valid_clip_tbl  & fl_mask[j]) != 0)
				LCD_Display[3][i] = '1';  // tables
			j--;
		}
	}
	return (lcd_menu);
}



//*****************************************************
// Display cpu nts limits
//*****************************************************

int16 display_cpu_limits(int16 lcd_menu)
{
	int16 i;
	int16 fl = 1;
	float fl_dist;
	static int16 upd_dpy;
	static int16 hw_sel;

	if(LCD_Sub_Init == 1)	// first time through Display cpu limits
	{
		LCD_Sub_Init = 0;
		upd_dpy = 1;
		hw_sel = 0;
	}
	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	{
	    LCD_UP_PB = 1;  // incriment
	    upd_dpy = 1;
		hw_sel++;
		if (hw_sel > 1)
			hw_sel = 0;
	}
	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	{
	    LCD_DN_PB = 1;  // decriment
	    upd_dpy = 1;
		hw_sel--;
		if (hw_sel < 0)
			hw_sel = 1;
	}

	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	{
	    LCD_Enter_PB = 1;
	    upd_dpy = 1;
	}
	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	{
	    LCD_Mode_PB = 1;  //
		lcd_menu = 0;
		return(lcd_menu);
	}

	if(upd_dpy == 1)
	{
		upd_dpy = 0;
		fl_dist = 0;
		for(i=0; i<=19; i++)
		{
			LCD_Display[0][i] = LCD_Term_Limits[0][i];
			if (hw_sel == 1)
			{
				LCD_Display[1][i] = LCD_Term_Limits[1][i];
				LCD_Display[2][i] = LCD_Term_Limits[2][i];
				LCD_Display[3][i] = LCD_Term_Limits[3][i];
			}
			else
			{
				LCD_Display[1][i] = LCD_Term_Limits[4][i];
				LCD_Display[2][i] = LCD_Term_Limits[5][i];
				LCD_Display[3][i] = LCD_Term_Limits[6][i];
			}
		}

	    
		if (hw_sel == 1)
		{
			sprintf(&LCD_Display[1][4],"%-9i",DPP_UN);
			LCD_Display[1][13] = ' ';
			
		   	fl_dist = (float)( (((float)(DPP_UN-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[1][15],"%5.1f",fl_dist);
		}
		else
		{
			sprintf(&LCD_Display[1][4],"%-9i",DPP_DT);
			LCD_Display[1][13] = ' ';
			
		   	fl_dist = (float)( (((float)(DPP_DT-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[1][15],"%5.1f",fl_dist);
		}

		if (hw_sel == 0)
			fl = cons[bottomf];
		else
			fl = cons[topf];
		
		sprintf(&LCD_Display[2][4],"%-9i",DPP_Floor_Pos[fl]);
		
	    LCD_Display[2][1] = flmrk[fl][0];//Put Display
	    LCD_Display[2][2] = flmrk[fl][1];// floor marking
		LCD_Display[2][13] = ' ';
	    
	   	fl_dist = (float)( (((float)(DPP_Floor_Pos[fl]-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
		sprintf(&LCD_Display[2][15],"%5.1f",fl_dist);



		if (hw_sel == 1)
		{
			sprintf(&LCD_Display[3][4],"%-9i",DPP_UT);
			LCD_Display[3][13] = ' ';
			
		   	fl_dist = (float)( (((float)(DPP_UT-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[3][15],"%5.1f",fl_dist);
		}
		else
		{
			sprintf(&LCD_Display[3][4],"%-9i",DPP_DN);
			LCD_Display[3][13] = ' ';
			
		   	fl_dist = (float)( (((float)(DPP_DN-DPP_Floor_Pos[cons[bottomf]]))/(float)Pulses_per_Inch)/12.0);
			sprintf(&LCD_Display[3][15],"%5.1f",fl_dist);
		}

	}
	return (lcd_menu);
}


// **************************************************
// Display Doorzone, Level zone and Selector Count
// **************************************************

int16 display_dz_off(int16 lcd_menu)
{
	int16 i;
	int16 fl = 1;
	float fl_dist;
	static int16 var_access;
	static int16 var_sel;
	int16 digit_start = 0;
	static int16 upd_dpy;
	static int16 hw_sel;
	int16 max_offset = 0;

	if(LCD_Sub_Init == 1)	// first time through Display cpu limits
	{
		LCD_Sub_Init = 0;
		upd_dpy = 1;
		var_access = 0;
		var_sel = 0;
		LCD_Dig_Point = 0;
	}
	if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
	{
	    LCD_UP_PB = 1;  // incriment
	    upd_dpy = 1;
		if (var_access == 1)
		{
			var_sel--;
			if (var_sel < 0)
				var_sel = 1;
		}
		else if (var_access == 2)
		{
			max_offset = (int16)(Pulses_per_Inch);
			if (var_sel == 0)
			  	adjust_variable(&Dn_fl_level_dist,max_offset,0,1,LCD_Dig_Point,0);
			else if (var_sel == 1)
			  	adjust_variable(&Up_fl_level_dist,max_offset,0,1,LCD_Dig_Point,0);
		}
	}
	if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
	{
	    LCD_DN_PB = 1;  // decriment
	    upd_dpy = 1;
		if (var_access == 1)
	    {
			var_sel++;
			if (var_sel > 1)
				var_sel = 0;
	    }
		else if (var_access == 2)
		{
			max_offset = (int16)(Pulses_per_Inch);
			if (var_sel == 0)
			  	adjust_variable(&Dn_fl_level_dist,max_offset,0,0,LCD_Dig_Point,0);
			else if (var_sel == 1)
			  	adjust_variable(&Up_fl_level_dist,max_offset,0,0,LCD_Dig_Point,0);
		}
	}

	if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
	{
	    LCD_Enter_PB = 1;
	    upd_dpy = 1;
		if (var_access == 0) 
		{						// 0 = no access, 1 = modify var
			if(PasswordFlag == false)
		   	{
		  		StoreLCDInfo();
				clrLCDdpy();
		  		LCD_Menu = 25;
		  		LCD_Init = 1;
				return(lcd_menu);
	   	   	}
			var_access = 1;
		}
		else if (var_access == 1)
		{
			var_access = 2;
		}
		else if (var_access > 1)	// save field new value entered
	    {
		  	Wrt_Hoistway();
			var_access = 1;
		  	LCD_Dig_Point = 0;
	    }
	}
	if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
	{
	    LCD_Mode_PB = 1;  //
		if (var_access == 0)
		{
			lcd_menu = 0;
			return(lcd_menu);
		}
		else if (var_access == 1)
		{
			upd_dpy = 1;
			var_access = 0;
		}
		else if (var_access == 2)
		{
			upd_dpy = 1;
  			LCD_Dig_Point = set_adj_digit(0x7fff,LCD_Dig_Point,0);
		}
	}

	if(upd_dpy == 1)
	{
		upd_dpy = 0;
		fl_dist = 0;
		for(i=0; i<=19; i++)
		{
			LCD_Display[0][i] = LCD_lev_dist[0][i];	 //  Header
			LCD_Display[1][i] = LCD_lev_dist[1][i];  //  Dn level distance
			LCD_Display[2][i] = LCD_lev_dist[2][i];  //  Up level distance
			LCD_Display[3][i] = LCD_lev_dist[3][i];  //  Pulses per inch
		}

	    

		if ((var_access > 1) && (var_sel == 0))
			sprintf(&LCD_Display[1][11],"%05i",Dn_fl_level_dist);
		else
			sprintf(&LCD_Display[1][11],"%-5i",Dn_fl_level_dist);
		LCD_Display[1][16] = ' ';
			
		if ((var_access > 1) && (var_sel == 1))
			sprintf(&LCD_Display[2][11],"%05i",Up_fl_level_dist);
		else
			sprintf(&LCD_Display[2][11],"%-5i",Up_fl_level_dist);
		LCD_Display[2][16] = ' ';
			
		sprintf(&LCD_Display[3][6],"%5.1f",Pulses_per_Inch);
		LCD_Display[3][11] = ' ';



		if (var_access > 0)
		{
			if (var_sel == 0)
			{
				LCD_Display[1][9] = '>';
				digit_start = 15;
			}
			else if (var_sel == 1)
			{
				LCD_Display[2][9] = '>';
				digit_start = 15;
			}
			LCD_Dig_Loc = digit_start-LCD_Dig_Point;
	  		LCD_Flash_TMP[0] = LCD_Display[var_sel+1][LCD_Dig_Loc];
		}
	}
	if (var_access == 1)
		flash_digit('>', var_sel+1, 9, 1);
	else if (var_access == 2)
		flash_digit(LCD_Flash_TMP[0], var_sel+1, LCD_Dig_Loc, 1);

	return (lcd_menu);
}

static  const char LCD_bit_tbl_dpy[2][25]={
      "  16....... 8......1",
      "   00000000 00000000",
};

//********************************
// Display variable 
//********************************

void display_variable(int16 row, int16 col, int16 digit, int16 lcd_par, int16 flash)
{							// display data
	char next_char;
	int16 digit_adjust = 0;
	int16 i,j;

	if ((digit & 0x80) != 0)
	{
		next_char = LCD_Display[row+1][col+6];
		for(i=0; i<=19; i++)
		{
			LCD_Display[2][i] = LCD_bit_tbl_dpy[1][i];	 //  Zero's
			
		}
		
		j = 15;
		for (i=3; i<=19; i++)
		{
			if (i == 11)
				i++;
			if ((lcd_par  & bittbl[j]) != 0)
				LCD_Display[2][i] = '1';  // bit is set
			j--;
		}
		
		sprintf(&LCD_Display[row+1][col],"%06i",lcd_par);

		LCD_Display[row+1][col+6] = next_char;

		if (LCD_Dig_Point > 7)
			digit_adjust = 1;
		
		if (flash == 1)
		{
			LCD_Dig_Loc = (col + 5) - (LCD_Dig_Point + digit_adjust);
	  		LCD_Flash_TMP[row] = LCD_Display[row][LCD_Dig_Loc];
		}
	}
	else
	{
		if (digit > 3)
			digit = 0;

		next_char = LCD_Display[row][col+6];
		if (digit == 1)
		{
			if (LCD_Dig_Point > 0)
				digit_adjust = 1;
			sprintf(&LCD_Display[row][col],"%04i.%01i",lcd_par/10,lcd_par%10);
		}
		else if (digit == 2)
		{
			if (LCD_Dig_Point > 1)
				digit_adjust = 1;
			sprintf(&LCD_Display[row][col],"%03i.%02i",lcd_par/100,lcd_par%100);
		}
		else if (digit == 3)
		{
			if (LCD_Dig_Point > 2)
				digit_adjust = 1;
			sprintf(&LCD_Display[row][col],"%02i.%03i",lcd_par/1000,lcd_par%1000);
		}
		else
			sprintf(&LCD_Display[row][col],"%06i",lcd_par);

		LCD_Display[row][col+6] = next_char;

		if (flash == 1)
		{
			LCD_Dig_Loc = (col + 5) - (LCD_Dig_Point + digit_adjust);
	  		LCD_Flash_TMP[row] = LCD_Display[row][LCD_Dig_Loc];
		}
	}
}
//********************************
// Display variable  11 digits
//********************************

void display_variable_11_digits(int16 row, int16 col, int16 digit, int32 lcd_par, int16 flash)
{							// display data
	char next_char;
	int16 digit_adjust = 0;

		
	if (digit > 3)
		digit = 0;

	next_char = LCD_Display[row][col+11];
	if (digit == 1)
	{
		if (LCD_Dig_Point > 0)
			digit_adjust = 1;
		sprintf(&LCD_Display[row][col],"%09i.%01i",lcd_par/10,lcd_par%10);
	}
	else if (digit == 2)
	{
		if (LCD_Dig_Point > 1)
			digit_adjust = 1;
		sprintf(&LCD_Display[row][col],"%08i.%02i",lcd_par/100,lcd_par%100);
	}
	else if (digit == 3)
	{
		if (LCD_Dig_Point > 2)
			digit_adjust = 1;
		sprintf(&LCD_Display[row][col],"%07i.%03i",lcd_par/1000,lcd_par%1000);
	}
	else
		sprintf(&LCD_Display[row][col],"%011i",lcd_par);

	LCD_Display[row][col+11] = next_char;

	if (flash == 1)
	{
		LCD_Dig_Loc = (col + 10) - (LCD_Dig_Point + digit_adjust);
  		LCD_Flash_TMP[row] = LCD_Display[row][LCD_Dig_Loc];
	}
}



//***********************************
// Adjust field adjustable variable
//***********************************

const int16 adj_amt[10] = {1,10,100,1000,10000,-1,-1,-1,-1,-1};

void adjust_variable (int16 *pvar, int16 max, int16 min, int16 inc, int16 digit, int16 deci)
{
	if ((deci & 0x0080) != 0)
	{
		if (inc == 1)		// Increment variable
		{
			if ((*pvar & bittbl[digit]) == 0)
				*pvar += bittbl[digit];
		}
		else
		{
			if ((*pvar & bittbl[digit]) != 0)
				*pvar -= bittbl[digit];
		}
		if (*pvar > max)
			*pvar = max;
	}
	else
	{

		if (digit > 5)
			digit = 0;

		if (inc == 1)		// Increment variable
			*pvar += adj_amt[digit];
		else
			*pvar -= adj_amt[digit];

		if (*pvar > max)
			*pvar = max;
		else if ((min >= 0) && (*pvar < 0)) 
			*pvar = min;
		else if (*pvar < min)
			*pvar = min;
	}
}

//***********************************
// Adjust field adjustable variable
//***********************************

const int32 adj_amt_32[10] = {1,10,100,1000,10000,100000,1000000,10000000,100000000,1000000000};

void adjust_variable_32 (int32 *pvar, int32 max, int32 min, int32 inc, int16 digit)
{

	if (digit > 9)
		digit = 0;

	if (inc == 1)		// Increment variable
		*pvar += adj_amt_32[digit];
	else
		*pvar -= adj_amt_32[digit];

	if (*pvar > max)
		*pvar = max;
	else if ((min >= 0) && (*pvar < 0)) 
		*pvar = min;
	else if (*pvar < min)
		*pvar = min;
}

//********************************************
// Set the digit to alter adjustable variable
//********************************************

int16 set_adj_digit (int32 max,int16 digit,int16 num_digits)
{
	int32 tmax;

	if ((num_digits & 0x0080) != 0)
	{
		digit++;
		if (digit >= (int16)(num_digits & 0x007F))
			digit = 0;
	}
	else
	{
		

		digit++;
		if (digit > 9)
			digit = 0;

		if (max == -1)
			tmax = cons[nmbcars];
		else if (max == -2)
			tmax = cons[grtopf];
		else if (max == -3)
			tmax = cons[speed];
		else
			tmax = max;

		if ((uint16)adj_amt_32[digit] > (uint16)tmax)
			digit = 0;
	}
	return digit;
}


//***********************************
// Flash digit being adjusted
//***********************************

void flash_digit (char dchar, int16 row, int16 col, int16 enable)
{
	if (enable == 1)
	{
		if(LCD_Flash != 0)
			LCD_Display[row][col] = dchar;
		else
			LCD_Display[row][col] = ' ';
	}
}


//******************************************
// Display Variable Label instead of number
//******************************************

// Car Push Button Options Menu 10
/*
  CC Button On Color				275 C 	0
  CC Button Off Color				276 C 	5
  CC Button Security Color			286 C 	10
  Car Call Button Att Up Color		320 C 	15
  Car Call Button Att Dn Color		325 C 	20
  Fire light Color					330 C 	26
  Medical light Color				335 C 	31
  Emergency light Color				340 C 	36
  OTS light Color					345 C 	41
  Backlight Output lights  			350 C 	46

// Hall Push Button Options	Menu 11

  HCB On Color 	   					264 G 	0 
  HCB Off Color 	   				265 G 	5 
  HCB Sec Color	   					266 G 	10
  HCB Sec Lt 		   				267 G  	15
},
*/

void Display_Var_Label(int16 menu, int16 fv_index, int16 var)
{
	int16 i;
	
	if ( (menu == Color_Lights_Menu) && ( (fv_index == fvcconcolor) || (fv_index == fvccoffcolor) || (fv_index == fvccseccolor) || (fv_index == fvccattupcolor) || (fv_index == fvccattdncolor) ||
			(fv_index == fvcopfirecolor) || (fv_index == fvcopmedcolor) || (fv_index == fvcopemcolor)	|| (fv_index == fvcopotscolor) ||
		    (fv_index == fvhcbuponcolor) || (fv_index == fvhcbupoffcolor) || (fv_index == fvhcbdnoncolor) || (fv_index == fvhcbdnoffcolor) || (fv_index == fvhcbiruponcolor) || 
			(fv_index == fvhcbirupoffcolor)|| (fv_index == fvhcbirdnoncolor) || (fv_index == fvhcbirdnoffcolor) ||
		    (fv_index == fvhcbcboncolor) || (fv_index == fvhcbcboffcolor) || (fv_index == fvhcbviponcolor) || (fv_index == fvhcbvipoffcolor)|| (fv_index == fvhcbseccolor) ) )
	{
	    for(i=0; i<=19; i++)
        {
	    	LCD_Display[1][i] =  LCD_Var_Labels[var][i];
	    }
	}
	else if ((menu == Color_Lights_Menu) && (fv_index == fvbklton))
	{		// Backlight Output lights
	    for(i=0; i<=19; i++)
  	    {
	    	LCD_Display[1][i] =  LCD_Backlight_Output[var][i];
	    }
	}
	else if ((menu == Color_Lights_Menu) && (fv_index == fvhcbseclt))
	{ 	// HCB Sec Lt
	    for(i=0; i<=19; i++)
  	    {
	    	LCD_Display[1][i] =  LCD_Button_Sec_Light[var][i];
	    }
	}
	else if((menu == System_Options_Menu) && ((fv_index >= fvexcflt1) && (fv_index <= fvexcflt6)))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = LCD_Fault[var][i];
	    }
	}
	else if ((menu == System_Options_Menu) && 
		((fv_index == fvbaud) || (fv_index == fvbaud2) || (fv_index == fvbaud3) || (fv_index == fvhlbaud) ))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = Baud_Display[var][i];
	    }
	}
	else if((menu == System_Options_Menu) && ((fv_index == fvcomdiag1) || (fv_index == fvcomdiag2)) )
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = Com_Sel_Display[var][i];
	    }
	}
	else if ((menu == Service_Options_Menu) && ((fv_index == fvservoctrl) || (fv_index == fvsvcmsg1) || (fv_index == fvsvcmsg2) || (fv_index == fvsvcmsg3)))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = LCD_Servf[var][i];
	    }
	}
	else if ((menu == Group_Options_Menu) && (fv_index == fvxasgn))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = Xassign_Display[var][i];
	    }
	}
	else if ((menu == Emergency_Service_Menu) && (fv_index == fvfiresw))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = Fire_SW_Display[var][i];
	    }
	}
	else if ((menu == Emergency_Service_Menu) && (fv_index == fvfire_rst))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = Fire_RST_Display[var][i];
	    }
	}
	else if ((menu == Car_Options_Menu)  && (fv_index == fviser))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = ISER_Display[var][i];
	    }
	}
	else if ((menu == Group_Options_Menu) && (fv_index == fvirctl))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = IR_CTL_Display[var][i];
	    }
	}
	else if ((menu == Emergency_Service_Menu) && (fv_index == fvfsofl))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = FSO_Display[var][i];
	    }
	}
	else if ((menu == Car_Options_Menu) && (fv_index == fvrmcc))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = RMCC_Display[var][i];
	    }
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvsecrec))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = SEC_RCL_Display[LCD_Dig_Point][i];
	    }
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvdobsec))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = DOB_SEC_Display[var][i];
	    }
	}
	else if ((menu == Group_Options_Menu) && (fv_index == fvepopled))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = OP_LED_Display[var][i];
	    }
	}
	else if ((menu == Group_Options_Menu) && (fv_index == fveppkled))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = PK_LED_Display[var][i];
	    }
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvheloff))
	{
	    for(i=0; i<=19; i++)
		{
			LCD_Display[1][i] = HEOF_Display[LCD_Dig_Point][i];
	    }
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvsecrec2))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = SEC_RCL_2_Display[var][i];
	    }
	}
	else if ((menu == Car_Options_Menu) && (fv_index == fvopenlctl))
	{
	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = OPENL_Display[LCD_Dig_Point][i];
	    }
	}
	else if ((menu == Car_Options_Menu) && (fv_index == fvoser1))
	{

	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = OSER_CTL_Display[LCD_Dig_Point][i];
	    }
	    
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvsabben))
	{

	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = SABB_EN_Display[LCD_Dig_Point][i];
	    }
	    
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvceloff))
	{

	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = ELEV_OFF_Display[LCD_Dig_Point][i];
	    }
	    
	}
	else if ((menu == Service_Options_Menu) && (fv_index == fvceloff2))
	{

	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = ELEV_OFF_2_Display[LCD_Dig_Point][i];
	    }
	    
	}
	else if ((menu == Car_Options_Menu) && (fv_index == fvrmccd))
	{

	    for(i=0; i<=19; i++)
  	    {
			LCD_Display[1][i] = RMCC_DIS_Display[LCD_Dig_Point][i];
	    }
	    
	}
	
}



//*************************************
//** Elevator Status Initialization ***
//*************************************

void Elevator_Status_Init (int16 Init_Flag)
{
	int16 i,j;
	static int16 upd_dpy;

	if(Init_Flag == 0)
	{		// Elevator Graphics display
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = ' ';  
		   	LCD_Display[1][i] = ' ';
		   	LCD_Display[2][i] = ' ';
		   	LCD_Display[3][i] = ' ';
	    }
	}
	else if (Init_Flag == 1)
	{		// Elevator Service Display		   
	    upd_dpy = 1;	 // Update PI
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = ' ';  
		   	LCD_Display[1][i] = ' ';
		   	LCD_Display[2][i] = ' ';
		   	LCD_Display[3][i] = ' ';
	    }
	}
	else if (Init_Flag == 2)
	{		// NTS Status
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_NTS_Status[0][i];
			LCD_Display[1][i] = LCD_NTS_Status[1][i];
			LCD_Display[2][i] = LCD_NTS_Status[2][i];
			LCD_Display[3][i] = LCD_NTS_Status[3][i];
		}
	}
	else if ((Init_Flag >= 3) && (Init_Flag <= 10))
	{	// IO Display
		j = (Init_Flag - 3) * 12;

		display_io_name(j);
	}
	else if (Init_Flag == 11)
	{					//  Chk Run State, Start State, Leveling State, door state
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Detail_Fault[32][i];  
		   	LCD_Display[1][i] = LCD_Detail_Fault[33][i];
			LCD_Display[2][i] = LCD_Detail_Fault[34][i];  
		   	LCD_Display[3][i] = LCD_Detail_Fault[35][i];
	    }
	}
	else if (Init_Flag == 12)
	{					//  Up Accel Rate, Up Decel Rate, Dn Accel Rate, Dn Decel Rate
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Detail_Fault[36][i];  
		   	LCD_Display[1][i] = LCD_Detail_Fault[37][i];
			LCD_Display[2][i] = LCD_Detail_Fault[38][i];  
		   	LCD_Display[3][i] = LCD_Detail_Fault[39][i];
	    }
	}
	else if (Init_Flag == 13)
	{
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Dbg_Status[0][i];
			LCD_Display[1][i] = LCD_Dbg_Status[1][i];
			LCD_Display[2][i] = LCD_Dbg_Status[2][i];
			LCD_Display[3][i] = LCD_Dbg_Status[3][i];
		}
	}
	else if (Init_Flag == 14)
	{
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Dbg_Status2[0][i];
			LCD_Display[1][i] = LCD_Dbg_Status2[1][i];
			LCD_Display[2][i] = LCD_Dbg_Status2[2][i];
			LCD_Display[3][i] = LCD_Dbg_Status2[3][i];
		}
	}
/*	
	else if (Init_Flag == 9)
	{
	    upd_dpy = 1;	 // Run  Screen
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Run_Status[0][i];
			LCD_Display[1][i] = LCD_Run_Status[1][i];
		}
	}
	else if (Init_Flag == 10)
	{					  // Fire status
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Fire_dpy_Status[0][i];
			LCD_Display[1][i] = LCD_Fire_dpy_Status[1][i];
		}
	}
	else if (Init_Flag == 11)
	{
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Run_Time[0][i];
			LCD_Display[1][i] = LCD_Run_Time[1][i];
		}
	}
	else if (Init_Flag == 14)
	{
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Voltage[0][i];
			LCD_Display[1][i] = LCD_Voltage[1][i];
		}
	}
	else if (Init_Flag == 23)
	{					// Fault bits
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Detail_Fault[30][i];  
		   	LCD_Display[1][i] = LCD_Detail_Fault[31][i];
	    }
	}
	else if (Init_Flag == 24)
	{					// Nudging status, Door Request, Call Flags, Chk Run State, Start State, Leveling State
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Detail_Fault[38][i];  
		   	LCD_Display[1][i] = LCD_Detail_Fault[39][i];
	    }
	}
	else if (Init_Flag == 25)
	{					// Check door status, front slowdown, rear slowdown and motion timer.
	    for(i=0; i<=19; i++)
	    {
			LCD_Display[0][i] = LCD_Detail_Fault[40][i];  
		   	LCD_Display[1][i] = LCD_Detail_Fault[41][i];
	    }
	}
	*/
}

void display_io_name (int16 ioloc)
{
	int16 i,j,k,m;
	
	/*		Example:
		  "xxxAD.|xL120.|xxxTF.",	// 0
		  "xxIND.|xxS10.|xxxBF.",	// 1
		  "xxLBP.|     .|xxxPS.",	// 2
		  "xxGBP.|xxGOV.|xxHSS.",	// 3
	*/		
		
    for(i=0; i<=19; i++)
    {
    	LCD_Display[0][i] = LCD_Dpy_IO_Row[i];
		LCD_Display[1][i] = LCD_Dpy_IO_Row[i];
	  	LCD_Display[2][i] = LCD_Dpy_IO_Row[i];
	    LCD_Display[3][i] = LCD_Dpy_IO_Row[i];
    }

    for(i=0; i<=2; i++)
    {
	    k = (i * 7);
	    m = i * 4;
		for (j=0;j<=4;j++)
		{
			LCD_Display[0][k + j] = ioname[ioloc+m][j];
			LCD_Display[1][k + j] = ioname[ioloc+m+1][j];
			LCD_Display[2][k + j] = ioname[ioloc+m+2][j];
			LCD_Display[3][k + j] = ioname[ioloc+m+3][j];
    	}
    }
	if ((io_valid[(ioloc+m)/8] & bittbl[(ioloc+m) & 0x7]) != 0)
	{
		LCD_Display[0][k + 5] = io_off;
	}
	if ((io_valid[(ioloc+m+1)/8] & bittbl[(ioloc+m+1) & 0x7]) != 0)
	{
		LCD_Display[1][k + 5] = io_off;
	}
	if ((io_valid[(ioloc+m+2)/8] & bittbl[(ioloc+m+2) & 0x7]) != 0)
	{
		LCD_Display[2][k + 5] = io_off;
	}
	if ((io_valid[(ioloc+m+3)/8] & bittbl[(ioloc+m+3) & 0x7]) != 0)
	{
		LCD_Display[3][k + 5] = io_off;
	}
}
	
static int16 const io_row[12] = {0,1,2,3,0,1,2,3,0,1,2,3};
static int16 const io_col[12] = {5,5,5,5,12,12,12,12,19,19,19,19};
	
void display_io_value (int16 ioloc, struct Fault *ptr)
{
	int16 i,k;
  	for (i=0;i<=11;i++)
  	{
		k = (ioloc+i)/8;
		if ((io_valid[k] & bittbl[(ioloc+i) & 0x7]) != 0) 
		{		 // valid i/o
			if((ptr->iodata[k] & bittbl[(ioloc+i) & 0x7]) != 0)
			{
			    if((IO_In_Out[k] & bittbl[(ioloc+i) & 0x7]) != 0)	// it is an output off
					LCD_Display[io_row[i]][io_col[i]] = io_off;
			    else										// it is an input  on
					LCD_Display[io_row[i]][io_col[i]] = io_on;
			}
	 		else
			{
			    if((IO_In_Out[k] & bittbl[(ioloc+i) & 0x7]) != 0)	// it is an output on
					LCD_Display[io_row[i]][io_col[i]] = io_on;
	  	  	  	else										// it is an input off
					LCD_Display[io_row[i]][io_col[i]] = io_off;
			}
		}
  	}
}

//***********************************************
//******     Elevator Service    *****************
//***********************************************

void Elevator_Service (struct Fault *ptr)
{
	int16 i,j;
	static int16 upd_dpy;

	// Service on line 1

	if ((ptr->servf == s_INSP) && (ptr->procf == 2))
	{					  // on inspection 
		for(i=0; i<=19; i++)
		{
		    LCD_Display[0][i] = LCD_Ins_Servf[ptr->ins_servf][i];
		}
	}
	else if ((ptr->servf == s_FIRE2) || (ptr->servf == s_F1MAIN) || (ptr->servf == s_F1ALT))
	{		// on fire service
		for(i=0; i<=19; i++)
		{
		    LCD_Display[0][i] = LCD_Fire_status[ptr->firef][i];
		}
	}
	else
   	{
		for(i=0; i<=19; i++)
		{
		    LCD_Display[0][i] = LCD_Servf[ptr->servf][i];
		}
   	}

	// Elevator process line 2
    for(i=0; i<=19; i++)
    {
		LCD_Display[1][i] = LCD_Procf[ptr->procf][i];
    }
    upd_dpy = 1;

	// Elevator Door Line 3

	if ((ptr->doorf != 0) || ((cons[rear] == 1) && (ptr->rdoorf != 0)))
  	{
  		if (ptr->doorf != 0)
  		{
	  	    for(i=0; i<=19; i++)
	  	    {
				if ((ptr->servf == s_AUTO) && (ptr->doorf == 2))
					LCD_Display[2][i] = LCD_Door_dwell[0][i];
				else
				   	LCD_Display[2][i] = LCD_Doorf[ptr->doorf][i];
		  	}
	      	upd_dpy = 1;
	  	}
	  	else 
	  	{
			for(i=0; i<=19; i++)
			{
				if ((ptr->servf == s_AUTO) && (ptr->rdoorf == 2))
					LCD_Display[2][i] = LCD_Door_dwell[1][i];
				else
					LCD_Display[2][i] = LCD_Rdoorf[ptr->rdoorf][i];
		    }
	  	    upd_dpy = 1;
	  	}
	}
	else 
	{		// doorf == 0 the check limits

		if (cons[rear] == 0) 
		{
			for(i=0; i<=19; i++)
			{
				if (rdinp_fm(i_GS,ptr) == 1)
					LCD_Display[2][i] = LCD_Doorf[0][i];
				else if ((ptr->run_statusf & rs_DOL) == 0)
				   	LCD_Display[2][i] = LCD_Doorf[2][i];
				else 
				   	LCD_Display[2][i] = LCD_Doorf[5][i];
		    }
		}
		else 
		{
			for(i=0; i<=19; i++)
			{
				if ((rdinp_fm(i_RGS,ptr) == 1) && (rdinp_fm(i_GS,ptr) == 1))
					LCD_Display[2][i] = LCD_Doorf[0][i];
				else if ((rdinp_fm(i_RGS,ptr) == 0) && (rdinp_fm(i_GS,ptr) == 1))
				{
					if ((ptr->run_statusf & rs_DOLR) == 0)
					   	LCD_Display[2][i] = LCD_Rdoorf[2][i];
					else 
					   	LCD_Display[2][i] = LCD_Rdoorf[5][i];
				}
				else if ((rdinp_fm(i_RGS,ptr) == 1) && (rdinp_fm(i_GS,ptr) == 0))
				{
					if ((ptr->run_statusf & rs_DOL) == 0)
					   	LCD_Display[2][i] = LCD_Doorf[2][i];
					else 
					   	LCD_Display[2][i] = LCD_Doorf[5][i];
				}
				else 
				{
					if ((ptr->run_statusf & rs_DOL) == 0)
					   	LCD_Display[2][i] = LCD_Doorf[2][i];
					else if ((ptr->run_statusf & rs_DOLR) == 0)
					   	LCD_Display[2][i] = LCD_Rdoorf[2][i];
					else 
					   	LCD_Display[2][i] = LCD_Doorf[5][i];
				}
			}
		}
	}				
	

	// Status Flag Line 4
	
	if ((ptr->statusf != 0) || (ptr->statusf2 != 0) || (ptr->statusf3 != 0) || (ptr->statusf4 != 0))
	{

	  	if (((ptr->statusf & sf_SS) != 0) && (ptr->ss_status != 0))
	  	{
			j = 0;
			while (j<=15)
			{
			    if ((ptr->ss_status  & bittbl[j++]) != 0)
			    	break;
			}
	  	    for(i=0; i<=19; i++)
	  	    {
				LCD_Display[3][i] = LCD_SS_Status[j][i];
	  	    }
	  	}
	  	else if (ptr->statusf != 0)
	  	{
			j = 0;
			while (j<=31)
			{
		      	if ((ptr->statusf & l_bit_mask[j++]) != 0)
			    	break;
			}
	  	    for(i=0; i<=19; i++)
	  	    {
				LCD_Display[3][i] = LCD_Statusf[j][i];
	  	    }
	  	}
	  	else if (ptr->statusf2 != 0)
	  	{
			j = 0;
			while (j<=31)
			{
		      	if ((ptr->statusf2 & l_bit_mask[j++]) != 0)
			    	break;
			}
	  	    for(i=0; i<=19; i++)
	  	    {
				LCD_Display[3][i] = LCD_Statusf2[j][i];
	  	    }
	  	}
	  	else if (ptr->statusf3 != 0)
	  	{
			j = 0;
			while (j<=31)
			{
		      	if ((ptr->statusf3 & l_bit_mask[j++]) != 0)
			    	break;
			}
	  	    for(i=0; i<=19; i++)
	  	    {
				LCD_Display[3][i] = LCD_Statusf3[j][i];
	  	    }
	  	}
	  	else
	  	{
			j = 0;
			while (j<=31)
			{
		      	if ((ptr->statusf4 & l_bit_mask[j++]) != 0)
			    	break;
			}
	  	    for(i=0; i<=19; i++)
	  	    {
				LCD_Display[3][i] = LCD_Statusf4[j][i];
	  	    }
	  	}
	}
	else 
	{
	  for(i=0; i<=19; i++)
	  {
	      LCD_Display[3][i] = LCD_Fault[ptr->code][i];
	  }
	}
	

	LCD_Display[2][18] = flmrk[ptr->pos][0];
	LCD_Display[2][19] = flmrk[ptr->pos][1];
}


//************************************
//************************************
//************************************
void Elevator_Status (int16 Status_Dpy, struct Fault *ptr)
{
	int16 i;
	float tfloat;

	switch (Status_Dpy)
	{
		case 0:
		{
				//  " [_]^15 DPC= 00000000",   // 36 - 10
				//  " MVs^   SDC=000000000",   // 37 - 10
				//  " AUT    Up Fast      ",   // 38 - 5, 18
				//  " 000^fpm  tix=       ",   // 39 - 6, 16
		  	LCD_Display[0][1] = '[';
		  	LCD_Display[0][3] = ']';

			if (cons[rear] == 0)
			{
				if (((ptr->run_statusf & rs_DCL) == 0) || (rdinp_fm(i_GS,ptr) == 1))
				  	LCD_Display[0][2] = doors_closed;		// both doors closed
				else
				  	LCD_Display[0][2] = fdoor_open;		// Front door open
			}
			else
			{
				if (((ptr->run_statusf & (rs_DCL | rs_DCLR)) == 0) || ((rdinp_fm(i_GS,ptr) == 1) && (rdinp_fm(i_RGS,ptr) == 1)))
				  	LCD_Display[0][2] = doors_closed;		// both doors closed
				else 
				{
					if (((ptr->run_statusf & rs_DCL) == 0) && ((ptr->run_statusf & rs_DCLR) != 0))
					  	LCD_Display[0][2] = rdoor_open;		// rear door open
					else if (((ptr->run_statusf & rs_DCL) != 0) && ((ptr->run_statusf & rs_DCLR) == 0))
					  	LCD_Display[0][2] = fdoor_open;		// Front door open
					else
					  	LCD_Display[0][2] = ' ';		// both doors open
				}
			}
			
			
			if (ptr->dpref == 1)
		  		LCD_Display[0][4] = up_arrow;		// Up
			else if (ptr->dpref == 2)
			  	LCD_Display[0][4] = dn_arrow;		// Down
			else
			  	LCD_Display[0][4] = ' ';			// None
					  	
			LCD_Display[0][5] = flmrk[ptr->pos][0];
			LCD_Display[0][6] = flmrk[ptr->pos][1];
			
			
				
			if (rdinp_fm(i_MCC,ptr) == 1)
			  	LCD_Display[1][1] = motor_on;		// motor on
			else
			  	LCD_Display[1][1] = ' ';		// motor off
			
			if ((rdoutp_fm(o_RUN,ptr) == 1) && ((rdoutp_fm(o_SU,ptr) == 1) || (rdoutp_fm(o_SD,ptr) == 1)))
			{
				if (rdinp_fm(i_SU,ptr) == 1)
		  			LCD_Display[1][2] = up_arrow;		// Up
				else
				  	LCD_Display[1][2] = dn_arrow;		// Down
				  	
				LCD_Display[1][3] = valve_on;		// valve on
				  	
				if ((rdoutp_fm(o_SUF,ptr) == 1) || (rdoutp_fm(o_SDF,ptr) == 1))
		  			LCD_Display[1][4] = 'f';		// fast valve
				else
				  	LCD_Display[1][4] = ' ';		// no fast valve
				  	
			}
			else
			{
				LCD_Display[1][2] = ' ';		// Direction off
				LCD_Display[1][3] = ' ';		// valve off
				LCD_Display[1][4] = ' ';		// high speed off
			}
			
		  	LCD_Display[2][1] = servf_tbl[ptr->servf][0];	
		  	LCD_Display[2][2] = servf_tbl[ptr->servf][1];	
		  	LCD_Display[2][3] = servf_tbl[ptr->servf][2];

			LCD_Display[0][8] = 'D';
			LCD_Display[0][9] = 'P';
			LCD_Display[0][10] = 'C';
			LCD_Display[0][11] = '=';

			itoa(ptr->dpp_count, LCD_String);  // Put out current Dpp count
			i=0;
			while(((LCD_String[i] >= '0') && (LCD_String[i] <= '9')) || (LCD_String[i] == '-'))
			{
			 	LCD_Display[0][i+12] = LCD_String[i];
			 	i++;
			}
			while((i+12) < 19)
			{
			 	LCD_Display[0][i+12] = ' ';
			 	i++;
			}
			

			if (((ptr->run_statusf & (rs_UL | rs_DL | rs_DZ)) != 0) && ((ptr->run_statusf & rs_HSF) == 0)) 
			{		// In the door zone and not running high speed
				LCD_Display[1][8] = 'F';
				LCD_Display[1][9] = 'P';
				LCD_Display[1][10] = 'C';
				LCD_Display[1][11] = '=';
				itoa(ptr->fl_dpp_count, LCD_String);  // Put out current Dpp count
				i=0;
				while(((LCD_String[i] >= '0') && (LCD_String[i] <= '9')) || (LCD_String[i] == '-'))
				{
				 	LCD_Display[1][i+12] = LCD_String[i];
				 	i++;
				}
				while((i+12) < 19)
				{
				 	LCD_Display[1][i+12] = ' ';
				 	i++;
				}
			}
			else
			{
				LCD_Display[1][8] = 'S';
				LCD_Display[1][9] = 'D';
				LCD_Display[1][10] = 'C';
				LCD_Display[1][11] = '=';
				itoa(ptr->sd_count, LCD_String);  // Put out current Dpp count
				i=0;
				while(((LCD_String[i] >= '0') && (LCD_String[i] <= '9')) || (LCD_String[i] == '-'))
				{
				 	LCD_Display[1][i+12] = LCD_String[i];
				 	i++;
				}
				while((i+12) < 19)
				{
				 	LCD_Display[1][i+12] = ' ';
				 	i++;
				}
			}
			
			// Elevator process line 3
			if ((ptr->procf>=3) && (ptr->procf<=11))
			{
			    for(i=8; i<=18; i++)
			    {
					LCD_Display[2][i] = LCD_Procf2[ptr->procf-3][i-8];
			    }
			}
			else
			{
			    for(i=8; i<=19; i++)
			    {
					LCD_Display[2][i] = ' ';
			    }
			}

			// Car Velocity
			itoa(ptr->enc_vel_fpm,LCD_String);
			i=0;
			while((LCD_String[i] >= '0') && (LCD_String[i] <= '9'))
			{
			  	LCD_Display[3][(i+1)] = LCD_String[i];
			  	i++;
			}
			while((i+1) < 9)
			{
			  	LCD_Display[3][(i+1)] = ' ';
			  	i++;
			}

			if (ptr->enc_dir == 1)
			  	LCD_Display[3][5] = up_arrow;
			else if (ptr->enc_dir == 2)
			  	LCD_Display[3][5] = dn_arrow;
			else
			  	LCD_Display[3][5] = ' ';
			
			LCD_Display[3][6] = 'f';
			LCD_Display[3][7] = 'p';
			LCD_Display[3][8] = 'm';

			if (Trace_Stop == 1)
			{
				if ((trace_stop_ix + 36) >= max_trace_ix)		// go to beginning of trace
					trace_dpy_offset = (int16)(36 - (max_trace_ix - trace_stop_ix));
				else
					trace_dpy_offset = (int16)(trace_stop_ix + 36);
					
				if (trace_dpy_ix < trace_dpy_offset)
					dpy_offset_ix = (trace_dpy_ix + (max_trace_ix - trace_dpy_offset));
				else
					dpy_offset_ix = trace_dpy_ix - trace_dpy_offset;
				
				// Trace Index
				LCD_Display[3][13] = 't';
				LCD_Display[3][14] = 'i';
				LCD_Display[3][15] = 'x';
				LCD_Display[3][16] = '=';
				itoa(dpy_offset_ix,LCD_String);
				i=0;
				while((LCD_String[i] >= '0') && (LCD_String[i] <= '9'))
				{
				  	LCD_Display[3][i+17] = LCD_String[i];
				  	i++;
				}
				while((i+17) <= 19)
				{
				  	LCD_Display[3][(i+17)] = ' ';
				  	i++;
				}
			}
			
			break;
		}
		
		case 1:
		{
			Elevator_Service(ptr);
			break;
		}

		case 2:	// NTS Status
		{
			//		NTS Position Count
			itoa(ptr->NTS_poscnt, LCD_String);  // Put out current NTS position count
			i=0;
			while(((LCD_String[i] >= '0') && (LCD_String[i] <= '9')) || (LCD_String[i] == '-'))
			{
			 	LCD_Display[0][i+12] = LCD_String[i];
			 	i++;
			}
			while((i+12) <= 19)
			{
			 	LCD_Display[0][i+12] = ' ';
			 	i++;
			}

			// NTS velocity
			itoa(ptr->NTS_vel,LCD_String);
			i=0;
			while((LCD_String[i] >= '0') && (LCD_String[i] <= '9'))
			{
			  	LCD_Display[1][(i+6)] = LCD_String[i];
			  	i++;
			}
			while((i+6) < 10)
			{
			  	LCD_Display[1][(i+6)] = ' ';
			  	i++;
			}

			if (ptr->NTS_vel_dir == 1)
			  	LCD_Display[1][10] = up_arrow;
			else if (ptr->NTS_vel_dir == 2)
			  	LCD_Display[1][10] = dn_arrow;
			else
			  	LCD_Display[1][10] = ' ';
			
			LCD_Display[1][11] = 'f';
			LCD_Display[1][12] = 'p';
			LCD_Display[1][13] = 'm';
			
			if ((ptr->NTS_limits & 0x01) != 0)	// UN
				LCD_Display[2][2] = io_on;
			else
				LCD_Display[2][2] = io_off;
			
			if ((ptr->NTS_limits & 0x02) != 0)	// UT
				LCD_Display[2][6] = io_on;
			else
				LCD_Display[2][6] = io_off;
				
			if ((ptr->NTS_doorzone & 0x02) != 0)	// DZ
				LCD_Display[2][11] = io_on;
			else
				LCD_Display[2][11] = io_off;
			
			if ((ptr->NTS_status1 & 0x01) != 0)	// Hoistway learn
				LCD_Display[2][19] = io_on;
			else
				LCD_Display[2][19] = io_off;
			
			if ((ptr->NTS_limits & 0x10) != 0)	// DN
				LCD_Display[3][2] = io_on;
			else
				LCD_Display[3][2] = io_off;
				
			if ((ptr->NTS_limits & 0x20) != 0)	// DT
				LCD_Display[3][6] = io_on;
			else
				LCD_Display[3][6] = io_off;
				
			if ((ptr->NTS_status1 & 0x08) != 0)	// Online
				LCD_Display[3][11] = io_on;
			else
				LCD_Display[3][11] = io_off;
		
			if ((ptr->NTS_status1 & 0x04) != 0)	// CPF Clip Fault
				LCD_Display[3][19] = io_on;
			else
				LCD_Display[3][19] = io_off;
		
			break;
		}
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		{
			i = (Status_Dpy - 3) * 12;
			display_io_value(i,ptr);
			break;
		}
		case 11: // Check run, start, level and doors
		{
			//  " CkDrS=             ",	// 32 - 6, 17
			//  " CkStS=             ",	// 33 - 6, 17
			//  "CkRunS=             ",	// 34 - 6, 17
			//  "CkLevS=             ",	// 35 - 6, 17
  		    for(i=7; i<=19; i++)
		    {
				LCD_Display[0][i] = LCD_ckdoor_tbl[ptr->chkdoor_st][i-7];
		    }

  		    for(i=7; i<=19; i++)
		    {
				LCD_Display[1][i] = LCD_ckstart_tbl[ptr->chkstart_st][i-7];
		    }

  		    for(i=7; i<=19; i++)
		    {
				LCD_Display[2][i] = LCD_ckrun_tbl[ptr->chkrun_st][i-7];
		    }

  		    for(i=7; i<=19; i++)
		    {
				LCD_Display[3][i] = LCD_cklevel_tbl[ptr->chklevel_st][i-7];
		    }

			break;
		}
		case 12: // Check run, start, level and doors
		{
			//  "Up 10   -10    fpm/s",	// 36 - 6, 17
			//  "Dn 10   -10    fpm/s",	// 37 - 6, 17
			//  "USD 40.0 ULD 20.0 in",	// 38 - 6, 17
			//  "DSD 40.0 DLD 20.0 in",	// 39 - 6, 17
			sprintf(&LCD_Display[0][3],"%2.0f",Up_Accel_Rate);
			LCD_Display[0][5] = ' ';
			LCD_Display[0][6] = ' ';
			sprintf(&LCD_Display[0][9],"%2.0f",Up_Decel_Rate);
			LCD_Display[0][11] = ' ';
			LCD_Display[0][12] = ' ';
			sprintf(&LCD_Display[1][3],"%2.0f",Dn_Accel_Rate);
			LCD_Display[1][5] = ' ';
			LCD_Display[1][6] = ' ';
			sprintf(&LCD_Display[1][9],"%2.0f",Dn_Decel_Rate);
			LCD_Display[1][11] = ' ';
			LCD_Display[1][12] = ' ';
			
			tfloat = (float)(DPP_Fl_Up_SD[position]/Pulses_per_Inch);
			sprintf(&LCD_Display[2][4],"%2.1f",tfloat);
			if (tfloat < 10)
				LCD_Display[2][7] = ' ';
			LCD_Display[2][8] = ' ';
			
			sprintf(&LCD_Display[2][13],"%2.1f",Up_Lev_Dist_Inch);
			if (Dn_Lev_Dist_Inch < 10)
				LCD_Display[2][16] = ' ';
			LCD_Display[2][17] = ' ';
			
			tfloat = (float)(DPP_Fl_Dn_SD[position]/Pulses_per_Inch);
			sprintf(&LCD_Display[3][4],"%2.1f",tfloat);
			if (tfloat < 10)
				LCD_Display[3][7] = ' ';
			LCD_Display[3][8] = ' ';

			sprintf(&LCD_Display[3][13],"%2.1f",Dn_Lev_Dist_Inch);
			if (Dn_Lev_Dist_Inch < 10)
				LCD_Display[3][16] = ' ';
			LCD_Display[3][17] = ' ';
			

			break;
		}
		case 13:
		{		   // debug
			sprintf(LCD_String,"%06xh",(int)debug1);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[0][10+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%06xh",(int)debug2);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[1][10+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%06xh",(int)debug3);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[2][10+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%06xh",(int)debug4);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[3][10+i] = LCD_String[i];
		    }
			break;
		}

		case 14:
		{		 // debug
			sprintf(LCD_String,"%06xh",(int)debug5);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[0][10+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%06xh",(int)debug6);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[1][10+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%06xh",(int)debug7);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[2][10+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%06xh",(int)debug8);
		    for(i=0; i<=6; i++)
		    {
			   	LCD_Display[3][10+i] = LCD_String[i];
		    }
			break;
		}
/*
		case 2: // LCD_Detail_Fault Menu Active Data 0
				//	"servf=   , procf=   "	// 0  - 6, 17
				//  "doorf=   .rdoorf=   ", // 1  - 6, 17
				//  "dpref=   ,  dirf=   ", // 2  - 6, 17
				//  " empf=   ,  medf=   ".	// 3  - 6, 17
  		{	   
			sprintf(LCD_String,"%2i",servf);
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",procf);
		  	LCD_Display[0][17] = LCD_String[0];
		  	LCD_Display[0][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",doorf);
		  	LCD_Display[1][6] = LCD_String[0];
		  	LCD_Display[1][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",rdoorf);
		  	LCD_Display[1][17] = LCD_String[0];
		  	LCD_Display[1][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",dpref);
		  	LCD_Display[2][6] = LCD_String[0];
		  	LCD_Display[2][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",dirf);
		  	LCD_Display[2][17] = LCD_String[0];
		  	LCD_Display[2][18] = LCD_String[1];
			
			sprintf(LCD_String,"%2i",empf);
		  	LCD_Display[3][6] = LCD_String[0];
		  	LCD_Display[3][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",medf);
		  	LCD_Display[3][17] = LCD_String[0];
		  	LCD_Display[3][18] = LCD_String[1];

			break;
		}

		case 3: // LCD_Detail_Fault Menu Active Data 1
				//  "codeb=   ,   eqf=   ",   // 4  - 6, 17
				//  "firef=   ,rfiref=   ",   // 5  - 6, 17
				//  "  hsf=   ,startf=   ",   // 6  - 6, 17
				//  "stepf=   ,estopf=   ",   // 7  - 6, 17
		{	
			sprintf(LCD_String,"%2i",codebf);
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",eqf);
		  	LCD_Display[0][17] = LCD_String[0];
		  	LCD_Display[0][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",firef);
		  	LCD_Display[1][6] = LCD_String[0];
		  	LCD_Display[1][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",rfiref);
		  	LCD_Display[1][17] = LCD_String[0];
		  	LCD_Display[1][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",hsf);
		  	LCD_Display[2][6] = LCD_String[0];
		  	LCD_Display[2][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",startf);
		  	LCD_Display[2][17] = LCD_String[0];
		  	LCD_Display[2][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",stepf);
		  	LCD_Display[3][6] = LCD_String[0];
		  	LCD_Display[3][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",estop);
		  	LCD_Display[3][17] = LCD_String[0];
		  	LCD_Display[3][18] = LCD_String[1];

			break;
		}
		
		case 4: // LCD_Detail_Fault Menu Active Data 2
				//  "callf=   ,dcalls=   ",   // 8  - 6, 17
				//  "nstop=   ,nxstop=   ",   // 9  - 6, 17
				//  "Relev=   ,LevStr=   ",   // 10 - 6, 17
				//  "NCUds=   ,DOseqf=   ",   // 11 - 6, 17
		{	
			sprintf(LCD_String,"%02x",Call_Flags);
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",dcalls);
		  	LCD_Display[0][17] = LCD_String[0];
		  	LCD_Display[0][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",nstopf);
		  	LCD_Display[1][6] = LCD_String[0];
		  	LCD_Display[1][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",stops[0]);
		  	LCD_Display[1][17] = LCD_String[0];
		  	LCD_Display[1][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",relevel);
		  	LCD_Display[2][6] = LCD_String[0];
		  	LCD_Display[2][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",lev_startf);
		  	LCD_Display[2][17] = LCD_String[0];
		  	LCD_Display[2][18] = LCD_String[1];

			sprintf(LCD_String,"%2i",ncu_door_seq);
		  	LCD_Display[3][6] = LCD_String[0];
		  	LCD_Display[3][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",Door_Seq_Flags);
		  	LCD_Display[3][17] = LCD_String[0];
		  	LCD_Display[3][18] = LCD_String[1];
			break;
		}
		
		case 5: // LCD_Detail_Fault Menu Active Data 3
				//  "NudSt=   ,DoorRq=   ",   // 12 - 6, 17
				//  "FSd=     ,RSd=      ",   // 13 - 4, 14
				//  "InsSt=   ,InsSvc=   ",   // 14 - 6, 17
				//  "Motion Tmr =        ",   // 15 - 13
		{	
			sprintf(LCD_String,"%02x",Nudgst_Flags);
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];

			sprintf(LCD_String,"%02x",Door_Req_Flags);
		  	LCD_Display[0][17] = LCD_String[0];
		  	LCD_Display[0][18] = LCD_String[1];

			sprintf(LCD_String,"%04x",front_slowdown);
		  	LCD_Display[1][4] = LCD_String[0];
		  	LCD_Display[1][5] = LCD_String[1];
		  	LCD_Display[1][6] = LCD_String[2];
		  	LCD_Display[1][7] = LCD_String[3];

			sprintf(LCD_String,"%04x",rear_slowdown);
		  	LCD_Display[1][14] = LCD_String[0];
		  	LCD_Display[1][15] = LCD_String[1];
		  	LCD_Display[1][16] = LCD_String[2];
		  	LCD_Display[1][17] = LCD_String[3];

			sprintf(LCD_String,"%2x",ins_status);
		  	LCD_Display[2][6] = LCD_String[0];
		  	LCD_Display[2][7] = LCD_String[1];

			sprintf(LCD_String,"%2i",ins_servf);
		  	LCD_Display[2][17] = LCD_String[0];
		  	LCD_Display[2][18] = LCD_String[1];

			sprintf(LCD_String,"%5i",timers[tmotion]);
		  	LCD_Display[3][13] = LCD_String[0];
		  	LCD_Display[3][14] = LCD_String[1];
   		  	LCD_Display[3][15] = LCD_String[2];
		  	LCD_Display[3][16] = LCD_String[3];
		  	LCD_Display[3][17] = LCD_String[4];
			break;
		}
		
		case 6: // statusf and statusf2, SS Status, Pwr Status and Run Status    
				//  " statusf =          ",   // 16 - 11
				//  "statusf2 =          ",   // 17 - 11
				//  "Run Stat =          ",   // 18 - 11
				//  "ssSt=    ,pwrSt=    ",   // 19 - 5, 16
		{	 
			sprintf(LCD_String,"%08xh",(int32)statusf);
		    for(i=0; i<=8; i++)
		    {
			   	LCD_Display[0][11+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%08xh",(int32)statusf2);
		    for(i=0; i<=8; i++)
		    {
			   	LCD_Display[1][11+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%08xh",(int32)run_statusf);
		    for(i=0; i<=8; i++)
		    {
			   	LCD_Display[2][11+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%04x",(int16)safety_string_status);
		    for(i=0; i<4; i++)
		    {
			   	LCD_Display[3][5+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%04x",(int16)power_status);
		    for(i=0; i<4; i++)
		    {
			   	LCD_Display[3][16+i] = LCD_String[i];
		    }
			break;
		}
		case 7:
		{	 // statusf3 and statusf4
			sprintf(LCD_String,"%08xh",(int32)statusf3);
		    for(i=0; i<=8; i++)
		    {
			   	LCD_Display[0][13+i] = LCD_String[i];
		    }
			sprintf(LCD_String,"%08xh",(int32)statusf4);
		    for(i=0; i<=8; i++)
		    {
			   	LCD_Display[1][13+i] = LCD_String[i];
		    }
			break;
		}

		
		case 10: // SS Status, Pwr Status and Run Status    run_statusf
		{	 


			break;
		}
		case 11: // LCD_Detail_Fault Menu Active Data 4
		{
				//  "FltB1=   . FltB2=   ", // 30 - 6, 17
				//  "FltB3=   . FltB4=   ", // 31 - 6, 17
				//  "CkDrS=   ,CkRunS=   ",	// 34 - 6, 17
				//  "CkStS=   ,CkLevS=   ",	// 35 - 6, 17
			sprintf(LCD_String,"%02x",Fault_Bits[0]);
		  	LCD_Display[0][6] = LCD_String[0];
		  	LCD_Display[0][7] = LCD_String[1];
		  	LCD_Display[0][8] = 'h';

			sprintf(LCD_String,"%02x",Fault_Bits[1]);
		  	LCD_Display[0][17] = LCD_String[0];
		  	LCD_Display[0][18] = LCD_String[1];
		  	LCD_Display[0][19] = 'h';
		  	
			sprintf(LCD_String,"%02x",Fault_Bits[2]);
		  	LCD_Display[1][6] = LCD_String[0];
		  	LCD_Display[1][7] = LCD_String[1];
		  	LCD_Display[1][8] = 'h';

			sprintf(LCD_String,"%02x",Fault_Bits[3]);
		  	LCD_Display[1][17] = LCD_String[0];
		  	LCD_Display[1][18] = LCD_String[1];
		  	LCD_Display[1][19] = 'h';
		  	
			sprintf(LCD_String,"%02x",chkdoor_state);
		  	LCD_Display[2][6] = LCD_String[0];
		  	LCD_Display[2][7] = LCD_String[1];

			sprintf(LCD_String,"%02x",chkrun_state);
		  	LCD_Display[2][17] = LCD_String[0];
		  	LCD_Display[2][18] = LCD_String[1];

			sprintf(LCD_String,"%02x",chkstart_state);
		  	LCD_Display[3][6] = LCD_String[0];
		  	LCD_Display[3][7] = LCD_String[1];

			sprintf(LCD_String,"%02x",chklevel_state);
		  	LCD_Display[3][17] = LCD_String[0];
		  	LCD_Display[3][18] = LCD_String[1];

			break;
		}

		case 12:	// Run Status
		{
				//  "RUN= ,HS= ,SU= ,SD= ", // 4,9,14,19
				//  "DZA= ,UL= ,DZ= ,DL= ", // 4,9,14,19
				//  "DOL= ,TL= ,ML= ,BL= ", // 4,9,14,19
				//  "DCL= ,DC= ,DO= ,GS= ",	// 4,9,14,19
				
				
				//  "RUN= ,HS= ,SU= ,SD= ", // 4,9,14,19
			if ((run_statusf & rs_RUN) != 0)
				LCD_Display[0][4] = '1';
			else
				LCD_Display[0][4] = '0';
			
			if ((run_statusf & rs_HSF) != 0)
				LCD_Display[0][9] = '1';
			else
				LCD_Display[0][9] = '0';
			
			if ((run_statusf & rs_UP) != 0)
				LCD_Display[0][14] = '1';
			else
				LCD_Display[0][14] = '0';
			
			if ((run_statusf & rs_DNR) != 0)
				LCD_Display[0][19] = '1';
			else
				LCD_Display[0][19] = '0';
			
				//  "DZA= ,UL= ,DZ= ,DL= ", // 4,9,14,19
			if ((run_statusf & rs_DZA) != 0)
				LCD_Display[1][4] = '1';
			else
				LCD_Display[1][4] = '0';
			
			if ((run_statusf & rs_UL) != 0)
				LCD_Display[1][9] = '1';
			else
				LCD_Display[1][9] = '0';
			
			if ((run_statusf & rs_DZ) != 0)
				LCD_Display[1][14] = '1';
			else
				LCD_Display[1][14] = '0';
			
			if ((run_statusf & rs_DL) != 0)
				LCD_Display[1][19] = '1';
			else
				LCD_Display[1][19] = '0';
			
				//  "DOL= ,TL= ,ML= ,BL= ", // 4,9,14,19
			if ((run_statusf & rs_DCL) != 0)
				LCD_Display[2][4] = '1';
			else
				LCD_Display[2][4] = '0';
			
			if ((run_statusf & rs_DLT) != 0)
				LCD_Display[2][9] = '1';
			else
				LCD_Display[2][9] = '0';
			
			if ((run_statusf & rs_DLM) != 0)
				LCD_Display[2][14] = '1';
			else
				LCD_Display[2][14] = '0';
			
			if ((run_statusf & rs_DLB) != 0)
				LCD_Display[2][19] = '1';
			else
				LCD_Display[2][19] = '0';
				
			
				//  "DCL= ,DC= ,DO= ,GS= ",	// 4,9,14,19
			if ((run_statusf & rs_DCL) != 0)
				LCD_Display[3][4] = '1';
			else
				LCD_Display[3][4] = '0';
			
			if ((run_statusf & rs_DC) != 0)
				LCD_Display[3][9] = '1';
			else
				LCD_Display[3][9] = '0';
			
			if ((run_statusf & rs_DO) != 0)
				LCD_Display[3][14] = '1';
			else
				LCD_Display[3][14] = '0';
			
			if ((run_statusf & rs_GS) != 0)
				LCD_Display[3][19] = '1';
			else
				LCD_Display[3][19] = '0';
			break;
		}
		
		case 13:	// Run Status with rear door
		{
				//  "RUN= ,HS= ,SU= ,SD= ", // 4,9,14,19
				//  "DZA= ,UL= ,DZ= ,DL= ", // 4,9,14,19
				//  "DOLR= ,RLM= ,RGS=   ", // 5,11,17
				//  "DCLR= ,DCR= ,DOR=   ", // 5,11,17
				
				
				//  "RUN= ,HS= ,SU= ,SD= ", // 4,9,14,19
			if ((run_statusf & rs_RUN) != 0)
				LCD_Display[0][4] = '1';
			else
				LCD_Display[0][4] = '0';
			
			if ((run_statusf & rs_HSF) != 0)
				LCD_Display[0][9] = '1';
			else
				LCD_Display[0][9] = '0';
			
			if ((run_statusf & rs_UP) != 0)
				LCD_Display[0][14] = '1';
			else
				LCD_Display[0][14] = '0';
			
			if ((run_statusf & rs_DNR) != 0)
				LCD_Display[0][19] = '1';
			else
				LCD_Display[0][19] = '0';
			
				//  "DZA= ,UL= ,DZ= ,DL= ", // 4,9,14,19
			if ((run_statusf & rs_DZA) != 0)
				LCD_Display[1][4] = '1';
			else
				LCD_Display[1][4] = '0';
			
			if ((run_statusf & rs_UL) != 0)
				LCD_Display[1][9] = '1';
			else
				LCD_Display[1][9] = '0';
			
			if ((run_statusf & rs_DZ) != 0)
				LCD_Display[1][14] = '1';
			else
				LCD_Display[1][14] = '0';
			
			if ((run_statusf & rs_DL) != 0)
				LCD_Display[1][19] = '1';
			else
				LCD_Display[1][19] = '0';
			
				//  "DOLR= ,RLM= ,RGS=   ", // 5,11,17
			if ((run_statusf & rs_DCLR) != 0)
				LCD_Display[2][5] = '1';
			else
				LCD_Display[2][5] = '0';
			
			if ((run_statusf & rs_RLM) != 0)
				LCD_Display[2][11] = '1';
			else
				LCD_Display[2][11] = '0';
			
			if ((run_statusf & rs_RGS) != 0)
				LCD_Display[2][17] = '1';
			else
				LCD_Display[2][17] = '0';
			
			
				//  "DCLR= ,DCR= ,DOR=   ", // 5,11,17
			if ((run_statusf & rs_DCLR) != 0)
				LCD_Display[3][4] = '1';
			else
				LCD_Display[3][4] = '0';
			
			if ((run_statusf & rs_DCR) != 0)
				LCD_Display[3][9] = '1';
			else
				LCD_Display[3][9] = '0';
			
			if ((run_statusf & rs_DOR) != 0)
				LCD_Display[3][14] = '1';
			else
				LCD_Display[3][14] = '0';
			
			break;
		}

		case 14:
		{			   // fire status
			sprintf(LCD_String,"%2i",fs1_effect);
		  	LCD_Display[0][5] = LCD_String[0];
		  	LCD_Display[0][6] = LCD_String[1];

			sprintf(LCD_String,"%2i",fire_reset);
		  	LCD_Display[0][13] = LCD_String[0];
		  	LCD_Display[0][14] = LCD_String[1];

			sprintf(LCD_String,"%2x",car_Grp_Stat.c_grp_fire_ctrl);
		  	LCD_Display[0][21] = LCD_String[0];
		  	LCD_Display[0][22] = LCD_String[1];
		  	LCD_Display[0][23] = 'h';

			sprintf(LCD_String,"%2i",fs2_to_fs1);
		  	LCD_Display[1][5] = LCD_String[0];
		  	LCD_Display[1][6] = LCD_String[1];

			sprintf(LCD_String,"%2i",fire_sensor);
		  	LCD_Display[1][13] = LCD_String[0];
		  	LCD_Display[1][14] = LCD_String[1];

			sprintf(LCD_String,"%2x",fire_status);
		  	LCD_Display[1][21] = LCD_String[0];
		  	LCD_Display[1][22] = LCD_String[1];
		  	LCD_Display[1][23] = 'h';

			break;
		}
		
		case 15:
		{		  // LCD_Run Timer Display
#if (Traction == 1)

			// Pre-torque time
			for (i=0;i<=7;i++)
				LCD_String[i] = ' ';

			if ((procf >= 14) && (procf <= 16))
				i = pre_torque_time;
			else
				i = 0;
			sprintf(LCD_String, "%2d.%-1d", i/10, i%10);
		  	LCD_Display[0][4] = LCD_String[0];
		  	LCD_Display[0][5] = LCD_String[1];
		  	LCD_Display[0][6] = LCD_String[2];
		  	LCD_Display[0][7] = LCD_String[3];
		  	
			// Run time from start of pattern
			for (i=0;i<=7;i++)
				LCD_String[i] = ' ';

			if ((run_time > pre_torque_time) && (procf >= 14) && (procf <= 16))
				i = run_time - pre_torque_time;
			else
				i = 0;
			sprintf(LCD_String, "%3d.%-1d", i/10, i%10);
		  	LCD_Display[0][13] = LCD_String[0];
		  	LCD_Display[0][14] = LCD_String[1];
		  	LCD_Display[0][15] = LCD_String[2];
		  	LCD_Display[0][16] = LCD_String[3];
		  	LCD_Display[0][17] = LCD_String[4];

			if (short_fl_run == 1)
				LCD_Display[0][23] = '1';
			else
				LCD_Display[0][23] = '0';
			
			// Pre-open door time
			for (i=0;i<=7;i++)
				LCD_String[i] = ' ';

			if ((run_time >= preopen_time) && (preopen_time != 0) && (procf >= 14) && (procf <= 16))
				i = run_time - preopen_time;
			else
				i = 0;
			sprintf(LCD_String, "%2d.%-1d", i/10, i%10);
		  	LCD_Display[1][4] = LCD_String[0];
		  	LCD_Display[1][5] = LCD_String[1];
		  	LCD_Display[1][6] = LCD_String[2];
		  	LCD_Display[1][7] = LCD_String[3];

			for (i=0;i<=7;i++)
				LCD_String[i] = ' ';

			// Leveling time
			if ((run_time >= targetfl_time) && (procf >= 14) && (procf <= 16))
				i = run_time - targetfl_time;
			else
				i = 0;
			sprintf(LCD_String, "%2d.%-1d", i/10, i%10);
		  	LCD_Display[1][13] = LCD_String[0];
		  	LCD_Display[1][14] = LCD_String[1];
		  	LCD_Display[1][15] = LCD_String[2];
		  	LCD_Display[1][16] = LCD_String[3];

			if (Roll_early_exit == 1)
				LCD_Display[1][23] = '1';
			else
				LCD_Display[1][23] = '0';

#endif			
			break;
		}

		case 18:			   // NTS Status
		{
			NTS_can.cmd_req = 1;
			itoa(NTS_can.velocity,LCD_String);
			i=0;
			while((LCD_String[i] >= '0') && (LCD_String[i] <= '9'))
			{
			  	LCD_Display[0][(i+8)] = LCD_String[i];
			  	i++;
			}
			while((i+8) < 12)
			{
			  	LCD_Display[0][(i+8)] = ' ';
			  	i++;
			}
			
			if (NTS_can.vel_dir == 1)
				LCD_Display[0][12] = 'U';
			else if (NTS_can.vel_dir == 2)
				LCD_Display[0][12] = 'D';
			else
				LCD_Display[0][12] = ' ';
						
			j = 0;
			for (i=18;i<=19;i++)
				LCD_Display[0][i] = nts_service[NTS_can.service][j++];

			if (((NTS_can.limit_flt[0] & 0xf5) != 0) || ((NTS_can.limit_flt[1] & 0x0f) != 0))
				j = 9;
			else if (((NTS_can.limit_flt[1] & 0x50) != 0) || ((NTS_can.limit_flt[2] & 0x7f) != 0))
				j = 8;
			else if ((NTS_can.status & 0x40) != 0)
				j = 7;						// emsd 
			else if ((NTS_can.status & 0x20) != 0)
				j = 6;						// vel fault
			else if ((NTS_can.status & 0x80) != 0)
				j = 5;						// vel dir fault
			else if ((NTS_can.status & 0x04) == 0)
				j = 4;						// sel comm fault
			else if ((NTS_can.status & 0x08) == 0)
				j = 3;						// spb comm fault
			else if ((NTS_can.status & 0x02) != 0)
				j = 2;						// running dn
			else if ((NTS_can.status & 0x01) != 0)
				j = 1;						// running up
			else 
				j = 0;						// run enable
				
			for (i=0;i<17;i++)
				LCD_Display[1][7+i] = nts_lim_stat[j][i];
			
			break;
		}
	*/
		default:
			break;
	}
	if ((Trace_Stop == 1) && (Trace_ix_dpy == 1))
	{
		if ((trace_stop_ix + 36) >= max_trace_ix)		// go to beginning of trace
			trace_dpy_offset = (int16)(36 - (max_trace_ix - trace_stop_ix));
		else
			trace_dpy_offset = (int16)(trace_stop_ix + 36);
			
		if (trace_dpy_ix < trace_dpy_offset)
			dpy_offset_ix = (trace_dpy_ix + (max_trace_ix - trace_dpy_offset));
		else
			dpy_offset_ix = trace_dpy_ix - trace_dpy_offset;
		
		// Trace Index
		LCD_Display[3][12] = ' ';
		LCD_Display[3][13] = 't';
		LCD_Display[3][14] = 'i';
		LCD_Display[3][15] = 'x';
		LCD_Display[3][16] = '=';
		itoa(dpy_offset_ix,LCD_String);
		i=0;
		while((LCD_String[i] >= '0') && (LCD_String[i] <= '9'))
		{
		  	LCD_Display[3][i+17] = LCD_String[i];
		  	i++;
		}
		while((i+17) <= 19)
		{
		  	LCD_Display[3][(i+17)] = ' ';
		  	i++;
		}
	}
	
}

char getcaps (char c)
{
	if ((c >= 'a') && (c <= 'z'))
		c &= ~0x20;
	return(c);
}


/*
void Service_Timers (void)
{

	int16 i;
	int16 max;
	static int16 prev_flash;
	static int16 md_ix;
	static int16 dt_ix;
	static int16 dow_ix;
	static int16 tim_ix;
	static int16 modify_var;
	static int16 date_time_ix;
	static int16 hr_min_ix;
	int16 date_time_max[6] = {12,31,23,59,23,59};
	int16 date_time_min[6] = { 0, 0, 0, 0, 0, 0};
	int16 dow_time_max[4] = {23,59,23,59};
	int16 dow_time_min[4] = {0, 0, 0, 0};
	int16 digit_loc[6] = {14,17,14,17,14,17};
						//     Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
	int16 days_of_month[13] = {0, 31,  29,  31,  30,  31,  30,  31,  30,  31,  31,  30,  31}; 


 	if (Menu_level == 1)
 	{			// Rotate through Call menu items
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[0][i];
 			LCD_Display[0][19] = (char)(Timer_Number + '0'); 
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			Menu_level = 0;
			LCD_Pointer = Timer_Number + 11;
			for(i=0; i<=19; i++)
			{
				LCD_Display[0][i] = LCD_Main_Menu[10][i];
			  	LCD_Display[1][i] = LCD_Timer_Menu[0][i];
			}
			LCD_Display[1][19] = (char)((LCD_Pointer - 11) + '0'); 
			return;
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
		    LCD_Pointer++;
		    if(LCD_Pointer > 7)
			  LCD_Pointer = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
		    LCD_Pointer--;
		    if(LCD_Pointer < 1)
			  LCD_Pointer = 7;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
		  	Menu_level = (LCD_Pointer + 1);
			LCD_Pointer = 0;
		}
		if(upd_dpy == 1)
		{
			upd_dpy = 0;
		    for(i=0; i<=19; i++)
			  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
		}
	}

	if (Menu_level == 2)
	{				   // Set the Month/Day Timers
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
			line_select = 0;
			date_time_ix = 0;
			LCD_Dig_Point = 0;
			modify_var = 0;
			md_ix = 0;
			dt_ix = 0;
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
			get_month_day_timer(Timer_Number,md_ix);
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			if (modify_var == 1)
			{
				upd_dpy = 1;
				if (LCD_Dig_Point == 1)
				{			   // back to first digit
					LCD_Dig_Point = 0;
					date_time_ix ^= 0x01;  // swap byte for date or time
				}
				else
				{			   // second digit
		  			LCD_Dig_Point = 1;	
		  		}		
			}
			else if (line_select > 0)
			{
			 	line_select --;
				if (line_select == 0)
				{
					upd_dpy = 1;
		 		    for(i=0; i<=19; i++)
		 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
					get_month_day_timer(Timer_Number,md_ix);
					dt_ix = 0;
					date_time_ix = 0;
				}
			}
			else
			{
				line_select = 0;
				LCD_Pointer = Menu_level-1;
				Menu_level = 1;
				for(i=0; i<=19; i++)
				{
					LCD_Display[0][i] = LCD_Timer_Menu[0][i];
				  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
				}
				LCD_Display[0][19] = (char)(Timer_Number + '0'); 
			}
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
			if (line_select == 0)
			{						// next month/day timer
				md_ix++;
				if (md_ix > 2)
					md_ix = 0;
				get_month_day_timer(Timer_Number,md_ix);
			}
			else if (line_select == 1)
			{						// next date/time setting
				dt_ix++;
				if (dt_ix > 2)
					dt_ix = 0;
				date_time_ix = dt_ix * 2;
			}
			else if (modify_var == 1)
			{						 // Adjust the time or date
				if (date_time_ix == 1)
					max = days_of_month[date_time_var[c_month]];
				else
					max = date_time_max[date_time_ix];

		  		adjust_variable(&date_time_var[date_time_ix],max,date_time_min[date_time_ix],1,LCD_Dig_Point,0);
			}
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
			if (line_select == 0)
			{						// next month/day timer
				md_ix--;
				if (md_ix < 0)
					md_ix = 2;
				get_month_day_timer(Timer_Number,md_ix);
			}
			else if (line_select == 1)
			{						   // next date/time setting
				dt_ix--;
				if (dt_ix < 0)
					dt_ix = 2;
				date_time_ix = dt_ix * 2;
			}
			else if (modify_var == 1)
			{							// Adjust the time or date
				if (date_time_ix == 1)
					max = days_of_month[date_time_var[c_month]];
				else
					max = date_time_max[date_time_ix];

		  		adjust_variable(&date_time_var[date_time_ix],max,date_time_min[date_time_ix],0,LCD_Dig_Point,0);
			}
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (line_select == 0)
			{						// Select which month/day timer
				line_select = 1;
	 		    for(i=0; i<=19; i++)
	 			  	LCD_Display[0][i] = LCD_Month_Day_Timer_Menu[0][i];
				LCD_Display[0][23] = (char)(md_ix + '0'); 
			}
			else if (line_select == 1)
			{						// enter modify mode
				modify_var = 1;
				line_select = 2;
				LCD_Dig_Point = 0;
				date_time_ix = dt_ix * 2;
			}
			else if (line_select == 2)
			{						   // Update the new timer value
				modify_var = 0;
				line_select = 1;
				set_month_day_timer(Timer_Number,md_ix);
				Wrt_Grp_Svc_Timer(Timer_Number);
			}
		}

		if ((line_select == 2) && (prev_flash != LCD_Flash))
			upd_dpy = 1;
		prev_flash = LCD_Flash;

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			if (line_select == 0)
			{
	 		    for(i=0; i<=19; i++)
	 			  	LCD_Display[1][i] = LCD_Month_Day_Timer_Menu[0][i];
				LCD_Display[1][23] = (char)(md_ix + '0'); 
			}
			else 
			{
	 		    for(i=0; i<=19; i++)
	 			  	LCD_Display[1][i] = LCD_Month_Day_Timer_Menu[dt_ix + 1][i];

				sprintf(&LCD_Display[1][digit_loc[(date_time_ix & 0xFFFE)]],"%02i",date_time_var[(date_time_ix & 0xFFFE)]);
				sprintf(&LCD_Display[1][digit_loc[(date_time_ix & 0xFFFE)+1]],"%02i",date_time_var[(date_time_ix & 0xFFFE)+1]);
				if (dt_ix == 0)
					LCD_Display[1][16] = '/';
				else
					LCD_Display[1][16] = ':';

			  	LCD_Flash_TMP[0] = LCD_Display[1][(digit_loc[date_time_ix]+1)-LCD_Dig_Point];
	 		}
			flash_digit(LCD_Flash_TMP[0], 1, (digit_loc[date_time_ix]+1)-LCD_Dig_Point, (modify_var == 1));
		}
	}
	if (Menu_level == 3)
	{			// Set the Day of the Week timers
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
			line_select = 0;
			hr_min_ix = 0;
			LCD_Dig_Point = 0;
			modify_var = 0;
			dow_ix = 0;
			tim_ix = 0;
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
			get_dow_timer(Timer_Number,dow_ix);
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			if (modify_var == 1)
			{
				upd_dpy = 1;
				if (LCD_Dig_Point == 1)
				{			   // back to first digit
					LCD_Dig_Point = 0;
					hr_min_ix ^= 0x01;  // swap byte for date or time
				}
				else
				{			   // second digit
		  			LCD_Dig_Point = 1;	
		  		}		
			}
			else if (line_select > 0)
			{
			 	line_select --;
				if (line_select == 0)
				{
					upd_dpy = 1;
		 		    for(i=0; i<=19; i++)
		 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
					get_dow_timer(Timer_Number,dow_ix);
					tim_ix = 0;
					hr_min_ix = 0;
				}
			}
			else
			{
				line_select = 0;
				LCD_Pointer = Menu_level-1;
				Menu_level = 1;
				for(i=0; i<=19; i++)
				{
					LCD_Display[0][i] = LCD_Timer_Menu[0][i];
				  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
				}
				LCD_Display[0][19] = (char)Timer_Number + '0'; 
			}
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
			if (line_select == 0)
			{						// daily timer
				dow_ix++;
				if (dow_ix > 6)
					dow_ix = 0;
				get_dow_timer(Timer_Number,dow_ix);
			}
			else if (line_select == 1)
			{						// next time setting
				tim_ix++;
				if (tim_ix > 1)
					tim_ix = 0;
				hr_min_ix = tim_ix * 2;
			}
			else if (modify_var == 1)
			{						 // Adjust the time or date
		  		adjust_variable(&dow_time_var[hr_min_ix],dow_time_max[hr_min_ix],dow_time_min[hr_min_ix],1,LCD_Dig_Point,0);
			}
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
			if (line_select == 0)
			{						// next month/day timer
				dow_ix--;
				if (dow_ix < 0)
					dow_ix = 6;
				get_dow_timer(Timer_Number,dow_ix);
			}
			else if (line_select == 1)
			{						   // next date/time setting
				tim_ix--;
				if (tim_ix < 0)
					tim_ix = 1;
				hr_min_ix = tim_ix * 2;
			}
			else if (modify_var == 1)
			{							// Adjust the time or date
		  		adjust_variable(&dow_time_var[hr_min_ix],dow_time_max[hr_min_ix],dow_time_min[hr_min_ix],0,LCD_Dig_Point,0);
			}
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (line_select == 0)
			{						// Select which month/day timer
				line_select = 1;
	 		    for(i=0; i<=19; i++)
	 			  	LCD_Display[0][i] = LCD_DOW_Timer_Menu[dow_ix][i];
			}
			else if (line_select == 1)
			{						// enter modify mode
				modify_var = 1;
				line_select = 2;
				LCD_Dig_Point = 0;
				hr_min_ix = tim_ix * 2;
			}
			else if (line_select == 2)
			{						   // Update the new timer value
				modify_var = 0;
				line_select = 1;
				set_dow_timer(Timer_Number,dow_ix);
				Wrt_Grp_Svc_Timer(Timer_Number);
			}
		}

		if ((line_select == 2) && (prev_flash != LCD_Flash))
			upd_dpy = 1;
		prev_flash = LCD_Flash;

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			if (line_select == 0)
			{
	 		    for(i=0; i<=19; i++)
	 			  	LCD_Display[1][i] = LCD_DOW_Timer_Menu[dow_ix][i];
			}
			else 
			{
	 		    for(i=0; i<=19; i++)
	 			  	LCD_Display[1][i] = LCD_DOW_Timer_Menu[tim_ix + 7][i];

				sprintf(&LCD_Display[1][digit_loc[(hr_min_ix & 0xFFFE)]],"%02i",dow_time_var[(hr_min_ix & 0xFFFE)]);
				sprintf(&LCD_Display[1][digit_loc[(hr_min_ix & 0xFFFE)+1]],"%02i",dow_time_var[(hr_min_ix & 0xFFFE)+1]);
				LCD_Display[1][16] = ':';

			  	LCD_Flash_TMP[0] = LCD_Display[1][(digit_loc[hr_min_ix]+1)-LCD_Dig_Point];
	 		}
			flash_digit(LCD_Flash_TMP[0], 1, (digit_loc[hr_min_ix]+1)-LCD_Dig_Point, (modify_var == 1));
		}
	}
	if (Menu_level == 4)
	{					// Set the timer service
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
			status_select = 0;
			Timer_Service = svc_t[Timer_Number].service;
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			status_select = 0;
			LCD_Pointer = Menu_level-1;
			Menu_level = 1;
			for(i=0; i<=19; i++)
			{
				LCD_Display[0][i] = LCD_Timer_Menu[0][i];
			  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
			}
			LCD_Display[0][19] = (char)Timer_Number + '0'; 
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
			if (status_select == 1)
			{
				Timer_Service++;
				if (Timer_Service > s_last)
					Timer_Service = s_none;
			}
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
			if (status_select == 1)
			{
				Timer_Service--;
				if (Timer_Service < s_none)
					Timer_Service = s_last;
			}
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (status_select == 1)
			{
				status_select = 0;
				svc_t[Timer_Number].service = Timer_Service;
				Wrt_Grp_Svc_Timer(Timer_Number);
			}
			else
				status_select = 1;
		}

		if ((status_select == 1) && (prev_flash != LCD_Flash))
			upd_dpy = 1;
		prev_flash = LCD_Flash;

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			if ((status_select == 1) && (LCD_Flash == 0))
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = ' ';
			}
			else
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Service_Menu[(uint8)Timer_Service][i];
			}
		}
	}
	if (Menu_level == 5)
	{			// Timer Activation Logic menu
		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
			status_select = 0;
			Timer_Logic = svc_t[Timer_Number].logic;
 		    for(i=0; i<=19; i++)	// printing Timer Type on the top line
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
 	  	}
		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			LCD_Pointer = Menu_level-1;
			Menu_level = 1;
			for(i=0; i<=19; i++)
			{
				LCD_Display[0][i] = LCD_Timer_Menu[0][i];
			  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
			}
			LCD_Display[0][19] = (char)Timer_Number + '0'; 
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
			if (status_select == 1)
			{
				Timer_Logic++;
				if (Timer_Logic > 3)
					Timer_Logic = 0;
			}
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
			if (status_select == 1)
			{
				Timer_Logic--;
				if (Timer_Logic < 0)
					Timer_Logic = 3;
			}
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (status_select == 1)
			{
				status_select = 0;
				svc_t[Timer_Number].logic = Timer_Logic;
				Wrt_Grp_Svc_Timer(Timer_Number);
			}
			else
				status_select = 1;
		}

		if ((status_select == 1) && (prev_flash != LCD_Flash))
			upd_dpy = 1;
		prev_flash = LCD_Flash;

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			if ((status_select == 1) && (LCD_Flash == 0))
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = ' ';
			}
			else
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Logic[(uint8)Timer_Logic][i];
			}
		}
	}
	if (Menu_level == 6)
	{			// Set the timer enable
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++;
 			status_select = 0; 
			Timer_Status = svc_t[Timer_Number].status;
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			status_select = 0;
			LCD_Pointer = Menu_level-1;
			Menu_level = 1;
			for(i=0; i<=19; i++)
			{
				LCD_Display[0][i] = LCD_Timer_Menu[0][i];
			  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
			}
			LCD_Display[0][19] = (char)Timer_Number + '0'; 
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
		    upd_dpy = 1;
			if (status_select == 1)
				Timer_Status ^= 0x02;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
		    upd_dpy = 1;
			if (status_select == 1)
				Timer_Status ^= 0x02;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (status_select == 1)
			{
				status_select = 0;
				svc_t[Timer_Number].status = (svc_t[Timer_Number].status & 0xFD) | (Timer_Status & 0x02);
				Wrt_Grp_Svc_Timer(Timer_Number);
			}
			else
				status_select = 1;
		}

		if ((status_select == 1) && (prev_flash != LCD_Flash))
			upd_dpy = 1;
		prev_flash = LCD_Flash;

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			Timer_Status = (Timer_Status & 0xFE) | (svc_t[Timer_Number].status & 0x01);
			if ((status_select == 1) && (LCD_Flash == 0))
			{
			    for(i=12; i<=19; i++)
				  	LCD_Display[1][i] = ' ';
			}
			else
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Status_Menu[Timer_Status & 0x03][i];
			}
		}
	}
	if (Menu_level == 7)
	{					// Copy Day of Week Timers
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
			status_select = 0;
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			LCD_Pointer = Menu_level-1;
			Menu_level = 1;
			for(i=0; i<=19; i++)
			{
				LCD_Display[0][i] = LCD_Timer_Menu[0][i];
			  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
			}
			LCD_Display[0][19] = (char)Timer_Number + '0'; 
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
			if (status_select == 0)
			{
				LCD_Pointer++;
				if (LCD_Pointer > 2)
					LCD_Pointer = 1;
			}
			else
				status_select = 0;
		    upd_dpy = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
			if (status_select == 0)
			{
				LCD_Pointer --;
				if (LCD_Pointer < 1)
					LCD_Pointer = 2;
			}
			else
				status_select = 0;
		    upd_dpy = 1;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (status_select == 0)
			{
				status_select = 1;
				if (LCD_Pointer == 1)
				{
					for (i=3;i<=6;i++)
						copy_timer(Timer_Number,2,i);
				}
				else
					copy_timer(Timer_Number,0,1);

				Wrt_Grp_Svc_Timer(Timer_Number);
			}
			else
				status_select = 0;
		}

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			if (status_select == 1)
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Copy_Menu[LCD_Pointer + 1][i];
			}
			else
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Copy_Menu[LCD_Pointer - 1][i];
			}
		}
	}
	if (Menu_level == 8)
	{					// Clear Timer
 		if (LCD_Pointer == 0)
 		{
 			upd_dpy = 1;
 			LCD_Pointer++; 
			status_select = 0;
 		    for(i=0; i<=19; i++)
 			  	LCD_Display[0][i] = LCD_Timer_Menu[Menu_level-1][i];
 	  	}
 		if((rdLCDio(Lcd_MODE) == 0) && (LCD_Mode_PB == 0))
 		{	   // Exit to main menu
 			LCD_Mode_PB = 1;  //
			LCD_Pointer = Menu_level-1;
			Menu_level = 1;
			for(i=0; i<=19; i++)
			{
				LCD_Display[0][i] = LCD_Timer_Menu[0][i];
			  	LCD_Display[1][i] = LCD_Timer_Menu[LCD_Pointer][i];
			}
			LCD_Display[0][19] = (char)Timer_Number + '0'; 
		}
		if((rdLCDio(Lcd_UP) == 0) && (LCD_UP_PB == 0))
		{
		    LCD_UP_PB = 1;  // incriment
			status_select = 0;
		    upd_dpy = 1;
		}
		if((rdLCDio(Lcd_DN) == 0) && (LCD_DN_PB == 0))
		{
		    LCD_DN_PB = 1;  // decriment
			status_select = 0;
		    upd_dpy = 1;
		}
		if((rdLCDio(Lcd_ENTER) == 0) && (LCD_Enter_PB == 0))
		{
		    LCD_Enter_PB = 1;
		  	upd_dpy = 1;
			if (status_select == 0)
			{
				status_select = 1;
				clear_timer(Timer_Number);
				Wrt_Grp_Svc_Timer(Timer_Number);
			}
			else
				status_select = 0;
		}

		if(upd_dpy == 1)
		{
			upd_dpy = 0;
			if (status_select == 1)
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Clear_Menu[1][i];
			}
			else
			{
			    for(i=0; i<=19; i++)
				  	LCD_Display[1][i] = LCD_Timer_Clear_Menu[0][i];
			}
		}
	}
	if (Menu_level > 8)
		Menu_level = 1;
}

void clear_timer(int16 Timer)
{
	int16 i;

	svc_t[Timer].status = 0;		
	svc_t[Timer].service = 0;
	svc_t[Timer].logic = 0;
	svc_t[Timer].option = 0;
	for (i=0;i<=2;i++)
	{
		svc_t[Timer].month[i] = 0;
		svc_t[Timer].day[i] = 0;
		svc_t[Timer].md_on_hour[i] = 0;
		svc_t[Timer].md_off_hour[i] = 0;
		svc_t[Timer].md_on_minute[i] = 0;
		svc_t[Timer].md_off_minute[i] = 0;
	}
	for (i=0;i<=6;i++)
	{
		svc_t[Timer].on_hour[i] = 0;
		svc_t[Timer].off_hour[i] = 0;
		svc_t[Timer].on_minute[i] = 0;
		svc_t[Timer].off_minute[i] = 0;
	}	
}

void copy_timer(int16 timer_number, int16 Timer_Ix_1, int16 Timer_Ix_2)
{
	svc_t[timer_number].on_hour[Timer_Ix_2] = svc_t[timer_number].on_hour[Timer_Ix_1];
	svc_t[timer_number].on_minute[Timer_Ix_2] = svc_t[timer_number].on_minute[Timer_Ix_1];
	svc_t[timer_number].off_hour[Timer_Ix_2] = svc_t[timer_number].off_hour[Timer_Ix_1];
	svc_t[timer_number].off_minute[Timer_Ix_2] = svc_t[timer_number].off_minute[Timer_Ix_1];
}

void get_month_day_timer(int16 timer_number,int16 Timer_Ix)
{
	// Month/Day timer
	date_time_var[c_month] = svc_t[timer_number].month[Timer_Ix];
	date_time_var[c_day] =	svc_t[timer_number].day[Timer_Ix];
	date_time_var[c_md_on_hour] = svc_t[timer_number].md_on_hour[Timer_Ix];
	date_time_var[c_md_on_minute] = svc_t[timer_number].md_on_minute[Timer_Ix]; 
	date_time_var[c_md_off_hour] = svc_t[timer_number].md_off_hour[Timer_Ix];
	date_time_var[c_md_off_minute] = svc_t[timer_number].md_off_minute[Timer_Ix]; 
}

void set_month_day_timer(int16 timer_number,int16 Timer_Ix)
{
	// Month/Day timer
	svc_t[timer_number].month[Timer_Ix] = (uint8)date_time_var[c_month];
	svc_t[timer_number].day[Timer_Ix] = (uint8)date_time_var[c_day];
	svc_t[timer_number].md_on_hour[Timer_Ix] = (uint8)date_time_var[c_md_on_hour];
	svc_t[timer_number].md_off_hour[Timer_Ix] = (uint8)date_time_var[c_md_off_hour];
	svc_t[timer_number].md_on_minute[Timer_Ix] = (uint8)date_time_var[c_md_on_minute]; 
	svc_t[timer_number].md_off_minute[Timer_Ix] = (uint8)date_time_var[c_md_off_minute]; 
}

void get_dow_timer(int16 timer_number,int16 Timer_Ix)
{
	// day of week timer
	dow_time_var[c_on_hour] =  svc_t[timer_number].on_hour[Timer_Ix];
	dow_time_var[c_on_minute] = svc_t[timer_number].on_minute[Timer_Ix]; 
	dow_time_var[c_off_hour] = svc_t[timer_number].off_hour[Timer_Ix];
	dow_time_var[c_off_minute] = svc_t[timer_number].off_minute[Timer_Ix]; 
}

void set_dow_timer(int16 timer_number,int16 Timer_Ix)
{
	// day of week timer
	svc_t[timer_number].on_hour[Timer_Ix] = (uint8)dow_time_var[c_on_hour];
	svc_t[timer_number].off_hour[Timer_Ix] = (uint8)dow_time_var[c_off_hour];
	svc_t[timer_number].on_minute[Timer_Ix] = (uint8)dow_time_var[c_on_minute]; 
	svc_t[timer_number].off_minute[Timer_Ix] = (uint8)dow_time_var[c_off_minute]; 
}
*/

//****************************
//  Fault display routine
//****************************

void fault_display (int16 fault_line, int16 dpy_flt_ix, int16 dpy_ix)
{
	int16 i;
	int16 vel_diff = 0;
	int16 fault_code = 0;
	int16 fault_type = 0;
	static int16 prev_fault_line;
	union 
	{
		uint16 w;
		struct {
			uint8 num;			// device number
			uint8 addr;			// address
		}ix;
	}dev;					// unsigned word union

  	if (f.Flts[dpy_flt_ix].code == 0)
		fault_line = 0;
	else 
	{
		if (((f.Flts[dpy_flt_ix].code == f_MRCAN_device_fault) || 
			 (f.Flts[dpy_flt_ix].code == f_CTCAN_device_fault) ||
			 (f.Flts[dpy_flt_ix].code == f_CCDB_device_fault) ||
			 (f.Flts[dpy_flt_ix].code == f_GRCAN_device_fault) ||
			 (f.Flts[dpy_flt_ix].code == f_HCDB_device_fault)) &&
			(f.Flts[dpy_flt_ix].device != 0) &&
			(f.Flts[dpy_flt_ix].prog_flag1 != 0))
		{ // display device and device fault with count
			fault_type = 1;
		}
		else if (((f.Flts[dpy_flt_ix].code == f_MRCAN_device_reset) || 
			 (f.Flts[dpy_flt_ix].code == f_CTCAN_device_reset) ||
			 (f.Flts[dpy_flt_ix].code == f_GRCAN_device_reset)) &&
			(f.Flts[dpy_flt_ix].device != 0))
		{		// Display Device and device requested initialization
			fault_type = 2;
		}
		else
			fault_type = 0;
	}
	
	if ((fault_line == 0) || (fault_line == 13))
	{
		if (fault_type == 1)
		{
			fault_code = f.Flts[dpy_flt_ix].prog_flag1;
 			dev.w = get_device_name_ix(f.Flts[dpy_flt_ix].code, f.Flts[dpy_flt_ix].device);
		}
		else if (fault_type == 2)
		{
 			dev.w = get_device_name_ix(f.Flts[dpy_flt_ix].code, f.Flts[dpy_flt_ix].device);
		}
		else
 			fault_code = f.Flts[dpy_flt_ix].code;
 		
		
		for(i=0; i<=19; i++)
		{
			if (fault_type == 1)
			{
				if (i < 7)
				{
					LCD_Display[0][i] = Can_Dev_Name[dev.ix.num][i];
					if ((i >= 4) && (i <= 5) && (dev.ix.addr != 0))
					{
					  	itoa(dev.ix.addr, LCD_String);  // display addr
						if(dev.ix.addr < 10)  
						{              // of the
							if (i == 4)
						  		LCD_Display[0][i] = '0';
						  	else
						  		LCD_Display[0][i] = LCD_String[0];         // fault index
						}
						else
						{
							if (i == 4)
						  		LCD_Display[0][i] = LCD_String[0];
							else
						  		LCD_Display[0][i] = LCD_String[1];
						}
					}
				}
				else
				{
					if (f.Flts[dpy_flt_ix].code == f_CCDB_device_fault) 
						LCD_Display[0][i] = LCD_CCDB_device_Fault[fault_code][i-7];
					else if (f.Flts[dpy_flt_ix].code == f_HCDB_device_fault) 
						LCD_Display[0][i] = LCD_HCDB_device_Fault[fault_code][i-7];
					else
						LCD_Display[0][i] = LCD_device_Fault[fault_code][i-7];
				}
			}
			else if (fault_type == 2)
			{
				if (i < 7)
				{
					LCD_Display[0][i] = Can_Dev_Name[dev.ix.num][i];
					if ((i >= 4) && (i <= 5) && (dev.ix.addr != 0))
					{
					  	itoa(dev.ix.addr, LCD_String);  // display addr
						if(dev.ix.addr < 10)  
						{              // of the
							if (i == 4)
						  		LCD_Display[0][i] = '0';
						  	else
						  		LCD_Display[0][i] = LCD_String[0];         // fault index
						}
						else
						{
							if (i == 4)
						  		LCD_Display[0][i] = LCD_String[0];
							else
						  		LCD_Display[0][i] = LCD_String[1];
						}
					}
				}
				else
					LCD_Display[0][i] = LCD_device_Reset[i-7];
			}
			else
		  		LCD_Display[0][i] = LCD_Fault[f.Flts[dpy_flt_ix].code][i];
			
		  	if(f.Flts[dpy_flt_ix].code != 0)
		  	{
			  	LCD_Display[1][i] = LCD_Fault_Xtra[0][i];
			  	LCD_Display[2][i] = LCD_Fault_Xtra[1][i];
			  	if ((i>=1) && (i<=3))
				  	LCD_Display[2][i] = servf_tbl[f.Flts[dpy_flt_ix].servf][i-1];
			  	LCD_Display[3][i] = LCD_Procf[f.Flts[dpy_flt_ix].procf][i];
		  	}
		  	else
		  	{
		      	LCD_Display[1][i] = LCD_Clear_Fault[4][i];
		      	LCD_Display[2][i] = ' ';
		      	LCD_Display[3][i] = ' ';
		  	}
		}
		
		if(f.Flts[dpy_flt_ix].code != 0)
		{
			//   "ix=00,P= 1,F= G,#001",   // Line 1
			if (fault_line == 25)
			{
				  	LCD_Display[1][3] = '0';
				  	LCD_Display[1][4] = '0';
			}
			else
			{
			  	itoa(dpy_ix, LCD_String);  // display index
				if(dpy_ix < 10)  
				{              // of the
				  	LCD_Display[1][3] = '0';
				  	LCD_Display[1][4] = LCD_String[0];         // fault index
				}
				else
				{
				  	LCD_Display[1][3] = LCD_String[0];
				  	LCD_Display[1][4] = LCD_String[1];
				}
			}
			
		  	itoa(f.Flts[dpy_flt_ix].pos, LCD_String);  // position
			if(f.Flts[dpy_flt_ix].pos < 10)                // of the
			  	LCD_Display[1][9] = LCD_String[0];         // fault
			else
			{
			  	LCD_Display[1][8] = LCD_String[0];
			  	LCD_Display[1][9] = LCD_String[1];
			}

  		    LCD_Display[1][13] = flmrk[f.Flts[dpy_flt_ix].pos][0];	// Building position of fault
  		    LCD_Display[1][14] = flmrk[f.Flts[dpy_flt_ix].pos][1];
			
			
			itoa(f.Flts[dpy_flt_ix].count, LCD_String);  // # of Ocurences
			if(f.Flts[dpy_flt_ix].count < 10)                // of the
			{
			  	LCD_Display[1][17] = '0';
			  	LCD_Display[1][18] = '0';
			  	LCD_Display[1][19] = LCD_String[0];         // fault
			}
			else if(f.Flts[dpy_flt_ix].count < 100)
			{
			  	LCD_Display[1][17] = '0';
			  	LCD_Display[1][18] = LCD_String[0];
			  	LCD_Display[1][19] = LCD_String[1];
			}
			else
			{
			  	LCD_Display[1][17] = LCD_String[0];
			  	LCD_Display[1][18] = LCD_String[1];
			  	LCD_Display[1][19] = LCD_String[2];
			}


			itoa(f.Flts[dpy_flt_ix].hour, LCD_String);  // Hour
			if(f.Flts[dpy_flt_ix].hour < 10)                // of the
			  	LCD_Display[2][7] = LCD_String[0];         // fault
			else
			{
			  	LCD_Display[2][6] = LCD_String[0];
			  LCD_Display[2][7] = LCD_String[1];
			}
			itoa(f.Flts[dpy_flt_ix].min, LCD_String);  // Minute
			if(f.Flts[dpy_flt_ix].min < 10)                // of the
			{
			  	LCD_Display[2][9] = '0';
			  	LCD_Display[2][10] = LCD_String[0];         // fault
			}
			else
			{
			  	LCD_Display[2][9] = LCD_String[0];
			  	LCD_Display[2][10] = LCD_String[1];
			}

			itoa(f.Flts[dpy_flt_ix].sec, LCD_String);  // second
			if(f.Flts[dpy_flt_ix].sec < 10)                // of the
			{
			  	LCD_Display[2][12] = '0';
			  	LCD_Display[2][13] = LCD_String[0];         // fault
			}
			else
			{
			  	LCD_Display[2][12] = LCD_String[0];
			  	LCD_Display[2][13] = LCD_String[1];
			}

			itoa(f.Flts[dpy_flt_ix].mon, LCD_String);  // Month
			if(f.Flts[dpy_flt_ix].mon < 10)                // of the
			{
			  	LCD_Display[2][15] = '0';
			  	LCD_Display[2][16] = LCD_String[0];         // fault
			}
			else
			{
			  	LCD_Display[2][15] = LCD_String[0];
			  	LCD_Display[2][16] = LCD_String[1];
			}
			itoa(f.Flts[dpy_flt_ix].day, LCD_String);  // Day
			if(f.Flts[dpy_flt_ix].day < 10)                // of the
			{
			  	LCD_Display[2][18] = '0';
			  	LCD_Display[2][19] = LCD_String[0];         // fault
			}
			else
			{
			  	LCD_Display[2][18] = LCD_String[0];
			  	LCD_Display[2][19] = LCD_String[1];
			}

		}
		prev_fault_line = fault_line;
	}
	else if ((fault_line >= 1) && (fault_line <= 12))
	{
		if (prev_fault_line != fault_line)
			Elevator_Status_Init(fault_line-1);
		prev_fault_line = fault_line;
		Elevator_Status(fault_line-1, &f.Flts[dpy_flt_ix]);
	}
}


//*****************************************************
// Get device name index and address
//*****************************************************

int16 get_device_name_ix(int16 fault_port,int16 device)
{
	union 
	{
		uint16 w;
		struct {
			uint8 num;			// device number
			uint8 addr;			// address
		}ix;
	}dev;					// unsigned word union
	
	if ((fault_port == f_MRCAN_device_fault) || (fault_port == f_MRCAN_device_reset))
	{
		dev.ix.addr = 0;
		dev.ix.num = 0;
		if (device == c_mrcan_NTS)
			dev.ix.num = 1;
		else if (device == c_mrcan_SPB)
			dev.ix.num = 3;
		else if (device == c_mrcan_LW)
			dev.ix.num = 7;
		else if (device == c_mrcan_VS)
			dev.ix.num = 9;
		else if (device == c_mrcan_PI_LANT)
			dev.ix.num = 12;
		else if (device >= c_mrcan_SEB_1)
		{
			dev.ix.addr = (uint8)(device - c_mrcan_SEB_1 + 1);
			dev.ix.num = 14;
		}
	}
	else if ((fault_port == f_CTCAN_device_fault) || (fault_port == f_CCDB_device_fault) || (fault_port == f_CTCAN_device_reset))
	{
		dev.ix.addr = 0;
		dev.ix.num = 0;
		if (device == c_ctcan_ENC_SEL)
			dev.ix.num = 0;
		else if (device == c_ctcan_SEL)
			dev.ix.num = 4;
		else if (device == c_ctcan_DOOR)
			dev.ix.num = 5;
		else if (device == c_ctcan_RDOOR)
			dev.ix.num = 6;
		else if (device == c_ctcan_LW)
			dev.ix.num = 8;
		else if (device == c_ctcan_VS)
			dev.ix.num = 10;
		else if (device == c_ctcan_PI_LANT)
			dev.ix.num = 13;
		else if (device == c_ctcan_SEB_1)		// CAR COP
			dev.ix.num = 18;
		else if (device == c_ctcan_SEB_2)		// SELECTOR DZ
			dev.ix.num = 19;
		else if (device == c_ctcan_SEB_3)		// SELECTOR LIMITS
			dev.ix.num = 20;
		else if (device >= c_ctcan_SEB_4)
		{
			dev.ix.addr = (uint8)(device - c_ctcan_SEB_1 + 1);
			dev.ix.num = 15;
		}
	}
	else
	{
		dev.ix.addr = 0;
		dev.ix.num = 0;
		if (device == c_grcan_VS)
			dev.ix.num = 11;
		else if (device == c_grcan_FI_DPY)
			dev.ix.num = 17;
		else if (device >= c_grcan_SEB_1)
		{
			if ((cons[sercom] & 0x01) != 0)
			{
				if (device >= c_grcan_HCB_1)
				{
					dev.ix.addr = (uint8)(device - c_grcan_HCB_1 + 1);
					dev.ix.num = 22;
				}
				else
				{
					dev.ix.addr = (uint8)(device - c_grcan_SEB_1 + 1);
					dev.ix.num = 16;
				}
			}
			else if ((cons[sercom] & 0x20) != 0)
			{
				if (device >= c_grcan_HCDB_1)
				{
					dev.ix.addr = (uint8)(device - c_grcan_HCDB_1 + 1);
					dev.ix.num = 21;
				}
				else
				{
					dev.ix.addr = (uint8)(device - c_grcan_SEB_1 + 1);
					dev.ix.num = 16;
				}
			}
			else
			{
				dev.ix.addr = (uint8)(device - c_grcan_SEB_1 + 1);
				dev.ix.num = 16;
			}
		}
	}
	return (dev.w);
					
}


/* Revision History

 03/04/02 1.14 mhd		1.  Made LCD module.
						2.  Set all const data variables as far.
						3.  Added Emergency power parameters.
						4.  Write Dispatcher number where car number was located on input/output screen
4/1/02	2.00 mhd		1.  Added status for group comm.
05/29/02 2.02 mhd		1.  Changed Attendent to Attendant (service display)
						2.  Deleted Delay using inctime in init_LCD routine since inctime calls Refresh_LCD
							and causes the display to go dark before clearing.
06/25/02 2.03 mhd		1.  Added car cal lockout security i/o's to lcd screen.
                        2.  Correct tx_cnt and rx_cnt for group comm status (display positive counts using unsigned
						    variables - negative counts shows spaces).
07/30/02 3.00 mhd		1.  Display group comm loss count on comm status display.
10/24/02 3.01 mhd		1.  Changed video display to show new fault data and to rotate fault screen when enter button hit.
						2. Deleted Car_Flts array and use Flts array for all cars.
12/19/02 3.02 mhd		1.  Changed Gen Run Time to say Gen/Lt/Fan Tim.
						2. 	Added second level to the following menu items: 
												Job Statistics
													View Job Statistics
													Clear Job Statistics
												Input and Outputs
													Car Inputs and Outputs
													Group Inputs and Outputs
												Setup Calls
													Setup Down Call
													Setup Car call
													Setup Up Call
												Fault Log
													View Fault Log
													Clear Fault Log
												Elevator Setup
													Set Speed Clamp # 1
													Set Speed Clamp # 2
													Set Speed Clamp # 3
													Set Speed Clamp # 4
													Set Speed Clamp # 5
													Lear Hoistway
												Diagnostics
													System Status Log
													Clear System Status Log
													Group Comm
													Clear Group Comm
						3.	Show Serial Hall Call I/o's on Input and Output screen.
						4.	Setup Up and Down Serial Hall Calls
						5.  In Learn Hoistway state, changed dpp count display index to i+3 from i+4 and changed
							check from ((i+4) < 12) to ((i+3) < 11)) to correct display problem of writting over
							the V in Vel. (Changed to match display hoistway table state).
						6. Moved BP8 to ETH, renamed ETH to EQ and moved to I/O #190, moved COL to I/O #191, and if non-distance
						   feedback than use TPL for BKS input.
						7. Use drive_type == 1 for hydro, drive_type == 3,4,5 for distance feedback, and deleted
						   using drive_type == 6 for non-distance feedback because there may be other cases for ndf
						8. Fixed index to write dpp to lcd display during learn hoistway.
2/11/03  				9. Display car number with software version.
3/18/03  3.03 mhd.		1. Added subroutines for setting car and hall calls.
						2. Made clear_job_statistics subroutine.
4/3/03 3.04 mhd			1. Use hall call serial comm if car serial comm used (sercom & 3) != 0.
4/23/03  				2. In main menu, use Traction == 0 to skip setup menu
6/4/03					3. Fix bug in diagnostics menu (array for LCD display used an index of 5 instead of 12).
 						4. Added return to lobby service.
 						5. Fix bug in diagnostics menu (array for LCD display used an index of 5 instead of 12).
 						6. Change PI location for special case when serial hc board used and floors > = 14 and <= 21.
						7. Moved rdfvar and wrfvar from hydro.cpp to this file.
						8. Add new field variable (DOB over Nudg) and (Emerg Dispatch).
						9. Put gripper_fault into backuped stored memory to remember status during power outage.
						10. Set car call bit in serial.brd_io when car serial comm used. See set_carcall.
						11. Added Rear security input labels (RCS) to ionames.
 7/7/03 				12. Added Lobby request and next up parameters.
						13. Allow hall call i/o board to be greater than 10 and display ir, code blue and security io data.
7/30/03	3.05 mhd		1. Added code blue car select field variable.
						2. Added ir car select field variable.
8/11/03 3.06 mhd		1. Change statusf to 32 bits therefore had to add two bytes to each block in the sys_stat buffer.
						2. Use TPL location for BKS for both traction and traction ndf.  Add LWA to s-curve board where
						   BKS was located.
8/29/03 3.07 mhd		1. Relocate LWB and LWA when using an NDF controller.
10/2/03 3.09 mhd		1. Use (sercom & 1) != 0 so car serial comm can be used without hall serial comm.  Also check
						   gc_hall_io_dev for serial hall i/o devices.
						2. Add adjustment variable for independent to override security.
10/10/03 3.10 mhd		1. Modified Refresh LCD so that fire service is shown when firef > 0.
11/11/03 3.11 mhd		1. Modified Set Speed Clamp procedures to check to be out of level zone.
12/15/03 3.15 mhd		1. Decreased the debounce count for the lcd switches when not a satdx4 cpu.
12/17/03 3.16 mhd		1. Added parameter fvars[fvbkcrel] to enable dropping the brake cool relay immediately during a relevel
						   to proved a partial brake lift on relevel.
						2. Added parameter fvars[fvbksrel] for a seperate brake pick delay during relevel.						
12/24/03 3.17 mdh		1. Added parameters for up and down peak operation.
						2. Added Overspeed test and Buffer test.
						3. Added TOC can comm error.
4/21/04 4.00 mhd		1. Setup new io locations for 1038 board. Changed board initialization, io addresses and started io array at 0.
8/27/04 4.03 mhd		1. Added reset jack procedure.
1/10/04 4.04 pn			1. Added field variable to invert brake lift switch input.
						2. Added field variable to invert in-service light output. 
						3. Added field variable to change a car other than 1 or 2 to become the master.
						4. Added field variable to time out video display.
1/12/04	4.04 pn			1. Added parking floor and width parameters to park cars at specific floors.
2/9/05 v4.07 mhd		1. Added load weighing setup screens.
						2. Correct detailed fault display output for IOD=.
4/25/05 4.14 mhd		1. Modify load weighing setup to record empty and full value at each floor.
5/6/05 v4.17 mhd		1. Added can buss error count to can diagnostic display.
 						2. Ask if you are sure you want to secure car calls if secure car calls is selected.
6/2/05 V4.19 mhd		1. Changed fault label from DPR input fail to DPM input fail.
6/22/05 v4.23 mhd		1. Before returning to pwrup routine, enable DOS interrupts.
6/22/05 V4.23 mhd		2. Added local gettime, getdate, settime setdate so that the 18.2 msec DOS interrupt could be disabled.
7/12/05 v4.24 mhd		1. Added pulse count error codes.
7/27/05 V4.26 mhd		1. Change fault display for MC to MCA and MS to MCC.
						2. Changed STP input off to CS input off.
8/4/05 V4.27 mhd		1. Added watchdog test.
						2. Added IR control variable.
8/22/05 v4.29 mhd		1. Changed start index for can from c_can_SPB to c_can_START to add the brake board c_can_BRK.
10/20/05 v4.36 mhd		1. Reset rope gripper from the LCD interface.
10/31/05 v4.37 mhd		1. Added safety string status to elevator status display.
11/9/05 v4.39 mhd		1. Added setup rear car and hall calls from LCD interface.
11/16/05 v4.39 mhd		2. Added door open/close delay time variable
11/21/05 V4.40 mhd		1. Added security recall variable.
11/28/05 v4.41 mhd		1. Added secirity recall floor. 
						2. Modified remoted cc options.
12/8/05 v4.43 mhd		1. Deleted Dynamic Brake Resistor temperature variable.
12/14/05 V4.44 mhd		1. When resetting the gripper, make sure the enter button is not being pressed when entering the
                           routine for the first time (do a return until the enter is not pressed).  This will keep GR1R
						   and GR2R from pulsing when entering in the reset gripper function.
2/1/06 v4.51 mhd		1. Added short dwell door timer
2/24/06 v4.56 mhd		1. Added parameter for stop at lobby fvars[fvstplby] and to invert CLF.
3/14/06 v4.59 mhd		1. Added parameters to invert TPL, LPS and LOS.
						2. Added parameter to nudge door with no onward calls.
						3. Added fvfireop variable
4/4/06 v4.61 mhd		1. Added fire options display. 
						2. Added ATT set car call when hall call set variable.
4/24/06 v4.64 mhd		1. Added Code blue door time, cb light and cb ind req variables.
						2. Added Hospital Service.
5/21/06 v4.67 mhd		1. Start buffer and counterweight test from the top or bottom floor instead of top - 1 and bottom + 1.
						2. Changed display for "p input off" to "p input on".
5/30/06 V4.68 mhd		1. Corrected display of gpi inputs in get_io_status.
6/5/06 V4.69 mhd		1. Added variable for single automatic pushbutton.
6/27/06 V4.74 mhd		1. Changed fviser to use +2 for in-use light
7/7/06 v4.75 mhd		1. Added variables fvdonodol to turn on the door open output if dol is not active when dwelling and 
						   also added fvdisglt to disable the gate and lock test for New York City.
7/25/06 v4.77 mhd		1. Changed max value for dpy_flt_line in in increment section to show the fault display.
7/26/06 5.00 mhd		1. Added realtime displays for LCD_Detail_Fault data in the Elevator Status display.  Also made subroutines
						   to execute this function.
8/15/06 v5.01 mhd		1. Added fvars[fvrlvst] relevel start speed.
8/16/06 v5.02 mhd		1. Added fvars[fvemdec] (Em_Decel) for the emergency decel rate.
						2. Round up when sending velocity and enc_vel to display by adding 0.5 before converting value to an integer.
9/5/06 v5.04 mhd		1. Added fvars[fvrtl] return to lobby variable
10/13/06 v5.06 mhd		1. Added parking type fvars[fvparktype] variable.
						2. Mofify gripper_fault reset to turn on GR1R AND GR2R regardless of the state of GTS.
11/6/06 v5.08 mhd		1. Added UT6/DT6, UT5/DT5 and UT4/DT4 in display hoistway table and elevator setup displays.
						2. Changed Cam_Mode finished valued from 10 to 16.
						3. Corrected parking floor index for 6 and 7.
						4. Added variable for non-simultaneous doors.
11/29/06 v5.09 mhd		1. Added variable for pre-opening door and for percent overspeed.  
						2. Modified variable for gripper trip from spb speed and overspeed.
12/26/06 v5.10 mhd		1. Added pos count update enable, pulse delay and gripper buzzer enable flags
						2. Changed brake lift switch invert option to show 0 for N/C and 1 for N/O.
12/29/06 v5.11 mhd		1. Added display for pulse count update in hoistway table display
						2. Use -1 for max number of cars and -2 for max number of floors for max adjustable variables and
					   	   use -1 for car number and -2 for bottom floor for the min variables.
						3. Added lowoil switch fault.
						4. Changed all double data types to float for the djgpp compiler.
1/12/07 v5.13 mhd		1. Add bit in fire option to turn off fire buzzer when car reaches fire floor.
1/18/07 v5.15 mhd		1. Added fire option 2 variable.
						2. Added brake opto delay.
1/26/07 v5.16 mhd		1. Changed "GATE OR LOCK OFF" status flag to "Door Close Contact".
2/15/07 v5.18 mhd		1. Made arrays out of variables that used one bit for floor from 1 32 word to 2.
						2. Added more pages for the car and group io display.
						3. Made the floor mask large enough for 60 floors.
						4. Show device version and revision on group comm display.
						5. Modified get_io_status for additional i/o boards.
2/23/07 v5.19 mhd		1. Corrected size declaration for bittbl from int to int16.
						2. Added interim revision number int_revision.
3/22/07 v5.21 mhd		1. Corrected the return from mode screen in load weighing setup: use LCD_Elev_Setup[16] instead of
							LCD_Elev_Setup[12].
4/11/07 v5.22 mhd		1. Added fvars[fvlevfltcnt]  leveling fault count variable.
						2. Added torque down variable fvars[fvtorqdn].
5/11/07 v5.23 mhd		1. Left out "break;" statement in detailed Elevator_Status.
						2. Changed soft stop timer to .2 sec minimum. 
						3. Changed relevel fault count to 3 trys minimum.
						4. Added torque ramp time.
						5. Added several error codes for hoistway variable check.
5/29/07 v5.24 mhd		1. Modified label for ISER Output Ctl.
						2. Added Electric Eye time-out parameter.
6/6/07 v5.25 mhd		1. Added variable fvars[fvotshc] "OTS No HC Canc" to prevent from cancelling hall calls when all cars go out of service.
6/18/07 v5.27 mhd		1. Added ability to modify the hoistway table floor and limit counts.
7/10/07 v5.30 mhd		1. Added phase 1 door close time-out variable.
8/6/07 v5.31 mhd		1. Added variable fvnohcreop to prevent hall call from reopening when set and onward hall call.
8/13/07 v5.33 mhd		1. Add bit in fireop2 to disable blink for phase 2 fire light (chicago only). Default is to blink
						   fire light when motor room or hoistway smoke detector active.
8/20/07 v5.34 mhd		1. Added drive ready fault counter.
9/13/07 v5.36 mhd		1. Change accel and decel max to 300 and jerk rates to 480.
9/24/07 				2. Change fviser & 0x04 to out of service alarm.
						3. Added fvrtldt (return to lobby door dwell time)
						4. Moved Double stroke variable to car options.
						5. Placed Em power floor in car options and left it in group options.
						6. Placed Em Dispatch in group options and left it in car options.
10/1/07 V5.37 mhd		1. Increased number of variables from 180 to 360. 
						2. Added NCU Lantern Control Variable.
						3. Added NCU Preference Control Variable.
10/4/07 v5.38 mhd		1. Added Second Riser Control variable.
						2. Added Second Riser Lanter Control variable.
10/18/07 v5.38.1 mhd	1. Added BKS Fault slowdown error 
10/31/07 v5.38.4 mhd	1. Added HBZ/PI Dis at non-valid floor.
11/13/07 v5.39 mhd		1. Added vip timer, vip op and nmb vip cars variables.
			   pn/mhd	2. Added Car call test.
11/20/07 v5.39.1 mhd	1. Added parameters for Emergency Power park and op outputs.
11/20/07 v5.39.2 mhd	1. Added elevator off option variable.
11/28/07 v5.39.3 mhd	1. Added drive baud and drive update rate variables.
12/01/07 v5.39.4 mhd	1. Added alternate lobby floor, alternate parking floor, lobby request control and 
						   handicap hall button control variables.
12/11/07 v5.39.5 pn		1. Added paramter to time-out closing of freight doors.
12/12/07 v5.39.6 mhd	1. Added leveling time-out fault.
12/28/07 v5.39.9 mhd	1. Use -3 for cons[speed] in adjustable variables.
						2. Use nmb_hcio_brds instead of fixed value to correct for highrise cars.
1/7/08	v5.40.1 mhd		1. Modified elevator_service to check for servf on fire service and to show door status on earthquake service if door are closed.
						2. Modified front and rear door display to show proper door location when on fire service.  When both front and rear are closed,
						   show door closed and not rdor closed.
1/15/08	v5.40.2 mhd		1. Add variable "RCM Hold" to hold retiring cam at valid floor until a door open is requested.
1/25/08 v5.40.3 mhd		1. Changed name of RCM_HWDoorCL to RCM_HWDoor. Change variable RCM HOLD TO RCM Control added bit 2 for advanced RCM when RCM_HWDoor set.
2/5/08 mhd				2. Changed "DCL Input Off" to "Looking for DCL".
1/30/08 v5.40.4 mhd		1. Allow brake lift on inspection with door open.  Make user press two additional keys to verify. 
						2. Change hall addres # from 32-44 to B6-B18 to reflect the jumper configuration.
						3. Added variable for recall from fs1 alt floor fvrecallfs1a
2/4/08 v5.41 mhd		1. Added variable for automatic learn hoistway stall time.
						2. Added automatic learn hoistway.
						3. Check that pulses increment every two seconds.	  
						4. Corrected io status for hall calls from 26 to 37 for highrise cars.
3/1/08 v5.41.1 hdl		1. Restructured the LCD interface for changing the date. Now you can change year by units, tens hunderds and thousands. Also no invalid years can be entered.
3/11/08 v5.42 mhd		1. Added new brake parameters, brake pick start, brake relevel start, brake pick rate and brake relevel rate.
						2. Added short floor slowdown timer and Mid short floor slowdown timer for hydro and traction ndf.
3/20/08 V5.42.2 mhd		1. Added short floor up and down slowdown timers for short and mid short floors.  Changed current timers to down and added ones for up.
3/21/08 V5.42.3 mhd		1. Added HS Elev Off Floor, GOV Grip Trip, PI Serv Msg 1, and PI Serv Msg 2 variables.
3/24/08 v5.42.4 mhd		1. Added variables for Short Floor Soft Start, Short Floor Accel rate, Short Floor Roll Over Jerk, Short Floor Decel Jerk, Short Floor Decel Rate and Short Floor Targ Distance.
3/25/08 V5.42.5 mhd		1. Added short floor control variable.
4/1/08 v5.43 mhd		1. Modified brake lift on inspection to swich screens if safe() is picked or dropped.
						2. Moved inspection door close to service options.
4/17/08 v5.43.5 mhd		1. Added EP recall delay variable.
4/18/08 v5.43.6 mhd		1. Modified stop at lobby parameter display.
						2. Added Group override security timer.
4/25/08 v5.43.8 mhd		1. Corrected debounce for lcd buttons.
5/16/08 v5.44 mhd		1. Added hc on and off brightness variables.
						2. Changed min brake pick and hold voltage to 20 and min brake relevel voltate to 10.
6/10/08 v5.44.1 mhd		1. Changed ul or dl off fault to ul and dl off fault.
6/30/08 V5.44.5 mhd		1. Reversed serial io hall calls order to start with 1D at the top of display so get_io_status() had to be modified.
						2. Changed pf3 to dv2 for device 2 in error log and prog_flag3 to device_2.
7/3/08 v5.45 mhd		1. Reset gripper latch only if no SPB comm error and the SPB does not have an Unintended Motion fault.
						2. Added parameters fvacctopfl, and fvaccbotfl.
						3. Corrected last_var[] for service option on tract ndf. 
7/10/08 v5.45.1 mhd		1. Added variable fvars[fvppstop] to enable stop on count.
7/22/08 v5.45.2 mhd		1. Deleted DPP_DZU_Count[], DPP_DZD_Count[] and DPP_FL_Offset[] to use DZU_Dist, DZD_Dist, Up_fl_level_dist and Dn_fl_level_dist instead.
8/15/08 v5.45.5 mhd		1. Add parameter for sabbath restart time fvars[fvsabtim].
8/20/08 V5.45.6 mhd		1. Added Security Recall as service 24.
9/2/08 v5.45.7 mhd		1. If no valid front from during buffer test the set car call for rear floor.
9/24/08 v5.46 WC/mhd    1. Automatically display fault on LCD  when it occurs; Function Refresh_LCD in LCD.cc was modified
                           as well as the function record_faults in control.cc
						2. Adjustable varible fvfltdpy in globle.cc and control was to created to turn on or off the above feature
9/29/08 v5.46 mhd		3. Added reset low oil from LCD display for 2007 code.
						4. Added GOV reset.
10/2/08					5. Added behind car call cancel variable.
10/15/08				6. Delete clearing LCD_State_ix when password is not being checked i.e. (fvars[fvpassword] == 0).
10/15/08 v5.46.1 mhd	1. Reset LCD_Menu to known state in ReturnLCDMenu if LCD_State_ix == 0.
						2. Jump to powerup.exe routine same as a traction of hydro running on ts5300 cpu.
10/20/08 v5.46.2 mhd	1. Added advance door enable timer for non-simultaneous doors.
10/21/08 v5.46.3 mhd	1. Added variables, Group service parking, Binary Preset Always, Short floor hsf without hsv. (only use Binary Preset with this version)
11/4/08 v5.46.5 mhd     1. Added Service Timers.
11/18/08 v5.46.6 mhd	1. Changed baud rate for drive.
						1. Added modbus protocol parameter.
11/28/08 v5.46.7 mhd	1. Added Adjust Drive Parameters routine for delta drive.
12/15/08 v5.46.8 mhd	1. Added floor offset back into table. see display_fl_off().
1/12/09 v5.47.1 mhd		1. Change the loop when displaying HC serial i/o board to check all the group devices each time.
						2. Also display the correct hall call driver board number instead of always 1.
1/14/09 v5.47.2 mhd		1. Added get io status check for gpio board 9 on non HR car in get_io_status() routine.
						2. Corrected io status for case 20: in grp_io_status.
						3. Corrected diagnostic display for hc comm boards.
1/20/09 v5.47.3 mhd		1. Added version and revision for serial hall call boards.
2/02/09 v5.47.4 pn		1. Added Sabbath feature as service 25.
2/9/09 v5.47.5 mhd		1. Added variable "Alt Rcl FS Off" (fvaltrclfs) to allow car to return to fire alternate floor after car has returned to main recall floor from FS switch 
						   and FS switch is then turned off.
2/10/09 v5.47.6 mhd		1. Added car call push button security code entry and service activation.
						2. Added Day of the week display under date and time menu.
3/1/09 v5.47.7 mhd		1. Made corrections to car call pushbutton security user input.
3/10/09 v5.47.10 mhd	1. Added emergency power recovery mode.
						2. Added mechanism to keep the ul and dl offsets on a hoistway learn.
						3. Allow interim version to be two digits.
						4. During auto hoistway learn, check for (LCD_Sub_Point != 13) to disable mode button to prevent car from contiuning to run 
						   if LCD_Menu == 0 and mode button pressed while going down looking for DN.
						5. Added parameter for inspection decel stop rate.
3/19/09 v5.47.11 mhd	1. Added Ep_Recov_Vel for emergency power recovery velocity.
						2. Added Em_Lev_Decel Emergency Deceleration to Leveling Rate.
						3. Added Cycle Run time.
4/1/09 v5.48.1 mhd		1. Modified adjust_variable() routine to not treat -1,-2 and -3 specail for min and max values.  This is done in utils.cc only.
4/22/09 v5.48.4 mhd		1. Added hall call red, green and blue on and off parameters.
5/15/09 v5.48.5	hdl		1. Added field variable and ouput for Door open light. Options FireRecall complete, return to lobby complete and emp = 4 home doors open
5/18/09 v5.48.6 mhd		1. Added power loss brake control in Elevator Setup menu.
						2. Corrected adjustment of slowdown limits above UT2 and DT2.
5/20/09 v5.48.7 mhd		1. Added diagnostic display for ups comm and status.
						2. Corrected get_io_status to use gc_uc_dsr[], gc_dc_dsr[], etc. instead of gc_uc[] and gc_dc[], etc.
5/29/09 v5.48.8 mhd		1. Added parameters for hall call button colors.
						2. Added hoistway sensor 2 return floor variable.
						3. Display fire service software variables on status screen.
6/3/09 v5.48.9 mhd		1. Added fault code for ul,dl setup count fault.  If rpm is incorrect the calculation for 8 inches is incorrect.
						2. Corrected display for UPS status.
						3. Deleted brake time-out for power loss brake pick. (Car moves very slow).
						4. Corrected UPS status bit test.
6/12/09 v5.48.11 mhd	1. Added fault for EP Recall time-out, EP Recall ots and SPB SFC fault.
						2. Added Drive speed multiplier parameter. 
7/20/09 v5.49.1 mhd		1. Added errors for up and down normal limit setup.						
7/30/09 v5.49.5 mhd		1. Added parameter for advanced pre-torque.
8/1/09 v5.49.6 mhd		1. Added HCB Reset and Init command in diagnostic display.  Rearranged diagnostic display to show hall call board status after group status.
8/8/09  v5.49.7 mhd		1. Changed HcbControl to an array to send control data to all hall call driver boards.
8/11/09 V5.49.8 mhd		1. Changed bit in HcbControl for reset from bit 4 to bit 0x80.	(Will only work with version 2.01 and higher driver board.)
						2. Added selector preset fault code.
8/28/09 V5.49.11 mhd	1. Added car call light color and brightness control variables.
9/1/09 v5.49.11 wc		1. LCD_Pointer corrected in diagnostic DN button if drive comm and serial hall buttons.
9/10/09 v5.49.11 mhd	1. Added Governor trip function.
9/15/09 V5.50 mhd		1. Modified gripper reset display, parameters and error codes to better suit the Emergency brake. see EBK.	
9/30/09 v5.50.3 mhd		1. Added Sabbath control variable.
10/7/09 v5.50.4 mhd		1. Added detector edge time-out fault.
10/12/09 v5.50.4 mhd	1. Added parameters for low line voltage and low door voltage.
						2. Added faults for L1, L2, L3 and Door low voltage.
10/21/09 v5.50.5 mhd	1. Re-arranged menu system to add Modified Motion, Pushbutton Option and System Options.

11/25/09 v5.50.8 hdl	1. added two field variables, fvsabuzt and fvsadt. One is the timer for the buzzer to go off
							before doors close. The second is a dwelling time that engages once the sabbath operation is ON	
12/31/09 v5.50.10 hdl	1. added function reinit_LCD to reset the display in the event that it gets garbage on the screen
							you need to press Mode -> Up -> Down -> Up -> Down.
						2. Corrected LCD load weigher routine. Issue: if no comm to load weigher board,
							the display will say complete, get frozen and you could not exit out to the main menu
12/9/09/v5.50.11 mhd	1. Modified Power Loss Brake lift to use the MBP to turn off after time delay to shut off UPS.
						2. Added error codes for run inhibit from reset count, at floor shutdown and emergency motion exit from inspection.
						3. Added hot oil fault error display message.  
12/28/09 v5.51.2 mhd	1. Added ee cancel dwel parameter.
						2. Added lobby dwell and lobby off to Sabbath Enable Control variable.
01/9/10 V5.51.4 mhd		1. Added EP recover move select count and at floor select variables.
1/26/10 v5.51.9 mhd		1. Changed check for PWL_Brake == 0 to != 1 to allow for PWL_Brake == 2. 
						2. Changed PWL status and faults to UPS.
						3. Send command to SPB to display car speed when lifting brake on inspection.
						4. Show comm status for Eaton UPS_Type == 1.
2/8/10 v5.51.10 mhd		1. Added parameter to assign parking floor to car with door open.
3/12/10 v5.51.14 mhd	1. Added security activation timers for Floor security configurations 2, 3, and 4. 
3/19/10 V5.52 mhd		1. Changed SEB #18 label to CC1 #18.
3/23/10 v5.51.16 mhd 	1. Added variables for Sabbath start at lobby and to use cab lanterns for direction arrows.
3/24/10 v5.52 mhd		1. Added fault messages for RGB Car Call Board.
3/29/10 V5.51.1 mhd		1. Added variables fvclantctl (cab lantern control), fvmaxdoorhld (max door hold time), and fvaccdoorcl (access door close).
4/2/10 v5.52.2 mhd		1. Show door status when servf == 0 and procf >= 14 and procf <= 16.  Car level at the floor and out of service.
5/3/10 5.52.7 mhd		1. Added error code for hall call low supply voltage.
6/7/10 V5.52.9 mhd		1. Increased number of variables from 360 to 420. 
						2. Added parameters for hall call light control for up and down, ir, code blue and vip.
						3. Add CB,Vip & HSec Call Light menu item, renamed Car Call menu to CC & COP Lights, and renamed Hall Call menu to HC & IR Call Lights.
						4. Added parameters Vip lantern control and Group Car Call Override Control.

6/21/10 v5.52.10 hdl	1. Added 3 exclusion fault field variables and control variables for each (6 fvars). You can choose not to display faults based on ctrl
						2. Changed logic for retiring cam to attempt 4 times to make up locks before declaring a fault and shutiing down
						3. Added RCM / lock fault
6/24/10 v5.52.11 mhd	1. Corrected label for hall call address from Hall #C21 and C23. 
7/1/10 v5.52.11 mhd		1. Added new electronic emergency brake parameters
7/8/10 v5.52.14 mhd		1. Added LCD_HCB_Com_Fault[] variables for Up Input Overload, Dn Input Overload, Aux Up Input Overload, and Aux Dn Input Overload. 
7/29/10 v5.52.19 mhd	1. Modified get_io_status() to add code blue second riser inputs.  
						2. Added parameter for second riser code blue car, for ir car code blue enable and ir code blue penalty time.

8/10/10 v5.52.22 hdl	1. Exclusion faults were not displayed properly. Modified Display_Var_Label()
8/24/10	v5.52.26 hdl		1. Added INSEC output and fvars[fvinsec] for inverting the output. 
							It outputs whether the in car security is enabled or not
9/8/10 v5.52.29 mhd		1. Added Encoder Dbn Interval parameter.
10/6/10 V5.52.36 mhd	1. Added modbus comm to Yaskawa L1000 drive (drive_type[]=15).
						2. Added service ups parameter to allow the ups to be disconnectd from the comm while it is being serviced.

10/18/10 v5.52.58 hdl 	1. The label for emergency drop rate was incorrect. Changed from 5 to 1.5

10/25/10 v5.52.39 hdl	1. Added the menu under Software version to back up flashcards to the flashcard and recover from there
10/25/10 V5.52.41 mhd	1. Added two additional I/O board on can bus.
11/11/10 V5.52.46 mhd	1. Added security variables to activate modified express service security for hall calls on individual cars.	 See Hall Call secure direction.
11/19/10 V5.52.47 mhd	1. Added UPS baud rate parameter.
11/23/10 v5.52.48	hdl	1. Added fvhcattbuz to allow car to aknowledge hall calls bu buzzing for 1 second every new call comes in. To be used in attendant cars
11/28/10 v5.52.49 mhd	1. Deleted all parameters to activate modified express service except for Hall Call assignment secure type.
1/11/11 v5.52.56 mhd	1. Added encoder preset fault.
						2. Delete Delta Drive.
2/2/11 v5.52.58	hdl		1. Changed the max for fveppkled from 1 to 2. It allos the PRK led to come on only when teh car is at the emp floor 

3/16/11 v5.52.09 hdl	1. in find io status the labels for the group security board were off by one on the second board fpr group security . 
							changed index from 9 to 8 in case 35
5/20/11 v5.54.02 mhd	1. Added parameters for direction check and ee memory location.
7/8/11 v5.54.11 mhd		1. Fixed menu index for Elevator Setup menu for hydro when using GOV reset on roped hydro.
7/11/11 v5.54.12 mhd	1. Allow OSERL OutCtrl 2 to be changed to zero. Set to 1 gives control to OSERL Outctl 1.
7/12/11 v5.54.14 mhd	1. Added variables for MED door reopen and MED independent override.
7/26/11 v5.54.17 mhd	1. Added Base count and encoder init count to display.
				 hdl	2. Added user message 3 parameter.

9/22/11 v5.54.25 mhd	1. Added 1st recall and select car parameters for second power feeder

10/13/11 v5.54.32 mhd	1. Add menu item to reset debug variables in Software Version menu.

11/29/11 v5.54.40 hdl	1. Changed display hoistway tables routine to subtract DPP_DN instead of 5000. 
						All limit switches distances in feet were off by 13 feet since we are not starting at 5000 anymore.

01/03/2012 v5.54.46 pn	1. Changed Exclusion fault feature from 3 to 6 and eliminated the exclusion fault control option for each exlusion fault.								
1/30/12 v6.0 mhd		1. Added parameter and fault for velocity difference check between SPB velocity and Encoder velocity.
						2. Added seperate flag for encoder velocity unintended motion in fvspbgrip variable.
						3. Deleted parameter fvdisglt that allows the gate and lock check for NY to be disabled.

2/1/12 v5.54.53 mhd		1. Added parameters fvdobovrdcb	and fvdenfsv to allow DOB to override DCB on phase 2 (for Miami) and special recall operation for Denver to close the doors after
						   the car recalls on phase 1.  Doors are reopened from the hall call button at the recall floor.
						2. Added parameter fvf1dwell for denver phase 1 dwell time
3/8/12 v6.0.1 mhd		1. Changed SPB Vel Difference Fault to Slip Detect Fault. Also added Slip Vel Difference Disable parameter.
3/8/12 v5.54.62 mhd		1. Changed SPB Vel Difference Fault to Slip Detect Fault. Also added Slip Vel Difference Disable parameter.

3/14//12 v5.54.63 hdl	1. Added check for emergency breake when resetting emergency brake so we could turn on UTM in LCD routine 
5/1/12  v6.0.7 mhd		1. Check for gripper fault during hoistway learn.
5/1/12 v6.0.7 mhd		1. Added new brake control cons[EM_BRK] == 7.  This is to have a controled drop of the emergency brake even after MC drops.
8/14/12 v6.0.16 mhd		1. Added Auto_Learn_Hoistway(1) when LCD_Sub_Point == 14 to make sure that learn run command turns off. 
						2. Also in auto learn, changed LCD_Sub_Point = 16 from 15 in down check when LCD_Sub_Point == 13 to give the correct error code.
9/17/12 v6.0.21 mhd		1. Added motor rpm for keb drive.
						2. Added modification for velocity display for power loss brake lift.
1/4/13 v7.0.0 mhd		1. Added Riot Control service when cons[prison] == 2, servf = s_RIOT from v5.55.15 atl_fed_pen.
2/13/13 v7.0.1 mhd		1. Added emergency power manual select (fvep_selsw_rcl) and acces speed (fvaccspd) paremeters.
9/3/13 v7.0.18 mhd		1. Changed Display_Var_Label() routine to use the variable index number instead of the menu index number to identify which variable needs to display a label.
						   The reason for this change is that when a new variable is added to the middle of a menu, the changed in index number no longer matters.
						2. Added keb display type parameter to select new keb display instead of using a different drive number.
						3. Added parameter to select the encoder type instead of using the cons file parameter.
9/12/13 v7.0.19 mhd		1, Seperated Elevator_Setup from lcd.c.
						2. Added parameter for single or 3 phase brake input voltage.
						3. Moved elevator_setup() to a seperate module.
9/30/13 v7.0.21 mhd		1. Added check for inspection to read or write to eeprom. (Previously commented out)
						2. Added distance feed forward parameter.
10/29/13 v7.0.24 mhd	1. Added parameters 516 and 517 below to match GALaxy 3. .
							  "SR CCSec by Dir=        ",	// 516 C Second Riser car calls security by direction 
							  "Min Door Tim En=        ",x	// 517 C Minimum short door time enable

11/12/13 v7.0.28 mhd	1. Replaced cons[carnmb] with 1 where necessary to allow any car to be the group.
						2. Replaced iodata[1] with iodata[cons[carnmb]] where necessary.
11/27/13 V7.0.30 mhd	1. Replaced 4 instances of Sys_Stat_Size with MRAM_Sys_Stat_Size
						2. Added variable for fire reset 2.
						3. Added variable to Invert HC security inputs
1/20/14 v7.0.32 mhd		1. In diagnostic display added "to" to grcan, ctcan and mrcan such as "Group GRCAN to SEB #1"
3/21/14 v7.0.37 mhd		1. Display additional fault and status data from fault display and elevator status.screen.
6/26/14 v7.1.4 mhd		1. Displayed inspection service when on inspection.
7/23/14 v7.1.6 mhd		1. Added additional faults
11/10/14  V7.1.20 mhd	1. When field variable changed, send data to galcom device.
11/25/14 v7.1.21 mhd	1. Write field variables (limit values) when limit velocities are initialized.
12/16/14 v7.1.24 mhd	1. Modified G4 to match changes in the following G3 software modifications: 
							12/02/13 v6.1.18 as		1. Added Trace options under software utilities to start and initialize trace, or clear trace
							9/12/14 v6.1.76 as		1. Added additional I/O board to Can_Device_Name[].
							10/7/14 v6.01.87 as		1. Added below changes related to G3 software:
													9/26/14 v6.1.87 cl		1. Added "COP/Remote Dis" to Car options 
																			2. Change Indepent security description to "+1=CCS +2=SECF +4=COP   " and change max to 7
							11/5/14 v6.1.95 as		1. Modified get_io_status() routine to show correct IO status when we have cons[CB_SR] for io board 52 and 53.
2/26/15 v7.1.27 mhd		1. Set the minimum time on the password time-out to 10 seconds.
4/6/15 v7.1.29 mhd		1. Moved IO dislay routines to a seperate file (iodpy.c).
6/19/15 v7.1.35 mhd		1. Changed EBK1 faults to EBK and EBK2 faults to EBK1 to match IO names.
7/13/15 v7.1.38 as		1. Added printing option " 3 = 115200 Baud        " on the Drv_Baud_Display array.
9/17/15 V7.1.41 mhd		1. Added earthquake reset to display.  
						2. Fixed hall call driver board on-line in Diagnostics HC Boards Comm Status.
11/18/15 v7.1.48 as		1. Added sending packet 109 when Date and Time is updated on the dispatcher through LCD.
11/23/15 v7.1.50 mhd	1. Change fault code Learn HW Safe Fault to Hoistway Safe Fault so that it can be used for both Hoistway learn and brake test.
12/21/15 v7.1.54 tb		1. Added delimiters to LCD_Fault[] to return fault string from array when searching for "[faultnumber]F -".
						2. Changed LCD_Par for parameters 186 (fvheloff) and 528 (fvceloff) to match with GALaxy 3:
							"+1=RC+2=DO,+4=CLFof+8=DC",   // 186 - Hall Elevator Off options
							"+1=RC+2=DO,+4=CLFof+8=DC",   // 528 - Car  Elevator Off options
1/4/16 V7.1.56 mhd		1. Added "Parameter Setup Flt" to device_fault table.
						2. Added "PAR ER" to spb_service.
01/12/16 v7.1.62 tb		1. Changed LCD_Par and LCD_Field_Vars strings for fvheofovrind to match G3.
11/8/17 v8.0.17 mhd		1. Used fvars_deci[nmbfvar] bit 7 when set, the variable data is displayed as individual bits.  Bits 0-3 of fvars_deci[nmbfvar] are the number of individual bits used. 
						2. Modified display_variable(), adjust_variable(), set_adj_digit() and Display_Var_Label() to show variable as bits when needed.
						3. Modified display of fvsecrec, fvheloff, fvopenlctl, fvoser1, fvsabben, fvceloff, fvceloff2, and fvrmccd to be bit adjustable.
						4. Added tix (trace index) to trace screen when you press the enter button.
						5. Set LCD_Menu to 6 on power up so that the initial screen is the Elevator Status screen.
12/07/17 v8.0.21 tb   	1. Corrected "Safety Sting" to "Safety String".
*/
