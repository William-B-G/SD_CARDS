extern const char LCD_Elev_Setup[][21];
extern const char Learn_Hw_CED[34][21];
extern int16 Elevator_Setup (int16 lcd_menu);
extern int16 hwl_number_valid_fl (void);
