extern int16 Display_Car_IO (int16 lcd_menu);
extern int16 Display_Group_IO(int16 lcd_menu);
extern uint16 get_io_status(int16 brdnmb, int16 ix);
extern int16 Relocate_IO(int16 lcd_menu);
extern int16 Display_FPGA1_IO (int16 lcd_menu);
